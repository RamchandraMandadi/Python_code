"""
Portfolio Manager — Entry Point with Login
Requires: pip install pandas openpyxl Pillow
Run: python main.py
"""
import tkinter as tk
from ui.login_window import LoginWindow
from ui.main_window  import MainWindow
from ui.app_monitor_view import register_session, deregister_session, start_heartbeat


_main_root = None


def launch_app(user_info):
    """Called after successful login — destroy login root and open main app."""
    login_root.destroy()

    # Register the user session for monitoring
    method = user_info.pop('_login_method', 'Password')
    register_session(user_info, method=method)
    username = user_info.get('username', '')

    global _main_root
    _main_root = tk.Tk()
    _main_root.configure(bg='#f0f2f7')

    def on_logout():
        deregister_session(username)
        _main_root.destroy()
        main()  # re-launch login

    def on_close():
        """Window X button — treat same as logout for session cleanup."""
        deregister_session(username)
        _main_root.destroy()

    app = MainWindow(_main_root, user_info=user_info, on_logout=on_logout)
    _main_root.title(
        f"KMG Portfolio Mgmt  —  {user_info.get('full_name', user_info.get('username', ''))}  [{user_info.get('role', '')}]"
    )
    _main_root.protocol('WM_DELETE_WINDOW', on_close)
    # Start the heartbeat so the shared ActiveSessions sheet stays current
    start_heartbeat(_main_root)
    _main_root.mainloop()


def main():
    global login_root
    login_root = tk.Tk()
    LoginWindow(login_root, on_success=launch_app)
    login_root.mainloop()


if __name__ == '__main__':
    main()
