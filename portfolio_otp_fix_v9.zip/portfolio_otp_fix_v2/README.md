# Project Management Application — with KMG PPT Report integration

A desktop Project Management application built with Python + Tkinter.
All data lives in **one** Excel file: `input/project_data.xlsx`.

## What this build adds

A **`📑  PPT Report`** button has been added to the right side of the
project header card on the **Project Status** tab (next to the
Priority / Progress / Budget Used metrics).

Pressing the button opens the KMG-style slide-overlay preview window
where you pick a **Project** and a **Month**, then click
**📊  Create as PPT** to generate a `.pptx` file. The file is filled in
from the bundled `assets/template.pptx`, so all original images, icons,
colour bars and layouts are preserved — only the dynamic values are
inserted.

> The KMG wizard's "Volume of Work / Portfolio" page is **not** shown
> in the UI (per request). The volume-of-work table on slide 3 of the
> PPT is still filled automatically using `WeeklyStatus` numbers.

## Data mapping (all from `input/project_data.xlsx`)

| PPT field | Source sheet & columns |
|---|---|
| `status_as_of`            | `WeeklyStatus.MonthLabel` for the picked month |
| Milestones (W1-W4)        | `WeeklyStatus.{WeekLabel, Status, Description}` |
| Summary                   | `Projects.{ProjectName, Client, Manager, Department, Priority, Description, Budget, Spent}` + month rollup |
| Resource Updates          | `Projects.Manager` + month hours rollup from `WeeklyStatus.HoursLogged` |
| Recent Accomplishments    | `Tasks` where Status='Completed' + `WeeklyStatus` rows where Status='Done' |
| Upcoming Key Activities   | `Tasks` where Status in {In Progress, Not Started, At Risk} |
| Key Risks and Issues      | `RAG` rows where Status='R' |
| Mitigation Discussions    | `RAG` rows where Status='A' |
| Volume-of-work table      | `WeeklyStatus.{HoursLogged, WeeklySpend}` (4 weeks) |
| Value Delivered           | Computed roll-up |

Status colour mapping for milestones:

| WeeklyStatus.Status | Milestone colour |
|---|---|
| Done | Green - "On track; will complete as planned" |
| In Progress | Amber - "Planned delivery at risk" |
| At Risk | Red - "Will miss planned delivery" |
| Planned / Not Started | Grey - "Originally planned or completed" |

## Run

```
pip install -r requirements.txt
python main.py
```

Then: **Project Status** tab -> pick a project from the Project dropdown ->
click **📑  PPT Report** -> pick a month -> **📊  Create as PPT** -> save.

## File map of the integration

```
pm_final/
├── assets/                            # NEW - KMG slide assets
│   ├── template.pptx                  #   bundled PPT template
│   ├── slide2_ui_bg.jpg               #   slide-overlay background
│   └── slide{1..4}_preview.jpg
├── services/
│   ├── ppt_generator.py               # NEW - fills the template
│   └── ppt_data_builder.py            # NEW - maps Excel -> PPT data dict
├── ui/
│   ├── ppt_slide_view.py              # NEW - slide-overlay UI window
│   └── project_status_summary_view.py # MODIFIED - added PPT Report button
└── requirements.txt                   # MODIFIED - added lxml
```
