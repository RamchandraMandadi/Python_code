from repository.excel_repository import ExcelRepository
from core.schema_reader import SchemaReader
import pandas as pd
from datetime import datetime

from services.progress_service import ProgressService
from services.project_status_service import ProjectStatusService


class DataService:

    def __init__(self):

        self.repo = ExcelRepository()
        self.schema_reader = SchemaReader()

    # ==============================
    # BASIC METHODS
    # ==============================
    def get_sheets(self):
        return self.repo.get_all_sheets()

    def get_schema(self):
        return self.schema_reader.get_schema()

    def get_sheet_data(self, sheet_name):
        return self.repo.read_sheet(sheet_name)

    def get_columns(self, sheet_name):
        return self.repo.get_columns(sheet_name)

    def add_row(self, sheet_name, row_data):
        self.repo.append_row(sheet_name, row_data)

    def update_row(self, sheet_name, row_index, updated_data):
        self.repo.update_row(sheet_name, row_index, updated_data)

    def update_row_by_id(self, sheet_name, key_column, key_value, updated_data):
        self.repo.update_row_by_id(sheet_name, key_column, key_value, updated_data)

    def delete_row(self, sheet_name, row_index):
        self.repo.delete_row(sheet_name, row_index)

    # ==============================
    # 🔍 DYNAMIC SHEET DETECTION
    # ==============================
    def get_task_sheet(self):

        for sheet in self.get_sheets():

            cols = self.get_columns(sheet)

            if "TaskID" in cols and "ProjectID" in cols:
                return sheet

        return None

    def get_project_status_sheet(self):

        for sheet in self.get_sheets():

            cols = self.get_columns(sheet)

            if (
                "ProjectID" in cols
                and "Progress" in cols
                and "AutoStatus" in cols
            ):
                return sheet

        return None

    # ==============================
    # TASK ID GENERATION
    # ==============================
    def generate_task_id(self):

        task_sheet = self.get_task_sheet()

        df = self.repo.read_sheet(task_sheet)

        if df.empty or "TaskID" not in df.columns:
            return 1

        # 🔥 SAFE conversion
        task_ids = pd.to_numeric(df["TaskID"], errors="coerce")

        task_ids = task_ids.dropna()

        if task_ids.empty:
            return 1

        return int(task_ids.max()) + 1

    # ==============================
    # 🚀 MAIN ENGINE (DYNAMIC)
    # ==============================
    def update_project_metrics(self, project_id):

        task_sheet = self.get_task_sheet()
        status_sheet = self.get_project_status_sheet()

        if not task_sheet:
            print("❌ Task sheet not found")
            return

        if not status_sheet:
            print("❌ ProjectStatus sheet not found")
            return

        # ==============================
        # LOAD FULL TASK DATA
        # ==============================
        tasks_df = self.get_sheet_data(task_sheet)

        project_col = "ProjectID"

        all_tasks = tasks_df.to_dict("records")

        # Filter only this project's tasks
        tasks = [
            t for t in all_tasks
            if str(t.get(project_col)) == str(project_id)
        ]

        if not tasks:
            return

        progress_service = ProgressService()
        status_service = ProjectStatusService()

        # ==============================
        # 1️⃣ CALCULATE PROGRESS
        # ==============================
        tasks = progress_service.calculate_task_progress(tasks)

        # ==============================
        # 🔥 SAFE MERGE BACK (CRITICAL FIX)
        # ==============================
        updated_map = {}

        for t in tasks:
            try:
                tid = int(float(t.get("TaskID")))
                updated_map[tid] = t
            except:
                continue

        for t in all_tasks:
            try:
                tid = int(float(t.get("TaskID")))
            except:
                continue

            if tid in updated_map:
                updated_task = updated_map[tid]

                # Only update Progress (safe)
                t["Progress"] = updated_task.get("Progress", t.get("Progress"))

        # Save FULL dataset (not filtered)
        updated_df = pd.DataFrame(all_tasks)

        self.repo.write_sheet(task_sheet, updated_df)

        # ==============================
        # 2️⃣ PROJECT PROGRESS
        # ==============================
        project_progress = progress_service.calculate_project_progress(tasks)

        if pd.isna(project_progress):
            project_progress = 0.0

        # ==============================
        # 3️⃣ STATUS
        # ==============================
        status = status_service.calculate_status(tasks)

        # ==============================
        # UPDATE PROJECT STATUS SHEET
        # ==============================
        status_df = self.get_sheet_data(status_sheet)

        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        # Get Project Name
        projects_df = self.get_sheet_data("Projects")

        project_name = ""

        match = projects_df[
            projects_df["ProjectID"].astype(str) == str(project_id)
        ]

        if not match.empty:
            project_name = match.iloc[0].get("ProjectName", "")

        new_row = {
            "ProjectID": project_id,
            "ProjectName": project_name,
            "Progress": project_progress,
            "AutoStatus": status,
            "LastUpdated": now
        }

        # Ensure columns exist
        for col in new_row.keys():
            if col not in status_df.columns:
                status_df[col] = ""

        existing = status_df[
            status_df["ProjectID"].astype(str) == str(project_id)
        ]

        if not existing.empty:

            idx = existing.index[0]

            for key, value in new_row.items():
                status_df.loc[idx, key] = value

        else:
            status_df = pd.concat(
                [status_df, pd.DataFrame([new_row])],
                ignore_index=True
            )

        print("📄 Writing to sheet:", status_sheet)
        print(status_df)

        self.repo.write_sheet(status_sheet, status_df)

        print(f"✅ Project {project_id} → {project_progress}% | {status}")

    def get_hierarchy_ordered_tasks(self):

        print("\n==================== START DEBUG ====================")

        task_sheet = self.get_task_sheet()
        df = self.get_sheet_data(task_sheet)

        if df.empty:
            print("❌ No task data found")
            return []

        # ==========================
        # 🔥 MERGE PROJECT NAME
        # ==========================
        projects_df = self.get_sheet_data("Projects")

        if not projects_df.empty and "ProjectName" in projects_df.columns:
            df = df.merge(
                projects_df[["ProjectID", "ProjectName"]],
                on="ProjectID",
                how="left"
            )

        # ==========================
        # 🔥 GROUP BY PROJECT
        # ==========================
        projects_map = {}

        for task in df.to_dict("records"):

            pid = str(task.get("ProjectID"))
            pname = task.get("ProjectName", "Unknown Project")

            if pid not in projects_map:
                projects_map[pid] = {
                    "ProjectName": pname,
                    "tasks": []
                }

            projects_map[pid]["tasks"].append(task)

        ordered = []

        from core.task_hierarchy import TaskHierarchyBuilder

        # ==========================
        # 🔥 PROCESS EACH PROJECT
        # ==========================
        for pid, pdata in projects_map.items():

            print(f"\n📁 Project: {pdata['ProjectName']} (ID: {pid})")

            # 1️⃣ ADD PROJECT ROW
            ordered.append({
                "TaskName": pdata["ProjectName"],
                "level": 0,
                "is_project": True
            })

            tasks = pdata["tasks"]

            print("\n--- RAW TASKS ---")
            for t in tasks:
                print(
                    "TaskID:", t.get("TaskID"),
                    "| Name:", t.get("TaskName"),
                    "| Parent:", t.get("ParentTaskID")
                )

            # ==========================
            # 🔥 FIX INVALID PARENTS
            # ==========================
            valid_task_ids = set()

            for t in tasks:
                try:
                    valid_task_ids.add(int(float(t.get("TaskID"))))
                except:
                    continue

            print("\nValid Task IDs:", valid_task_ids)

            for t in tasks:

                parent = t.get("ParentTaskID")

                try:
                    parent = int(float(parent)) if parent else None
                except:
                    parent = None

                if (
                    parent not in valid_task_ids
                    or parent == t.get("TaskID")
                ):
                    t["ParentTaskID"] = None
                else:
                    t["ParentTaskID"] = parent

            print("\n--- AFTER FIX ---")
            for t in tasks:
                print(
                    "TaskID:", t.get("TaskID"),
                    "| Name:", t.get("TaskName"),
                    "| Parent:", t.get("ParentTaskID")
                )

            # ==========================
            # 🔥 BUILD TREE
            # ==========================
            builder = TaskHierarchyBuilder()
            tree = builder.build_tree(tasks)

            # 🔥 FORCE MULTIPLE ROOTS
            if not tree or len(tree) == 1:
                tree = [t for t in tasks if t.get("ParentTaskID") is None]

            print("\n--- ROOT TASKS ---")
            for t in tree:
                print("Root:", t.get("TaskName"))

            # ==========================
            # 🔥 FLATTEN TREE
            # ==========================
            def traverse(nodes, level=1):
                for node in nodes:

                    node["level"] = level
                    ordered.append(node)

                    children = node.get("children", [])
                    if children:
                        traverse(children, level + 1)

            traverse(tree)

        print("\n--- FINAL ORDERED LIST ---")
        for t in ordered:
            print(t.get("TaskName"), "| level:", t.get("level"))

        print("==================== END DEBUG ====================\n")

        return ordered