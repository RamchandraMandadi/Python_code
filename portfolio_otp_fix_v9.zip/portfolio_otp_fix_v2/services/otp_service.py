"""
otp_service.py — OTP generation & email delivery
SMTP credentials mirrored exactly from Version_01-5Bv19 appsettings.json:
  Host : smtp3.netcore.co.in
  Port : 587  (STARTTLS)
  User : leavetracker@kmgin.in
  Pass : #9zyeCBK5lVBF00%
  From : leavetracker@kmgin.in
"""

import os
import random
import string
import smtplib
import time
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

# ─── SMTP Configuration  (from Version_01-5Bv19 / appsettings.json) ───────────
SMTP_HOST     = os.environ.get('SMTP_HOST',     'smtp3.netcore.co.in')
SMTP_PORT     = int(os.environ.get('SMTP_PORT', '587'))
SMTP_USER     = os.environ.get('SMTP_USER',     'leavetracker@kmgin.in')
SMTP_PASSWORD = os.environ.get('SMTP_PASSWORD', '#9zyeCBK5lVBF00%')
SMTP_FROM     = os.environ.get('SMTP_FROM',     'leavetracker@kmgin.in')
OTP_EXPIRY_SECONDS = 300   # 5 minutes

# ─── In-memory OTP store  { email_lower: (otp_str, expires_at_epoch) } ────────
_otp_store: dict = {}


def _generate_otp(length: int = 6) -> str:
    return ''.join(random.choices(string.digits, k=length))


def send_otp(email: str):
    """
    Generate OTP and email it via smtp3.netcore.co.in:587 (STARTTLS).
    Returns (True, '') on success or (False, error_message) on failure.
    """
    otp = _generate_otp()
    expires_at = time.time() + OTP_EXPIRY_SECONDS
    _otp_store[email.strip().lower()] = (otp, expires_at)

    # ── Build email ────────────────────────────────────────────────────────────
    msg = MIMEMultipart('alternative')
    msg['Subject'] = 'KMG Portfolio Mgmt — Your Login OTP'
    msg['From']    = SMTP_FROM
    msg['To']      = email

    plain = (
        f"Your One-Time Password (OTP) for KMG Portfolio Mgmt is:\n\n"
        f"  {otp}\n\n"
        f"This code is valid for {OTP_EXPIRY_SECONDS // 60} minutes.\n"
        f"Do not share this code with anyone."
    )
    html = f"""\
    <html><body style="font-family:Segoe UI,Arial,sans-serif;background:#f4f5f7;padding:30px;">
      <div style="max-width:480px;margin:auto;background:#fff;border-radius:10px;
                  box-shadow:0 2px 12px rgba(0,0,0,.08);padding:36px;">
        <div style="text-align:center;margin-bottom:24px;">
          <span style="font-size:28px;font-weight:800;color:#1a1a2e;letter-spacing:1px;">KMG</span>
          <span style="font-size:12px;color:#8a8a9a;display:block;margin-top:4px;">Portfolio Mgmt</span>
        </div>
        <h2 style="color:#2f5fdb;font-size:20px;margin-bottom:6px;">Your One-Time Password</h2>
        <p style="color:#555;font-size:14px;margin-bottom:24px;">
          Use the code below to complete your login. It expires in
          <strong>{OTP_EXPIRY_SECONDS // 60} minutes</strong>.
        </p>
        <div style="background:#f0f4ff;border:2px dashed #2f5fdb;border-radius:8px;
                    padding:20px;text-align:center;margin-bottom:24px;">
          <span style="font-size:40px;font-weight:900;letter-spacing:10px;color:#1a1a2e;">
            {otp}
          </span>
        </div>
        <p style="color:#999;font-size:12px;text-align:center;">
          If you did not request this, you can safely ignore this email.
        </p>
        <hr style="border:none;border-top:1px solid #eee;margin:24px 0;">
        <p style="color:#bbb;font-size:11px;text-align:center;">
          &copy; KMG Portfolio Mgmt. All Rights Reserved.
        </p>
      </div>
    </body></html>
    """
    msg.attach(MIMEText(plain, 'plain'))
    msg.attach(MIMEText(html,  'html'))

    # ── Send via STARTTLS  (same as C# SmtpClient + EnableSsl=true + port 587) ─
    try:
        with smtplib.SMTP(SMTP_HOST, SMTP_PORT, timeout=20) as server:
            server.ehlo()
            server.starttls()          # upgrade to TLS — matches EnableSsl=true
            server.ehlo()
            server.login(SMTP_USER, SMTP_PASSWORD)
            server.sendmail(SMTP_FROM, email, msg.as_string())
        print(f'[otp_service] OTP sent to {email}')
        return True, ''
    except smtplib.SMTPAuthenticationError as e:
        msg_err = f'SMTP authentication failed ({e.smtp_code}). Check credentials.'
        print(f'[otp_service] {msg_err}')
        return False, msg_err
    except smtplib.SMTPConnectError as e:
        msg_err = f'Cannot connect to {SMTP_HOST}:{SMTP_PORT}. Check network/firewall.'
        print(f'[otp_service] {msg_err}')
        return False, msg_err
    except smtplib.SMTPException as e:
        msg_err = f'SMTP error: {e}'
        print(f'[otp_service] {msg_err}')
        return False, msg_err
    except Exception as e:
        msg_err = str(e)
        print(f'[otp_service] Unexpected error: {msg_err}')
        return False, msg_err


def verify_otp(email: str, code: str):
    """
    Verify *code* for *email*.
    Returns (True, '') on success, or (False, reason_str) on failure.
    """
    key   = email.strip().lower()
    entry = _otp_store.get(key)

    if entry is None:
        return False, 'No OTP was requested for this email. Please send OTP first.'

    stored_otp, expires_at = entry

    if time.time() > expires_at:
        del _otp_store[key]
        return False, 'OTP has expired. Please request a new one.'

    if code.strip() != stored_otp:
        return False, 'Incorrect OTP. Please try again.'

    # Valid — single-use: remove it
    del _otp_store[key]
    return True, ''


def cancel_otp(email: str) -> None:
    """Discard any pending OTP for *email*."""
    _otp_store.pop(email.strip().lower(), None)
