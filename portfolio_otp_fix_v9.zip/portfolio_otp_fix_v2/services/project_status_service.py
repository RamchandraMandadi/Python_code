from datetime import datetime
import pandas as pd


class ProjectStatusService:

    def safe_date(self, value):
        """
        Safely parse EndDate — handles datetime objects, strings, and NaN.
        """
        if value is None:
            return None
        if isinstance(value, datetime):
            return value
        try:
            parsed = pd.to_datetime(value, errors="coerce")
            return parsed.to_pydatetime() if not pd.isnull(parsed) else None
        except:
            return None

    def calculate_status(self, tasks):

        today = datetime.today()

        total = len(tasks)
        delayed = 0

        for t in tasks:

            end = self.safe_date(t.get("EndDate"))
            progress = float(t.get("Progress") or 0)

            if end and progress < 100:

                if end < today:
                    delayed += 1

        if delayed > total * 0.3:
            return "Red"

        if delayed > 0:
            return "Amber"

        return "Green"