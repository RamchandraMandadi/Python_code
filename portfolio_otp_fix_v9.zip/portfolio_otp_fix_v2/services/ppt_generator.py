"""
PPT generator — opens the template PPT (which contains all the original images
and styling), inserts the user's values into the placeholder shapes, and saves
the result to the user-specified path.

This preserves all original images, icons, colors, and layout from the template
and only fills in the dynamic values.
"""
import datetime
from copy import deepcopy
from lxml import etree
from pptx import Presentation
from pptx.util import Pt, Inches
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN
from pptx.oxml.ns import qn


# ---------------------------------------------------------------------------
# Constants — mapping milestone-status text to RGB color
# ---------------------------------------------------------------------------
STATUS_RGB = {
    "On track; will complete as planned": RGBColor(0x27, 0xAE, 0x60),  # green
    "Planned delivery at risk":           RGBColor(0xF1, 0xC4, 0x0F),  # yellow
    "Will miss planned delivery":         RGBColor(0xC0, 0x39, 0x2B),  # red
    "Originally planned or completed":    RGBColor(0xBF, 0xBF, 0xBF),  # grey
}


# ---------------------------------------------------------------------------
# Generic helpers
# ---------------------------------------------------------------------------
def _set_cell_text(cell, text, font_size=None, bold=None):
    """Set the text of a table cell while preserving its first run's formatting."""
    tf = cell.text_frame
    text = "" if text is None else str(text)
    if not tf.paragraphs:
        tf.add_paragraph()
    par = tf.paragraphs[0]
    # Drop additional paragraphs to avoid stacking
    txBody = tf._txBody
    extra = txBody.findall(qn("a:p"))[1:]
    for p in extra:
        txBody.remove(p)
    if par.runs:
        par.runs[0].text = text
        for extra_run in par.runs[1:]:
            extra_run._r.getparent().remove(extra_run._r)
        if font_size is not None:
            par.runs[0].font.size = Pt(font_size)
        if bold is not None:
            par.runs[0].font.bold = bold
    else:
        run = par.add_run()
        run.text = text
        if font_size is not None:
            run.font.size = Pt(font_size)
        if bold is not None:
            run.font.bold = bold


def _replace_body_with_bullets(shape, title_text, body_lines, body_font_size=9):
    """
    For a shape whose first paragraph is the section title, keep the title
    paragraph intact and rebuild the body as new bullet lines. A smaller font
    size keeps the content inside the box.
    """
    tf = shape.text_frame
    tf.word_wrap = True

    if not tf.paragraphs:
        tf.add_paragraph()

    title_par = tf.paragraphs[0]
    body_template_p = None
    if len(tf.paragraphs) > 1:
        body_template_p = tf.paragraphs[1]

    txBody = tf._txBody
    for p in txBody.findall(qn("a:p"))[1:]:
        txBody.remove(p)

    if title_par.runs:
        title_par.runs[0].text = title_text
    else:
        run = title_par.add_run()
        run.text = title_text
        run.font.size = Pt(11)
        run.font.bold = True

    for line in body_lines:
        line = line.strip()
        if not line:
            continue
        if body_template_p is not None:
            new_p = deepcopy(body_template_p._p)
            for r in new_p.findall(qn("a:r")):
                new_p.remove(r)
            template_run = body_template_p.runs[0] if body_template_p.runs else None
            if template_run is not None:
                new_r = deepcopy(template_run._r)
                t_elem = new_r.find(qn("a:t"))
                if t_elem is None:
                    t_elem = etree.SubElement(new_r, qn("a:t"))
                t_elem.text = line
                rPr = new_r.find(qn("a:rPr"))
                if rPr is None:
                    rPr = etree.SubElement(new_r, qn("a:rPr"))
                    new_r.insert(0, rPr)
                rPr.set("sz", str(body_font_size * 100))
                new_p.append(new_r)
            else:
                new_r = etree.SubElement(new_p, qn("a:r"))
                rPr = etree.SubElement(new_r, qn("a:rPr"))
                rPr.set("sz", str(body_font_size * 100))
                t_elem = etree.SubElement(new_r, qn("a:t"))
                t_elem.text = line
            txBody.append(new_p)
        else:
            new_par = tf.add_paragraph()
            new_par.level = 0
            run = new_par.add_run()
            run.text = "• " + line
            run.font.size = Pt(body_font_size)


def _find_shape_by_text(slide, search_text):
    for shape in slide.shapes:
        if shape.has_text_frame:
            full = shape.text_frame.text.strip()
            if full.startswith(search_text):
                return shape
    return None


def _set_shape_fill_color(shape, rgb_color):
    try:
        shape.fill.solid()
        shape.fill.fore_color.rgb = rgb_color
        return True
    except Exception:
        return False


def _month_abbr_from_status(status_as_of: str) -> str:
    """Extract a 3-letter month abbreviation (e.g. 'Mar') from the
    status_as_of string. Handles 'March 2026', '13 May 2026', 'Mar 2026',
    etc. Returns '' if none of the formats match."""
    s = (status_as_of or "").strip()
    if not s:
        return ""
    for fmt in ("%B %Y", "%d %b %Y", "%d %B %Y", "%b %Y", "%B %d, %Y"):
        try:
            return datetime.datetime.strptime(s, fmt).strftime("%b")
        except Exception:
            pass
    # Last-ditch: take the first word if it looks like a month name
    first = s.split()[0]
    for fmt in ("%B", "%b"):
        try:
            return datetime.datetime.strptime(first, fmt).strftime("%b")
        except Exception:
            pass
    return ""


def _write_pill_text(shape, text: str, font_size: int = 9):
    """Replace a pill/callout shape's text with a centered, bold, white label."""
    if not shape.has_text_frame:
        return
    tf = shape.text_frame
    # remove any extra paragraphs to avoid stacking
    txBody = tf._txBody
    extras = txBody.findall(qn("a:p"))[1:]
    for p in extras:
        txBody.remove(p)
    par = tf.paragraphs[0]
    par.alignment = PP_ALIGN.CENTER
    # clear existing runs
    for r in list(par.runs):
        r._r.getparent().remove(r._r)
    run = par.add_run()
    run.text = text
    run.font.size = Pt(font_size)
    run.font.bold = True
    run.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)


# ---------------------------------------------------------------------------
# Slide 2 — Project Status Summary
# ---------------------------------------------------------------------------
def _fill_slide2(slide, data):
    shapes_list = list(slide.shapes)

    # ---- Main slide title: replace "Quincy Project Status Summary" --------
    proj_name = data.get("project_name", "").strip()
    if proj_name:
        new_title = f"{proj_name} Project Status Summary"
        for shape in shapes_list:
            if not shape.has_text_frame:
                continue
            txt = shape.text_frame.text.strip()
            if "Project Status Summary" in txt:
                tf = shape.text_frame
                par = tf.paragraphs[0]
                if par.runs:
                    par.runs[0].text = new_title
                    for extra in par.runs[1:]:
                        extra._r.getparent().remove(extra._r)
                else:
                    run = par.add_run()
                    run.text = new_title
                break

    # ---- "Project Status as of" + date -----------------------------------
    for shape in shapes_list:
        if shape.has_text_frame:
            txt = shape.text_frame.text.strip()
            if txt == "Project Status as of" or txt.startswith("Project Status as of"):
                tf = shape.text_frame
                par = tf.paragraphs[0]
                date_str = data.get("status_as_of", "").strip()
                new_text = f"Project Status as of: {date_str}" if date_str else "Project Status as of:"
                if par.runs:
                    par.runs[0].text = new_text
                    for extra in par.runs[1:]:
                        extra._r.getparent().remove(extra._r)
                else:
                    run = par.add_run()
                    run.text = new_text
                    run.font.size = Pt(12)
                break

    # ---- Recent Accomplishments ------------------------------------------
    shape = _find_shape_by_text(slide, "Recent Accomplishments")
    if shape:
        lines = [ln for ln in data["recent_accomplishments"].splitlines() if ln.strip()]
        _replace_body_with_bullets(shape, "Recent Accomplishments", lines,
                                   body_font_size=7)

    # ---- Upcoming Key Activities -----------------------------------------
    shape = _find_shape_by_text(slide, "Upcoming Key Activities")
    if shape:
        lines = [ln for ln in data["upcoming_activities"].splitlines() if ln.strip()]
        _replace_body_with_bullets(shape, "Upcoming Key Activities", lines,
                                   body_font_size=7)

    # ---- Key Risks and Issues --------------------------------------------
    shape = _find_shape_by_text(slide, "Key Risks and Issues")
    if shape:
        lines = [ln for ln in data["key_risks"].splitlines() if ln.strip()]
        _replace_body_with_bullets(shape, "Key Risks and Issues", lines,
                                   body_font_size=9)

    # ---- Mitigation Discussions ------------------------------------------
    shape = _find_shape_by_text(slide, "Mitigation Discussions")
    if shape:
        lines = [ln for ln in data["mitigation_discussions"].splitlines() if ln.strip()]
        _replace_body_with_bullets(shape, "Mitigation Discussions", lines,
                                   body_font_size=9)

    # ---- Resource Updates -------------------------------------------------
    # The template's Resource Updates shape contains placeholder text. Replace
    # it with the user's content while preserving formatting on the title word.
    ru_lines = [ln.strip() for ln in data.get("resource_updates", "").splitlines()
                if ln.strip()]
    if ru_lines:
        ru_shape = None
        for shape in shapes_list:
            if shape.has_text_frame and shape.text_frame.text.startswith("Resource Updates"):
                ru_shape = shape
                break
        if ru_shape is not None:
            tf = ru_shape.text_frame
            tf.word_wrap = True
            tf.clear()
            par = tf.paragraphs[0]
            par.alignment = PP_ALIGN.LEFT
            # Title run (bold)
            title_run = par.add_run()
            title_run.text = "Resource Updates: "
            title_run.font.bold = True
            title_run.font.size = Pt(9)
            title_run.font.color.rgb = RGBColor(0x33, 0x33, 0x33)
            # First line of content on same paragraph
            content_run = par.add_run()
            content_run.text = ru_lines[0]
            content_run.font.bold = False
            content_run.font.size = Pt(9)
            content_run.font.color.rgb = RGBColor(0x33, 0x33, 0x33)
            # Any additional lines as separate paragraphs
            for extra in ru_lines[1:]:
                p = tf.add_paragraph()
                p.alignment = PP_ALIGN.LEFT
                r = p.add_run()
                r.text = extra
                r.font.size = Pt(9)
                r.font.color.rgb = RGBColor(0x33, 0x33, 0x33)

    # ---- KEY MILESTONES: status-color the 4 small boxes at the top -------
    top_row_callouts = []
    for shape in shapes_list:
        if shape.top is None or shape.left is None:
            continue
        top_in = shape.top / 914400
        left_in = shape.left / 914400
        height_in = (shape.height or 0) / 914400
        if 1.30 <= top_in <= 1.55 and left_in < 6.0 and 0.10 <= height_in <= 0.40:
            top_row_callouts.append(shape)
    top_row_callouts.sort(key=lambda s: s.left)

    for week_idx, shape in enumerate(top_row_callouts[:4]):
        if week_idx >= len(data["milestones"]):
            break
        status = data["milestones"][week_idx]["status"]
        color = STATUS_RGB.get(status)
        if color is not None:
            _set_shape_fill_color(shape, color)
        # Write "Mar W1", "Mar W2", "Mar W3", "Mar W4" (or just "W1".."W4"
        # if the month can't be parsed out of status_as_of).
        month_abbr = _month_abbr_from_status(data.get("status_as_of", ""))
        label = f"{month_abbr} W{week_idx + 1}" if month_abbr else f"W{week_idx + 1}"
        _write_pill_text(shape, label, font_size=9)

    # ---- KEY MILESTONES: clean overlay listing the 4 milestones ----------
    km_shape = None
    for shape in shapes_list:
        if shape.has_text_frame and shape.text_frame.text.strip() == "KEY MILESTONES":
            km_shape = shape
            break

    if km_shape:
        # Place an overlay text box inside the milestone area, below the top
        # callout row. Approx panel coords: left=0.50", top=1.65", width=5.40",
        # height=1.25".
        txbox = slide.shapes.add_textbox(
            Inches(0.55), Inches(1.78), Inches(5.30), Inches(1.20)
        )
        tf = txbox.text_frame
        tf.word_wrap = True
        first = True
        for i, m in enumerate(data["milestones"]):
            txt = m.get("text", "").strip()
            if not txt:
                continue
            if first:
                par = tf.paragraphs[0]
                first = False
            else:
                par = tf.add_paragraph()
            color = STATUS_RGB.get(m["status"], RGBColor(0xBF, 0xBF, 0xBF))
            dot_run = par.add_run()
            dot_run.text = "● "
            dot_run.font.size = Pt(11)
            dot_run.font.color.rgb = color
            label_run = par.add_run()
            label_run.text = f"Week {i+1}: "
            label_run.font.size = Pt(9)
            label_run.font.bold = True
            label_run.font.color.rgb = RGBColor(0x1F, 0x38, 0x64)
            txt_run = par.add_run()
            txt_run.text = txt
            txt_run.font.size = Pt(9)
            txt_run.font.color.rgb = RGBColor(0x33, 0x33, 0x33)

    # ---- SUMMARY content overlay -----------------------------------------
    if data.get("summary", "").strip():
        sum_box = slide.shapes.add_textbox(
            Inches(5.98), Inches(1.42), Inches(3.50), Inches(1.00)
        )
        tf = sum_box.text_frame
        tf.word_wrap = True
        first = True
        for line in data["summary"].splitlines():
            line = line.strip()
            if not line:
                continue
            if first:
                par = tf.paragraphs[0]
                first = False
            else:
                par = tf.add_paragraph()
            run = par.add_run()
            run.text = line
            run.font.size = Pt(9)
            run.font.color.rgb = RGBColor(0x33, 0x33, 0x33)


# ---------------------------------------------------------------------------
# Slide 3 — SUMMARY (volume of work) table
# ---------------------------------------------------------------------------
def _fill_slide3(slide, data):
    table_shape = None
    for shape in slide.shapes:
        if shape.has_table:
            table_shape = shape
            break
    if table_shape is None:
        return
    tbl = table_shape.table

    for r in range(4):
        wk = data["weeks"][r]
        _set_cell_text(tbl.cell(r + 1, 1), wk.get("total_amount", ""), font_size=11)
        _set_cell_text(tbl.cell(r + 1, 2), wk.get("onshore", ""),       font_size=11)
        _set_cell_text(tbl.cell(r + 1, 3), wk.get("offshore", ""),      font_size=11)
        _set_cell_text(tbl.cell(r + 1, 4), wk.get("total_hours", ""),   font_size=11)

    total = data.get("total_row", {})
    _set_cell_text(tbl.cell(5, 1), total.get("total_amount", ""), font_size=11, bold=True)
    _set_cell_text(tbl.cell(5, 2), total.get("onshore", ""),       font_size=11, bold=True)
    _set_cell_text(tbl.cell(5, 3), total.get("offshore", ""),      font_size=11, bold=True)
    _set_cell_text(tbl.cell(5, 4), total.get("total_hours", ""),   font_size=11, bold=True)

    vd_shape = _find_shape_by_text(slide, "* Value Delivered")
    if vd_shape and data.get("value_delivered", "").strip():
        tf = vd_shape.text_frame
        tf.word_wrap = True
        for line in data["value_delivered"].splitlines():
            line = line.strip()
            if not line:
                continue
            par = tf.add_paragraph()
            run = par.add_run()
            run.text = line
            run.font.size = Pt(10)
            run.font.color.rgb = RGBColor(0x33, 0x33, 0x33)


# ---------------------------------------------------------------------------
# Slide 1 — Cover slide (replace "Quincy" with selected project name)
# ---------------------------------------------------------------------------
def _fill_slide1(slide, data):
    """
    Replace every run containing 'Quincy' on the cover slide with the actual
    project name. The template title is split across three runs:
      run0 = 'Quincy Modernization '  run1 = 'Program '  run2 = '– Development '
    This patches whichever run(s) hold the placeholder word.
    """
    proj_name = data.get("project_name", "").strip()
    if not proj_name:
        return
    for shape in slide.shapes:
        if not shape.has_text_frame:
            continue
        if "Quincy" not in shape.text_frame.text:
            continue
        for par in shape.text_frame.paragraphs:
            for run in par.runs:
                if "Quincy" in run.text:
                    run.text = run.text.replace("Quincy", proj_name)


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------
def generate_status_ppt(template_path: str, output_path: str, data: dict) -> str:
    """Open the template, fill in data, save to output_path."""
    prs = Presentation(template_path)
    slides = list(prs.slides)
    if len(slides) >= 1:
        _fill_slide1(slides[0], data)
    if len(slides) >= 2:
        _fill_slide2(slides[1], data)
    if len(slides) >= 3:
        _fill_slide3(slides[2], data)
    prs.save(output_path)
    return output_path
