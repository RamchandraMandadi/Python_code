"""
ppt_data_builder.py
-------------------
Builds the data dict that ppt_generator.py expects, using ONLY the data
already present in pm_final's `input/project_data.xlsx` workbook.

The output dict shape mirrors the one used by the KMG Project Status app:

    {
      'status_as_of':            "January 2025",
      'milestones':              [ {text, status} × 4 ],
      'summary':                 str,
      'resource_updates':        str,
      'recent_accomplishments':  str,   # newline separated bullets
      'upcoming_activities':     str,
      'key_risks':               str,
      'mitigation_discussions':  str,
      'weeks':                   [ {total_amount, onshore, offshore, total_hours} × 4 ],
      'total_row':               {total_amount, onshore, offshore, total_hours},
      'value_delivered':         str,
    }

All data is filtered by the selected ProjectID and Month (e.g. "2025-01").
"""
from __future__ import annotations

import datetime
from pathlib import Path
from typing import Optional

import pandas as pd

from config.settings import Settings


# Status text used by ppt_generator.STATUS_RGB
STATUS_GREEN  = "On track; will complete as planned"
STATUS_AMBER  = "Planned delivery at risk"
STATUS_RED    = "Will miss planned delivery"
STATUS_GREY   = "Originally planned or completed"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _safe_str(v, default: str = "") -> str:
    if v is None:
        return default
    try:
        if pd.isna(v):
            return default
    except Exception:
        pass
    s = str(v).strip()
    return default if s.lower() in ("nan", "nat", "none", "null") else s


def _safe_num(v, default: float = 0.0) -> float:
    try:
        if v is None or (isinstance(v, float) and pd.isna(v)):
            return default
        return float(v)
    except Exception:
        return default


def _fmt_date(v) -> str:
    if v is None:
        return ""
    try:
        if pd.isna(v):
            return ""
    except Exception:
        pass
    if hasattr(v, "strftime"):
        try:
            return v.strftime("%Y-%m-%d")
        except Exception:
            pass
    s = str(v)
    return s[:10] if len(s) >= 10 else s


def _week_status_to_milestone_text(status: str) -> str:
    """Map pm_final WeeklyStatus values to the milestone status labels."""
    s = (status or "").strip().lower()
    if s in ("done", "complete", "completed"):
        return STATUS_GREEN
    if s == "at risk":
        return STATUS_RED
    if s in ("in progress", "inprogress"):
        return STATUS_AMBER
    # 'planned', 'not started', or empty
    return STATUS_GREY


def _task_status_to_milestone_text(status: str, end_date) -> str:
    """Map Tasks-sheet Status into milestone status, considering overdue."""
    s = (status or "").strip().lower()
    if s in ("completed", "done", "complete"):
        return STATUS_GREEN
    # If end-date is past and not completed → red
    try:
        d = pd.to_datetime(end_date, errors="coerce")
        if not pd.isna(d) and d.date() < datetime.date.today():
            return STATUS_RED
    except Exception:
        pass
    if s == "at risk":
        return STATUS_RED
    if s in ("in progress", "inprogress"):
        return STATUS_AMBER
    return STATUS_GREY


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------
class PPTDataBuilder:
    """
    Loads `input/project_data.xlsx` once per instance, then exposes methods
    to list projects / months and to build the PPT data dict for a chosen
    (ProjectID, Month) combination.
    """

    SHEETS = ("Projects", "Tasks", "RAG", "ProjectStatus", "WeeklyStatus")

    def __init__(self, excel_path: Optional[Path] = None):
        self.path = Path(excel_path) if excel_path else Settings.EXCEL_FILE
        self._data: dict[str, pd.DataFrame] = {}
        self.reload()

    # ------------------------------------------------------------------ data
    def reload(self):
        """Re-read every sheet from disk."""
        self._data = {}
        try:
            xl = pd.ExcelFile(self.path)
        except Exception as e:
            print(f"[PPTDataBuilder] Cannot open {self.path}: {e}")
            return
        for sheet in self.SHEETS:
            if sheet in xl.sheet_names:
                try:
                    self._data[sheet] = pd.read_excel(xl, sheet_name=sheet)
                except Exception as e:
                    print(f"[PPTDataBuilder] Error reading {sheet}: {e}")
                    self._data[sheet] = pd.DataFrame()
            else:
                self._data[sheet] = pd.DataFrame()

    def _df(self, sheet: str) -> pd.DataFrame:
        return self._data.get(sheet, pd.DataFrame())

    # ------------------------------------------------------------------ lists
    def list_projects(self) -> list[tuple[str, str]]:
        """Return [(ProjectID, ProjectName), ...]"""
        df = self._df("Projects")
        if df.empty or "ProjectID" not in df.columns:
            return []
        out = []
        for _, r in df.iterrows():
            pid  = _safe_str(r.get("ProjectID"))
            name = _safe_str(r.get("ProjectName"), pid)
            if pid:
                out.append((pid, name))
        return out

    def list_months(self, project_id: str) -> list[tuple[str, str]]:
        """Return [(Month, MonthLabel), ...] for the given project, sorted."""
        df = self._df("WeeklyStatus")
        if df.empty or "Month" not in df.columns:
            return []
        mdf = df[df["ProjectID"].astype(str) == str(project_id)]
        if mdf.empty:
            return []
        uniq = (mdf.drop_duplicates("Month")
                  .sort_values("Month")[["Month", "MonthLabel"]])
        return [(_safe_str(m), _safe_str(lbl) or _safe_str(m))
                for m, lbl in uniq.values.tolist()]

    # ------------------------------------------------------------------ build
    def build(self, project_id: str, month: str) -> dict:
        """
        Build the full PPT data dict for the given project + month.
        `month` is a value from the Month column (e.g. "2025-01").
        """
        project_id = str(project_id)
        proj_row   = self._project_row(project_id)
        proj_name  = _safe_str(proj_row.get("ProjectName"), project_id)

        # Weeks for this month
        weekly = self._df("WeeklyStatus")
        if not weekly.empty:
            m_df = weekly[(weekly["ProjectID"].astype(str) == project_id) &
                          (weekly["Month"].astype(str) == str(month))]
            m_df = m_df.sort_values("WeekNo")
        else:
            m_df = pd.DataFrame()

        month_label = (_safe_str(m_df["MonthLabel"].iloc[0])
                       if not m_df.empty and "MonthLabel" in m_df.columns
                       else _safe_str(month))

        # 1) MILESTONES — 4 weekly slots
        milestones = self._build_milestones(m_df)

        # 2) SUMMARY
        summary = self._build_summary(proj_row, m_df, proj_name, month_label)

        # 3) RESOURCE UPDATES
        resource_updates = self._build_resource_updates(proj_row, m_df)

        # 4) RECENT ACCOMPLISHMENTS
        recent_accomplishments = self._build_recent_accomplishments(
            project_id, m_df)

        # 5) UPCOMING KEY ACTIVITIES
        upcoming_activities = self._build_upcoming_activities(project_id)

        # 6) KEY RISKS AND ISSUES
        key_risks = self._build_key_risks(project_id)

        # 7) MITIGATION DISCUSSIONS
        mitigation = self._build_mitigation(project_id)

        # 8) VOLUME OF WORK (weeks + totals)
        weeks_block, total_row = self._build_volume_of_work(m_df)

        # 9) VALUE DELIVERED
        value_delivered = self._build_value_delivered(
            project_id, m_df, proj_name, month_label)

        return {
            "project_name":           proj_name,
            "status_as_of":           month_label,
            "milestones":             milestones,
            "summary":                summary,
            "resource_updates":       resource_updates,
            "recent_accomplishments": recent_accomplishments,
            "upcoming_activities":    upcoming_activities,
            "key_risks":              key_risks,
            "mitigation_discussions": mitigation,
            "weeks":                  weeks_block,
            "total_row":              total_row,
            "value_delivered":        value_delivered,
        }

    # ------------------------------------------------------------------ pieces
    def _project_row(self, project_id: str) -> dict:
        df = self._df("Projects")
        if df.empty:
            return {}
        rows = df[df["ProjectID"].astype(str) == str(project_id)]
        return rows.iloc[0].to_dict() if not rows.empty else {}

    def _build_milestones(self, weekly_df: pd.DataFrame) -> list[dict]:
        """Return 4 milestone dicts. Pads with empty/grey if fewer.

        Note: do NOT include a 'Week N:' prefix in the text — both
        ppt_generator.py and ppt_slide_view.py already prepend that label
        when rendering, so adding it here causes a 'Week 1: Week 1: …'
        duplication.
        """
        out: list[dict] = []
        if not weekly_df.empty:
            for _, r in weekly_df.iterrows():
                if len(out) >= 4:
                    break
                desc   = _safe_str(r.get("Description"))
                status = _safe_str(r.get("Status"))
                out.append({
                    "text":   desc,
                    "status": _week_status_to_milestone_text(status),
                })
        # Pad to 4
        while len(out) < 4:
            out.append({
                "text":   "",
                "status": STATUS_GREY,
            })
        return out

    def _build_summary(self, proj_row: dict, weekly_df: pd.DataFrame,
                       proj_name: str, month_label: str) -> str:
        lines = []
        client     = _safe_str(proj_row.get("Client"))
        department = _safe_str(proj_row.get("Department"))
        manager    = _safe_str(proj_row.get("Manager"))
        priority   = _safe_str(proj_row.get("Priority"))

        head = f"{proj_name} — {month_label}"
        if client:
            head += f" · Client: {client}"
        lines.append(head)

        meta = []
        if manager:    meta.append(f"PM: {manager}")
        if department: meta.append(f"Dept: {department}")
        if priority:   meta.append(f"Priority: {priority}")
        if meta:
            lines.append(" | ".join(meta))

        # Month roll-up
        if not weekly_df.empty:
            total_hrs = int(weekly_df.get("HoursLogged", pd.Series()).sum() or 0)
            total_sp  = float(weekly_df.get("WeeklySpend", pd.Series()).sum() or 0.0)
            done_ct   = int((weekly_df.get("Status") == "Done").sum())
            wk_ct     = len(weekly_df)
            lines.append(
                f"{done_ct}/{wk_ct} weeks delivered · "
                f"{total_hrs:,} hrs logged · ${total_sp:,.0f} spent"
            )

        # Budget context (project-level)
        budget = _safe_num(proj_row.get("Budget"))
        spent  = _safe_num(proj_row.get("Spent"))
        if budget > 0:
            pct = (spent / budget) * 100
            lines.append(
                f"Budget: ${spent:,.0f} of ${budget:,.0f} used ({pct:.0f}%)"
            )

        desc = _safe_str(proj_row.get("Description"))
        if desc:
            lines.append(desc)

        return "\n".join(lines)

    def _build_resource_updates(self, proj_row: dict,
                                weekly_df: pd.DataFrame) -> str:
        lines = []
        manager = _safe_str(proj_row.get("Manager"))
        if manager:
            lines.append(f"Project Manager: {manager}")

        if not weekly_df.empty:
            total_hrs = int(weekly_df.get("HoursLogged", pd.Series()).sum() or 0)
            wk_ct     = len(weekly_df)
            avg       = total_hrs / wk_ct if wk_ct else 0
            lines.append(
                f"Effort this month: {total_hrs:,} hrs across {wk_ct} weeks "
                f"(avg {avg:.0f} hrs/week)."
            )

        return "\n".join(lines) if lines else "No resource updates."

    def _build_recent_accomplishments(self, project_id: str,
                                      weekly_df: pd.DataFrame) -> str:
        """
        Combine:
          (a) completed tasks for this project (most recent EndDate first), and
          (b) WeeklyStatus rows with Status='Done' for the chosen month.
        """
        out: list[str] = []

        # (a) Completed tasks
        tdf = self._df("Tasks")
        if not tdf.empty and "Status" in tdf.columns:
            cdf = tdf[(tdf["ProjectID"].astype(str) == project_id) &
                      (tdf["Status"].astype(str).str.lower() == "completed")]
            if "EndDate" in cdf.columns:
                cdf = cdf.sort_values("EndDate", ascending=False)
            for _, r in cdf.head(6).iterrows():
                tn = _safe_str(r.get("TaskName"))
                ph = _safe_str(r.get("Phase"))
                ed = _fmt_date(r.get("EndDate"))
                line = tn
                if ph:
                    line += f" ({ph})"
                if ed:
                    line += f" — completed {ed}"
                out.append(line)

        # (b) Done weeks this month
        if not weekly_df.empty:
            done = weekly_df[weekly_df["Status"].astype(str) == "Done"]
            for _, r in done.iterrows():
                wk = _safe_str(r.get("WeekLabel"))
                d  = _safe_str(r.get("Description"))
                if d:
                    out.append(f"{wk}: {d}" if wk else d)

        if not out:
            return "No recent accomplishments to report."
        return "\n".join(out[:8])

    def _build_upcoming_activities(self, project_id: str) -> str:
        tdf = self._df("Tasks")
        if tdf.empty:
            return "No upcoming activities."
        adf = tdf[(tdf["ProjectID"].astype(str) == project_id) &
                  (tdf["Status"].astype(str).str.lower()
                       .isin(["in progress", "not started", "at risk"]))]
        if "StartDate" in adf.columns:
            adf = adf.sort_values("StartDate")
        out = []
        for _, r in adf.head(8).iterrows():
            tn  = _safe_str(r.get("TaskName"))
            ph  = _safe_str(r.get("Phase"))
            st  = _safe_str(r.get("Status"))
            sd  = _fmt_date(r.get("StartDate"))
            ed  = _fmt_date(r.get("EndDate"))
            prg = _safe_num(r.get("Progress"))
            line = tn
            if ph:    line += f" ({ph})"
            if st:    line += f" — {st}"
            if prg:   line += f", {int(prg)}%"
            if sd or ed:
                line += f" [{sd} → {ed}]"
            out.append(line)
        return "\n".join(out) if out else "No upcoming activities."

    def _build_key_risks(self, project_id: str) -> str:
        rag = self._df("RAG")
        if rag.empty:
            return ""
        r = rag[(rag["ProjectID"].astype(str) == project_id) &
                (rag["Status"].astype(str).str.upper() == "R")]
        out = []
        for _, row in r.iterrows():
            asp = _safe_str(row.get("Aspect"))
            exp = _safe_str(row.get("Explanation"))
            out.append(f"{asp}: {exp}" if exp else asp)
        return "\n".join(out) if out else "No critical risks."

    def _build_mitigation(self, project_id: str) -> str:
        """Amber items become mitigation discussions."""
        rag = self._df("RAG")
        if rag.empty:
            return ""
        a = rag[(rag["ProjectID"].astype(str) == project_id) &
                (rag["Status"].astype(str).str.upper() == "A")]
        out = []
        for _, row in a.iterrows():
            asp = _safe_str(row.get("Aspect"))
            exp = _safe_str(row.get("Explanation"))
            out.append(f"{asp}: {exp}" if exp else asp)
        return "\n".join(out) if out else "All aspects on track — no mitigation needed."

    def _build_volume_of_work(self, weekly_df: pd.DataFrame
                              ) -> tuple[list[dict], dict]:
        """
        Volume of work table — 4 rows + totals.
            total_amount → WeeklySpend (formatted)
            total_hours  → HoursLogged
            onshore/offshore → 50/50 split of HoursLogged (pm_final has no
                              onshore/offshore column).
        """
        weeks: list[dict] = []
        running_hrs = 0
        running_sp  = 0.0
        running_on  = 0
        running_off = 0

        # Take first 4 weeks sorted by WeekNo
        if not weekly_df.empty:
            wks = weekly_df.sort_values("WeekNo").head(4)
        else:
            wks = pd.DataFrame()

        for i in range(4):
            if i < len(wks):
                r = wks.iloc[i]
                hrs = int(_safe_num(r.get("HoursLogged")))
                sp  = _safe_num(r.get("WeeklySpend"))
                on  = hrs // 2
                off = hrs - on
                weeks.append({
                    "total_amount": f"${sp:,.0f}" if sp else "$0",
                    "onshore":      str(on),
                    "offshore":     str(off),
                    "total_hours":  str(hrs),
                })
                running_hrs += hrs
                running_sp  += sp
                running_on  += on
                running_off += off
            else:
                weeks.append({
                    "total_amount": "",
                    "onshore":      "",
                    "offshore":     "",
                    "total_hours":  "",
                })

        total_row = {
            "total_amount": f"${running_sp:,.0f}",
            "onshore":      str(running_on),
            "offshore":     str(running_off),
            "total_hours":  str(running_hrs),
        }
        return weeks, total_row

    def _build_value_delivered(self, project_id: str,
                               weekly_df: pd.DataFrame,
                               proj_name: str,
                               month_label: str) -> str:
        # Count completed tasks this month + completed weekly statuses
        done_weeks = 0
        if not weekly_df.empty:
            done_weeks = int((weekly_df["Status"] == "Done").sum())

        tdf = self._df("Tasks")
        comp_tasks = 0
        if not tdf.empty:
            ctdf = tdf[(tdf["ProjectID"].astype(str) == project_id) &
                       (tdf["Status"].astype(str).str.lower() == "completed")]
            comp_tasks = len(ctdf)

        total_sp  = 0.0
        total_hrs = 0
        if not weekly_df.empty:
            total_sp  = float(weekly_df.get("WeeklySpend", pd.Series()).sum() or 0.0)
            total_hrs = int(weekly_df.get("HoursLogged", pd.Series()).sum() or 0)

        return (
            f"{proj_name} — {month_label}: {done_weeks} week(s) delivered "
            f"on plan with {total_hrs:,} hrs of effort (${total_sp:,.0f}). "
            f"Project-to-date: {comp_tasks} task(s) completed."
        )
