"""
login_window.py — KMG Portfolio Mgmt Login  (Dual-Mode Edition)

MODE A — Password Login (Option 1):
    • Email/Username + Password fields + blue Login button
    • Hidden: OTP button
    • Link below: "Login with OTP instead →"

MODE B — OTP Email Login (Option 2):
    • Email field ONLY (no password) + green Login with OTP button
    • Hidden: password field and blue Login button
    • OTP is sent to the registered email for that account
    • Link below: "← Login with Password instead"
"""

import tkinter as tk
from tkinter import Canvas
import os
import threading
from PIL import Image, ImageTk
from openpyxl import load_workbook
import datetime

import sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
from services.otp_service import send_otp, verify_otp, cancel_otp

# ─── Colours ──────────────────────────────────────────────────────────────────
C = {
    'left_bg':    '#3f3d56',
    'right_bg':   '#ffffff',
    'right_text': '#1a1a1a',
    'right_sub':  '#8a8a9a',
    'input_bg':   '#ffffff',
    'input_fg':   '#333333',
    'input_ph':   '#9a9aa5',
    'btn_bg':     '#2f5fdb',
    'btn_hover':  '#2750ba',
    'otp_btn_bg': '#10b981',
    'otp_btn_hov':'#059669',
    'div_line':   '#e2e2e8',
    'div_txt':    '#9a9aa5',
    'ms_bd':      '#d8dae0',
    'copy_fg':    '#b0b0bb',
    'error':      '#ef4444',
    'success':    '#10b981',
    'logo_orange':'#e8862d',
    'logo_blue':  '#3d4a8a',
    'logo_green': '#5a9b6e',
    'switch_fg':  '#2f5fdb',
}

XLSX = os.path.join(os.path.dirname(__file__), '..', 'input', 'project_data.xlsx')
LOGO = os.path.join(os.path.dirname(__file__), '..', 'assets', 'images', 'kmg-logo.png')


# ─── Excel helpers ─────────────────────────────────────────────────────────────
def _load_users():
    by_uname, by_email = {}, {}
    try:
        wb = load_workbook(XLSX, read_only=True, data_only=True)
        if 'Users' not in wb.sheetnames:
            return by_uname, by_email
        ws = wb['Users']
        headers = None
        for row in ws.iter_rows(values_only=True):
            if headers is None:
                headers = [str(h).strip() if h else '' for h in row]
                continue
            if not row or row[0] is None:
                continue
            d = dict(zip(headers, row))
            uname = str(d.get('Username', '')).strip().lower()
            email  = str(d.get('Email',    '')).strip().lower()
            if not uname:
                continue
            record = {
                'username':  uname,
                'email':     str(d.get('Email', '')).strip(),
                'password':  str(d.get('Password', '')).strip(),
                'role':      str(d.get('Role', 'Viewer')).strip(),
                'full_name': str(d.get('FullName', '')).strip(),
                'is_active': str(d.get('IsActive', 'True')).strip() in ('True','TRUE','1','true'),
            }
            by_uname[uname] = record
            if email:
                by_email[email] = record
    except Exception as e:
        print(f'[login] _load_users error: {e}')
    return by_uname, by_email


def _find_user(input_str):
    key = input_str.strip().lower()
    by_uname, by_email = _load_users()
    return by_uname.get(key) or by_email.get(key)


def _update_last_login(username):
    try:
        wb = load_workbook(XLSX)
        ws = wb['Users']
        headers = [str(c.value).strip() if c.value else '' for c in ws[1]]
        ucol = headers.index('Username') + 1
        lcol = headers.index('LastLogin') + 1
        for row in ws.iter_rows(min_row=2):
            if str(row[ucol-1].value).strip().lower() == username.lower():
                row[lcol-1].value = datetime.datetime.now().strftime('%Y-%m-%d %H:%M')
                break
        wb.save(XLSX)
    except Exception as e:
        print(f'[login] _update_last_login error: {e}')


# ─── LoginWindow ───────────────────────────────────────────────────────────────
class LoginWindow:

    MODE_PASSWORD = 'password'
    MODE_OTP      = 'otp'

    def __init__(self, root, on_success):
        self.root           = root
        self.on_success     = on_success
        self._mode          = self.MODE_PASSWORD
        self._verified_user = None
        self._otp_email     = ''

        self.root.title('KMG Portfolio Mgmt — Login')
        self.root.geometry('1100x680')
        self.root.minsize(880, 560)
        self.root.configure(bg=C['left_bg'])
        self.root.resizable(True, True)
        self._set_window_icon()
        self._build()

    def _set_window_icon(self):
        try:
            pil_icon = Image.open(LOGO).convert('RGBA')
            self._win_icon = ImageTk.PhotoImage(pil_icon)
            self.root.iconphoto(True, self._win_icon)
        except Exception:
            pass

    # ── Layout ─────────────────────────────────────────────────────────────────
    def _build(self):
        outer = tk.Frame(self.root, bg=C['left_bg'])
        outer.pack(fill='both', expand=True)
        self._left  = tk.Frame(outer, bg=C['left_bg'])
        self._right = tk.Frame(outer, bg=C['right_bg'])
        self._left.pack(side='left',  fill='both', expand=True)
        self._right.pack(side='right', fill='both', expand=False)
        self.root.bind('<Configure>', self._on_resize)
        self._build_left(self._left)
        self._build_right(self._right)

    def _on_resize(self, event=None):
        w = self.root.winfo_width()
        right_w = max(380, int(w * 0.40))
        self._left.config(width=w - right_w)
        self._right.config(width=right_w)
        self._left.pack_propagate(False)
        self._right.pack_propagate(False)
        if hasattr(self, '_svg_canvas'):
            self._svg_canvas.config(width=w - right_w, height=self.root.winfo_height())
            self._draw_svg(self._svg_canvas)

    # ── LEFT PANEL ─────────────────────────────────────────────────────────────
    def _build_left(self, parent):
        feat_strip = tk.Frame(parent, bg=C['left_bg'])
        feat_strip.pack(side='bottom', fill='x', padx=44, pady=(0, 24))
        tk.Frame(feat_strip, bg='#55536a', height=1).pack(fill='x', pady=(0, 12))
        for icon, feat_text in [
            ('📊', 'Real-time RAG Status Dashboard'),
            ('📁', 'Portfolio-wide Project Visibility'),
            ('📅', 'Gantt Timeline & Milestones'),
            ('🔒', 'Role-based Access Control'),
            ('📈', 'Budget & Progress Analytics'),
        ]:
            row = tk.Frame(feat_strip, bg=C['left_bg'])
            row.pack(anchor='w', pady=5)
            tk.Label(row, text=icon, font=('Segoe UI', 13),
                     bg=C['left_bg'], fg='#a5b4fc').pack(side='left', padx=(0, 12))
            tk.Label(row, text=feat_text, font=('Segoe UI', 10, 'bold'),
                     bg=C['left_bg'], fg='#c8d8f0').pack(side='left')

        self._svg_canvas = Canvas(parent, bg=C['left_bg'], highlightthickness=0, bd=0)
        self._svg_canvas.pack(side='top', fill='both', expand=True)
        parent.update_idletasks()
        self._draw_svg(self._svg_canvas)

    def _draw_svg(self, cv):
        cv.delete('all')
        W = cv.winfo_width()  or 660
        H = cv.winfo_height() or 680
        sx = W / 1138; sy = H / 868
        def x(v): return int(v * sx)
        def y(v): return int(v * sy)
        def r(v): return max(1, int(v * min(sx, sy)))

        for cx in [575, 590, 605, 620]:
            for cy in [113, 128, 143, 158]:
                cv.create_oval(x(cx)-r(2), y(cy)-r(2), x(cx)+r(2), y(cy)+r(2), fill='#55536a', outline='')
        for rad in [20, 40, 60, 80]:
            cv.create_oval(x(690)-r(rad), y(280)-r(rad), x(690)+r(rad), y(280)+r(rad), outline='#c97b3d', width=1, fill='')
        for rad in [20, 40, 60, 80]:
            cv.create_oval(x(500)-r(rad), y(660)-r(rad), x(500)+r(rad), y(660)+r(rad), outline='#4f7a5e', width=1, fill='')
        for bx, by, bh, col in [(135,350,170,'#5a6cc4'),(158,380,140,'#e8e8f0'),
                                 (181,400,120,'#e8862d'),(204,430,90,'#e8e8f0'),
                                 (227,370,150,'#5a9b6e'),(250,455,65,'#e8e8f0')]:
            cv.create_rectangle(x(bx), y(by), x(bx+14), y(by+bh), fill=col, outline='')
        pts = [x(120),y(360), x(180),y(320), x(220),y(345), x(290),y(300), x(360),y(280)]
        cv.create_line(pts, fill='#e8e8f0', width=max(1,r(2)), smooth=True)
        px, py = x(875), y(545); pr = r(75)
        cv.create_arc(px-pr, py-pr, px+pr, py+pr, start=90,  extent=-108, fill='#e8862d', outline='')
        cv.create_arc(px-pr, py-pr, px+pr, py+pr, start=-18, extent=-252, fill='#5a6cc4', outline='')
        clx, cly = x(367), y(357); cr_outer = r(55); cr_inner = r(32)
        cv.create_oval(clx-cr_outer, cly-cr_outer, clx+cr_outer, cly+cr_outer, fill='white', outline='#e3e3e8', width=1)
        cv.create_oval(clx-cr_inner, cly-cr_inner, clx+cr_inner, cly+cr_inner, fill='#dde6f5', outline='#5a6cc4', width=max(1,r(2)))
        cv.create_line(clx, cly, clx, cly-r(18), fill='#3f3d56', width=max(1,r(2.5)), capstyle='round')
        cv.create_line(clx, cly, clx+r(13), cly+r(6), fill='#3f3d56', width=max(1,r(2.5)), capstyle='round')
        cv.create_oval(clx-r(2.5), cly-r(2.5), clx+r(2.5), cly+r(2.5), fill='#3f3d56', outline='')
        cv.create_rectangle(x(397), y(358), x(789), y(606), fill='white', outline='', width=0)
        sdx = x(467)
        cv.create_line(sdx, y(385), sdx, y(585), fill='#eeeef2', width=1)
        icon_ys = [y(392), y(441), y(480), y(520), y(562)]
        cv.create_rectangle(x(421), y(392), x(443), y(412), outline='#9a9aae', width=1, fill='')
        for iy in icon_ys[1:]:
            cv.create_oval(x(423), iy-r(9), x(441), iy+r(9), outline='#9a9aae', width=1, fill='')
        for ry in [y(399), y(432), y(465), y(498)]:
            cv.create_line(x(500), ry+r(4), x(504), ry+r(8), fill='#5a9b6e', width=max(1,r(2)))
            cv.create_line(x(504), ry+r(8), x(512), ry-r(1), fill='#5a9b6e', width=max(1,r(2)))
            cv.create_rectangle(x(525), ry-r(3), x(765), ry+r(3), fill='#e8e8f0', outline='')
        for bx, col in [(500,'#5a6cc4'),(572,'#e8862d'),(644,'#5a9b6e')]:
            cv.create_rectangle(x(bx), y(525), x(bx+60), y(571), fill=col, outline='')
        cv.create_rectangle(x(699), y(307), x(879), y(477), fill='white', outline='#eaeaef', width=1)
        cv.create_rectangle(x(730), y(320), x(846), y(328), fill='#eeeef2', outline='')
        cv.create_rectangle(x(711), y(364), x(869), y(380), fill='#f7d3ce', outline='')
        cv.create_rectangle(x(711), y(386), x(869), y(402), fill='#f7d3ce', outline='')
        for dx, dl in zip([722,744,766,788,809,831,853], ['M','T','W','T','F','S','S']):
            cv.create_text(x(dx), y(355), text=dl, fill='#9a9aae', font=('Arial', max(6, r(7))))
        for row_idx in range(4):
            for col_idx, nx in enumerate([722,744,766,788,809,831,853]):
                num = row_idx * 7 + col_idx + 1
                if num > 31: break
                ny = y(375 + row_idx * 22)
                if num in (3, 12):
                    cv.create_oval(x(nx)-r(7), ny-r(7), x(nx)+r(7), ny+r(7), fill='#e15b4f', outline='')
                    cv.create_text(x(nx), ny, text=str(num), fill='white', font=('Arial', max(6, r(7))))
                else:
                    cv.create_text(x(nx), ny, text=str(num), fill='#5a5a68', font=('Arial', max(6, r(7))))

    # ── RIGHT PANEL wrapper ─────────────────────────────────────────────────────
    def _build_right(self, parent):
        self._wrap = tk.Frame(parent, bg=C['right_bg'])
        self._wrap.place(relx=0.5, rely=0.5, anchor='center')
        self._render_step1()

    # ══════════════════════════════════════════════════════════════════════════════
    # STEP 1 — dual-mode form
    # ══════════════════════════════════════════════════════════════════════════════
    def _render_step1(self):
        wrap = self._wrap
        for w in wrap.winfo_children():
            w.destroy()

        # ── Logo ───────────────────────────────────────────────────────────────
        logo_row = tk.Frame(wrap, bg=C['right_bg'])
        logo_row.pack(pady=(0, 14))
        try:
            pil_img = Image.open(LOGO).convert('RGBA')
            bg_img  = Image.new('RGBA', pil_img.size, (255,255,255,255))
            bg_img.paste(pil_img, mask=pil_img.split()[3])
            nh = 48; nw = int(pil_img.width * nh / pil_img.height)
            bg_img = bg_img.resize((nw, nh), Image.LANCZOS)
            self._logo_img = ImageTk.PhotoImage(bg_img)
            tk.Label(logo_row, image=self._logo_img, bg=C['right_bg']).pack(side='left')
        except Exception:
            lc = tk.Canvas(logo_row, width=38, height=38, bg=C['right_bg'], highlightthickness=0)
            lc.pack(side='left', padx=(0, 6))
            lc.create_rectangle(0,  0, 17, 17, fill=C['logo_orange'], outline='')
            lc.create_rectangle(21, 0, 38, 17, fill=C['logo_blue'],   outline='')
            lc.create_rectangle(0, 21, 17, 38, fill=C['logo_green'],  outline='')

        tk.Label(wrap, text='Welcome to Portfolio Mgmt!',
                 font=('Segoe UI', 20, 'bold'),
                 bg=C['right_bg'], fg=C['right_text']).pack(pady=(0, 4))
        tk.Label(wrap, text='Enter into your Productive Universe',
                 font=('Segoe UI', 11),
                 bg=C['right_bg'], fg=C['right_sub']).pack(pady=(0, 18))

        # ── Error label ────────────────────────────────────────────────────────
        self._err_var = tk.StringVar(value='')
        tk.Label(wrap, textvariable=self._err_var,
                 font=('Segoe UI', 10), bg=C['right_bg'], fg=C['error'],
                 wraplength=340, justify='left').pack(anchor='w', pady=(0, 4))

        # ══════════════════════════════════════════════════
        # OPTION 1 — Password Login
        # ══════════════════════════════════════════════════
        if self._mode == self.MODE_PASSWORD:

            self._id_var = self._make_field(wrap, 'Username or Email')
            self._pw_var = self._make_field(wrap, 'Password', secret=True)

            btn = tk.Button(wrap, text='Login',
                            font=('Segoe UI', 12, 'bold'),
                            bg=C['btn_bg'], fg='white',
                            activebackground=C['btn_hover'], activeforeground='white',
                            relief='flat', bd=0, cursor='hand2',
                            command=self._do_password_login)
            btn.pack(fill='x', ipady=10, pady=(4, 0))
            btn.bind('<Enter>', lambda e: btn.config(bg=C['btn_hover']))
            btn.bind('<Leave>', lambda e: btn.config(bg=C['btn_bg']))
            self.root.bind('<Return>', lambda e: self._do_password_login())

            # switch link
            sf = tk.Frame(wrap, bg=C['right_bg'])
            sf.pack(pady=(16, 0))
            tk.Label(sf, text='or ', font=('Segoe UI', 10),
                     bg=C['right_bg'], fg=C['div_txt']).pack(side='left')
            lnk = tk.Label(sf, text='Login with OTP (Email) →',
                           font=('Segoe UI', 10, 'underline'),
                           bg=C['right_bg'], fg=C['switch_fg'], cursor='hand2')
            lnk.pack(side='left')
            lnk.bind('<Button-1>', lambda e: self._switch_mode(self.MODE_OTP))

        # ══════════════════════════════════════════════════
        # OPTION 2 — OTP Email Login  (email only, NO password)
        # ══════════════════════════════════════════════════
        else:
            # Subtle info hint
            hint = tk.Frame(wrap, bg='#f0fdf4', bd=0)
            hint.pack(fill='x', pady=(0, 12))
            tk.Label(hint,
                     text='✉  Enter your registered email — we\'ll send a one-time code.',
                     font=('Segoe UI', 9), bg='#f0fdf4', fg='#065f46',
                     wraplength=340, justify='left', padx=10, pady=7).pack(anchor='w')

            # Email field ONLY — no password
            self._otp_email_var = self._make_field(wrap, 'Registered Email Address')

            btn = tk.Button(wrap, text='🔐  Login with OTP (Email)',
                            font=('Segoe UI', 11, 'bold'),
                            bg=C['otp_btn_bg'], fg='white',
                            activebackground=C['otp_btn_hov'], activeforeground='white',
                            relief='flat', bd=0, cursor='hand2',
                            command=self._initiate_otp)
            btn.pack(fill='x', ipady=10, pady=(4, 0))
            btn.bind('<Enter>', lambda e: btn.config(bg=C['otp_btn_hov']))
            btn.bind('<Leave>', lambda e: btn.config(bg=C['otp_btn_bg']))
            self._otp_send_btn = btn
            self.root.bind('<Return>', lambda e: self._initiate_otp())

            # switch link
            sf = tk.Frame(wrap, bg=C['right_bg'])
            sf.pack(pady=(16, 0))
            lnk = tk.Label(sf, text='← Login with Password instead',
                           font=('Segoe UI', 10, 'underline'),
                           bg=C['right_bg'], fg=C['switch_fg'], cursor='hand2')
            lnk.pack()
            lnk.bind('<Button-1>', lambda e: self._switch_mode(self.MODE_PASSWORD))

        # ── Footer ─────────────────────────────────────────────────────────────
        tk.Frame(wrap, bg=C['div_line'], height=1).pack(fill='x', pady=(20, 10))
        tk.Label(wrap, text='© Copyright KMG Portfolio Mgmt. All Rights Reserved.',
                 font=('Segoe UI', 10), bg=C['right_bg'], fg=C['copy_fg']).pack()

    def _switch_mode(self, new_mode):
        self._mode = new_mode
        self._err_var.set('')
        self._render_step1()

    # ══════════════════════════════════════════════════════════════════════════════
    # STEP 2 — OTP verification (6-digit boxes)
    # ══════════════════════════════════════════════════════════════════════════════
    def _render_step2(self, email: str):
        wrap = self._wrap
        for w in wrap.winfo_children():
            w.destroy()
        self.root.unbind('<Return>')

        try:
            tk.Label(wrap, image=self._logo_img, bg=C['right_bg']).pack(pady=(0, 10))
        except Exception:
            pass

        tk.Label(wrap, text='Email Verification',
                 font=('Segoe UI', 18, 'bold'),
                 bg=C['right_bg'], fg=C['right_text']).pack(pady=(0, 6))

        masked = self._mask_email(email)
        tk.Label(wrap, text=f'An OTP was sent to\n{masked}',
                 font=('Segoe UI', 11), bg=C['right_bg'], fg=C['right_sub'],
                 justify='center').pack(pady=(0, 18))

        self._otp_err_var = tk.StringVar(value='')
        tk.Label(wrap, textvariable=self._otp_err_var,
                 font=('Segoe UI', 10), bg=C['right_bg'], fg=C['error'],
                 wraplength=340).pack(anchor='w', pady=(0, 2))

        # 6 digit boxes
        otp_frame = tk.Frame(wrap, bg=C['right_bg'])
        otp_frame.pack(pady=(0, 4))
        self._otp_digits = []
        for i in range(6):
            frame = tk.Frame(otp_frame, bg=C['ms_bd'], bd=0)
            frame.grid(row=0, column=i, padx=4)
            inner = tk.Frame(frame, bg=C['right_bg'])
            inner.pack(padx=1, pady=1)
            var = tk.StringVar()
            e = tk.Entry(inner, textvariable=var, width=2,
                         font=('Segoe UI', 22, 'bold'),
                         bg=C['input_bg'], fg=C['input_fg'],
                         insertbackground=C['input_fg'],
                         relief='flat', bd=0, highlightthickness=0,
                         justify='center')
            e.pack(padx=10, pady=10)
            self._otp_digits.append((var, e, frame))
            idx = i
            var.trace_add('write', lambda *a, ix=idx: self._otp_advance(ix))
            e.bind('<BackSpace>', lambda ev, ix=idx: self._otp_backspace(ix))
            e.bind('<FocusIn>',  lambda ev, f=frame: f.config(bg='#2f5fdb'))
            e.bind('<FocusOut>', lambda ev, f=frame: f.config(bg=C['ms_bd']))

        self._otp_digits[0][1].focus_set()

        self._timer_var = tk.StringVar(value='⏱  Expires in 5:00')
        tk.Label(wrap, textvariable=self._timer_var,
                 font=('Segoe UI', 10), bg=C['right_bg'],
                 fg=C['right_sub']).pack(pady=(6, 0))

        self._verify_otp_btn = tk.Button(
            wrap, text='✔  Verify OTP & Login',
            font=('Segoe UI', 12, 'bold'),
            bg=C['btn_bg'], fg='white',
            activebackground=C['btn_hover'], activeforeground='white',
            relief='flat', bd=0, cursor='hand2',
            command=self._do_otp_verify)
        self._verify_otp_btn.pack(fill='x', ipady=10, pady=(14, 0))
        self._verify_otp_btn.bind('<Enter>', lambda e: self._verify_otp_btn.config(bg=C['btn_hover']))
        self._verify_otp_btn.bind('<Leave>', lambda e: self._verify_otp_btn.config(bg=C['btn_bg']))

        bottom_row = tk.Frame(wrap, bg=C['right_bg'])
        bottom_row.pack(fill='x', pady=(10, 0))

        self._resend_btn = tk.Button(
            bottom_row, text='Resend OTP',
            font=('Segoe UI', 10, 'underline'),
            bg=C['right_bg'], fg=C['btn_bg'],
            activebackground=C['right_bg'], activeforeground=C['btn_hover'],
            relief='flat', bd=0, cursor='hand2',
            command=self._resend_otp)
        self._resend_btn.pack(side='left')

        tk.Button(bottom_row, text='← Back',
                  font=('Segoe UI', 10),
                  bg=C['right_bg'], fg=C['right_sub'],
                  activebackground=C['right_bg'], activeforeground=C['right_text'],
                  relief='flat', bd=0, cursor='hand2',
                  command=self._go_back).pack(side='right')

        tk.Frame(wrap, bg=C['div_line'], height=1).pack(fill='x', pady=(18, 10))
        tk.Label(wrap, text='© Copyright KMG Portfolio Mgmt. All Rights Reserved.',
                 font=('Segoe UI', 10), bg=C['right_bg'], fg=C['copy_fg']).pack()

        self.root.bind('<Return>', lambda e: self._do_otp_verify())
        self._remaining = 300
        self._tick()

    # ── OTP digit helpers ──────────────────────────────────────────────────────
    def _otp_advance(self, idx):
        var, entry, _ = self._otp_digits[idx]
        val = var.get()
        if len(val) > 1:
            var.set(val[-1])
        if len(var.get()) == 1 and idx < 5:
            self._otp_digits[idx + 1][1].focus_set()

    def _otp_backspace(self, idx):
        var, _, _ = self._otp_digits[idx]
        if not var.get() and idx > 0:
            self._otp_digits[idx - 1][1].focus_set()

    def _get_otp_code(self) -> str:
        return ''.join(v.get() for v, _, _ in self._otp_digits)

    def _tick(self):
        if not hasattr(self, '_timer_var'):
            return
        m, s = divmod(max(0, self._remaining), 60)
        self._timer_var.set(f'⏱  Expires in {m}:{s:02d}')
        if self._remaining > 0:
            self._remaining -= 1
            self.root.after(1000, self._tick)
        else:
            self._timer_var.set('⚠  OTP expired. Please resend.')
            if hasattr(self, '_verify_otp_btn'):
                self._verify_otp_btn.config(state='disabled')

    @staticmethod
    def _mask_email(email: str) -> str:
        try:
            user, domain = email.split('@')
            masked_user = user[:2] + '***' + user[-1] if len(user) > 3 else user[:1] + '***'
            return f'{masked_user}@{domain}'
        except Exception:
            return email

    # ── Actions ────────────────────────────────────────────────────────────────
    def _do_password_login(self):
        """Option 1 — username + password, straight to app."""
        self._err_var.set('')
        id_val = self._id_var.get()
        pw_val = self._pw_var.get()
        if id_val in ('Username or Email', ''): id_val = ''
        if pw_val in ('Password', ''):          pw_val = ''

        if not id_val or not pw_val:
            self._err_var.set('⚠  Please enter your username/email and password.')
            return

        user = _find_user(id_val)
        if not user:
            self._err_var.set('✗  Invalid username/email or password.')
            return
        if not user['is_active']:
            self._err_var.set('✗  Account inactive. Contact administrator.')
            return
        if pw_val != user['password']:
            self._err_var.set('✗  Invalid username/email or password.')
            return

        _update_last_login(user['username'])
        self.on_success({
            'username':       user['username'],
            'full_name':      user['full_name'],
            'role':           user['role'],
            'email':          user['email'],
            '_login_method':  'Password',
        })

    def _initiate_otp(self):
        """
        Option 2 — email only (no password).
        Looks up the account by email, confirms it exists and is active,
        then fires the OTP. No password required.
        """
        self._err_var.set('')
        email_val = self._otp_email_var.get()
        if email_val in ('Registered Email Address', ''):
            email_val = ''

        if not email_val:
            self._err_var.set('⚠  Please enter your registered email address.')
            return

        # Look up user by email only
        user = _find_user(email_val)
        if not user:
            self._err_var.set('✗  No account found for this email address.')
            return
        if not user['is_active']:
            self._err_var.set('✗  Account inactive. Contact administrator.')
            return
        if not user.get('email'):
            self._err_var.set('✗  No email registered for this account.')
            return

        self._verified_user = user
        self._otp_email     = user['email']

        self._otp_send_btn.config(text='📨  Sending OTP…', state='disabled')
        self.root.update_idletasks()

        def _send():
            ok, err = send_otp(self._otp_email)
            self.root.after(0, lambda: self._after_send(ok, err))

        threading.Thread(target=_send, daemon=True).start()

    def _after_send(self, ok: bool, err: str):
        if ok:
            self._render_step2(self._otp_email)
        else:
            self._otp_send_btn.config(text='🔐  Login with OTP (Email)', state='normal')
            self._err_var.set(f'✗  Failed to send OTP: {err}')

    def _do_otp_verify(self):
        code = self._get_otp_code()
        if len(code) < 6:
            self._otp_err_var.set('⚠  Please enter all 6 digits.')
            return

        ok, reason = verify_otp(self._otp_email, code)
        if not ok:
            self._otp_err_var.set(f'✗  {reason}')
            for var, e, _ in self._otp_digits:
                var.set('')
            self._otp_digits[0][1].focus_set()
            return

        user = self._verified_user
        _update_last_login(user['username'])
        self.on_success({
            'username':       user['username'],
            'full_name':      user['full_name'],
            'role':           user['role'],
            'email':          user['email'],
            '_login_method':  'OTP',
        })

    def _resend_otp(self):
        self._otp_err_var.set('')
        self._resend_btn.config(text='Sending…', state='disabled')
        self.root.update_idletasks()

        def _send():
            ok, err = send_otp(self._otp_email)
            def _after():
                if ok:
                    self._remaining = 300
                    if hasattr(self, '_verify_otp_btn'):
                        self._verify_otp_btn.config(state='normal')
                    for var, e, _ in self._otp_digits:
                        var.set('')
                    self._otp_digits[0][1].focus_set()
                    self._otp_err_var.set('✓  New OTP sent.')
                    self._tick()
                else:
                    self._otp_err_var.set(f'✗  {err}')
                self._resend_btn.config(text='Resend OTP', state='normal')
            self.root.after(0, _after)

        threading.Thread(target=_send, daemon=True).start()

    def _go_back(self):
        cancel_otp(self._otp_email)
        self._verified_user = None
        self._otp_email     = ''
        self._render_step1()

    # ── Field factory ──────────────────────────────────────────────────────────
    def _make_field(self, parent, placeholder, secret=False):
        frame = tk.Frame(parent, bg=C['ms_bd'], bd=0)
        frame.pack(fill='x', pady=(0, 14))
        inner = tk.Frame(frame, bg=C['right_bg'], bd=0)
        inner.pack(fill='x', padx=1, pady=1)

        var = tk.StringVar()
        entry = tk.Entry(inner, textvariable=var, show='',
                         font=('Segoe UI', 12),
                         bg=C['input_bg'], fg=C['input_fg'],
                         insertbackground=C['input_fg'],
                         relief='flat', bd=0, highlightthickness=0)
        entry.pack(side='left', fill='x', expand=True, padx=16, pady=13)

        entry._placeholder = placeholder
        entry._secret = secret
        entry._showing_placeholder = True
        entry.insert(0, placeholder)
        entry.config(fg=C['input_ph'], show='')

        def on_focus_in(e):
            if entry._showing_placeholder:
                entry.delete(0, 'end')
                entry.config(fg=C['input_fg'], show='*' if entry._secret else '')
                entry._showing_placeholder = False
            frame.config(bg='#2f5fdb')

        def on_focus_out(e):
            if not entry.get():
                entry.insert(0, entry._placeholder)
                entry.config(fg=C['input_ph'], show='')
                entry._showing_placeholder = True
            frame.config(bg=C['ms_bd'])

        entry.bind('<FocusIn>',  on_focus_in)
        entry.bind('<FocusOut>', on_focus_out)

        if secret:
            vis_btn = tk.Button(inner, text='👁', font=('Segoe UI', 11),
                                bg=C['input_bg'], fg=C['div_txt'],
                                activebackground=C['input_bg'],
                                relief='flat', bd=0, cursor='hand2')
            vis_btn.pack(side='right', padx=10)
            def toggle_vis():
                if entry._showing_placeholder: return
                entry.config(show='' if entry.cget('show') == '*' else '*')
                vis_btn.config(text='🙈' if entry.cget('show') == '' else '👁')
            vis_btn.config(command=toggle_vis)

        return var
