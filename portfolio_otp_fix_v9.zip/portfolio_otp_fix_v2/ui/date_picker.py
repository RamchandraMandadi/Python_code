"""
date_picker.py — Lightweight calendar popup for tkinter.
No external libraries required.

Usage:
    DateEntry(parent, textvariable=v, width=20)  — inline entry + calendar button
    CalendarPopup(parent, date, on_select)        — standalone popup
"""

import tkinter as tk
import calendar
import datetime


C = {
    'topbar': '#000000', 'accent': '#2952e3', 'bg': 'white',
    'ink': '#000000', 't2': '#000000', 'border': '#dde1ed',
    'today': '#2952e3', 'today_fg': 'white',
    'sel': '#dde8ff', 'sel_fg': '#000000',
    'hover': '#f0f2f7', 'weekend': '#e53935',
}


class CalendarPopup(tk.Toplevel):
    """Floating calendar that calls on_select(date_str) on click."""

    def __init__(self, parent, initial_date=None, on_select=None):
        super().__init__(parent)
        self.on_select   = on_select
        self.overrideredirect(True)          # no window border
        self.configure(bg=C['border'])
        self.resizable(False, False)

        try:
            if initial_date and len(str(initial_date)) >= 10:
                d = datetime.datetime.strptime(str(initial_date)[:10], '%Y-%m-%d').date()
            else:
                d = datetime.date.today()
        except:
            d = datetime.date.today()

        self._sel   = d
        self._view  = datetime.date(d.year, d.month, 1)   # first of displayed month
        self._build()
        self._render()

        # Click outside → close
        self.bind('<FocusOut>', lambda e: self.after(100, self._check_focus))
        self.grab_set()

    def _check_focus(self):
        try:
            if not self.focus_displayof():
                self.destroy()
        except:
            pass

    def _build(self):
        outer = tk.Frame(self, bg=C['topbar'], padx=1, pady=1)
        outer.pack()

        # ── Month / year navigation ───────────────────────────────────────────
        nav = tk.Frame(outer, bg=C['topbar'])
        nav.pack(fill='x', padx=8, pady=6)

        tk.Button(nav, text='◀', font=('Segoe UI', 10),
                  bg=C['topbar'], fg='white', relief='flat', bd=0,
                  cursor='hand2', activebackground='#1a2845',
                  command=self._prev_month).pack(side='left')

        self._nav_lbl = tk.Label(nav, text='', font=('Segoe UI', 10, 'bold'),
                                  bg=C['topbar'], fg='white', width=16)
        self._nav_lbl.pack(side='left', expand=True)

        tk.Button(nav, text='▶', font=('Segoe UI', 10),
                  bg=C['topbar'], fg='white', relief='flat', bd=0,
                  cursor='hand2', activebackground='#1a2845',
                  command=self._next_month).pack(side='right')

        # ── Day-name headers ──────────────────────────────────────────────────
        hdr = tk.Frame(outer, bg='white')
        hdr.pack(fill='x', padx=4)
        for i, day in enumerate(['Mo','Tu','We','Th','Fr','Sa','Su']):
            fg = C['weekend'] if i >= 5 else C['t2']
            tk.Label(hdr, text=day, font=('Segoe UI', 8, 'bold'),
                     bg='white', fg=fg, width=3, pady=4).grid(row=0, column=i)

        # ── Day grid ─────────────────────────────────────────────────────────
        self._grid = tk.Frame(outer, bg='white')
        self._grid.pack(fill='both', padx=4, pady=(0, 6))

        # ── Today shortcut ────────────────────────────────────────────────────
        tk.Button(outer, text='Today', font=('Segoe UI', 8),
                  bg=C['accent'], fg='white', relief='flat', bd=0,
                  padx=8, pady=4, cursor='hand2',
                  command=self._pick_today).pack(pady=(0, 4))

    def _render(self):
        for w in self._grid.winfo_children():
            w.destroy()

        self._nav_lbl.config(
            text=self._view.strftime('%B  %Y'))

        today = datetime.date.today()
        cal   = calendar.monthcalendar(self._view.year, self._view.month)

        for row, week in enumerate(cal):
            for col, day in enumerate(week):
                if day == 0:
                    tk.Label(self._grid, text='', bg='white',
                             width=3, height=1).grid(row=row, column=col)
                    continue

                d   = datetime.date(self._view.year, self._view.month, day)
                is_today = (d == today)
                is_sel   = (d == self._sel)
                is_wknd  = (col >= 5)

                if is_sel:
                    bg, fg = C['accent'], 'white'
                elif is_today:
                    bg, fg = C['sel'], C['accent']
                else:
                    bg = 'white'
                    fg = C['weekend'] if is_wknd else C['ink']

                btn = tk.Label(self._grid, text=str(day),
                               font=('Segoe UI', 9, 'bold' if is_today or is_sel else 'normal'),
                               bg=bg, fg=fg, width=3, pady=4, cursor='hand2')
                btn.grid(row=row, column=col, padx=1, pady=1)
                btn.bind('<Button-1>',
                         lambda e, dt=d: self._pick(dt))
                btn.bind('<Enter>',
                         lambda e, b=btn, orig_bg=bg: b.config(
                             bg=C['hover'] if orig_bg == 'white' else orig_bg))
                btn.bind('<Leave>',
                         lambda e, b=btn, orig_bg=bg: b.config(bg=orig_bg))

    def _pick(self, d):
        self._sel = d
        date_str  = d.strftime('%Y-%m-%d')
        if self.on_select:
            self.on_select(date_str)
        self.destroy()

    def _pick_today(self):
        self._pick(datetime.date.today())

    def _prev_month(self):
        y, m = self._view.year, self._view.month - 1
        if m == 0:
            y -= 1; m = 12
        self._view = datetime.date(y, m, 1)
        self._render()

    def _next_month(self):
        y, m = self._view.year, self._view.month + 1
        if m == 13:
            y += 1; m = 1
        self._view = datetime.date(y, m, 1)
        self._render()


class DateEntry(tk.Frame):
    """Drop-in replacement for tk.Entry for date fields.
    Shows a text entry + calendar icon button.
    Clicking the icon opens a CalendarPopup.
    """

    def __init__(self, parent, textvariable=None, width=16, **kw):
        super().__init__(parent, bg='white')
        self._var = textvariable or tk.StringVar()

        self._entry = tk.Entry(self, textvariable=self._var,
                               width=width, font=('Segoe UI', 9),
                               relief='solid', bd=1, **kw)
        self._entry.pack(side='left')

        self._btn = tk.Button(self, text='📅', font=('Segoe UI', 9),
                              bg='#f0f2f7', fg='#2952e3',
                              relief='flat', bd=0, padx=4,
                              cursor='hand2',
                              command=self._open)
        self._btn.pack(side='left', padx=(2, 0))

    def _open(self):
        current = self._var.get().strip()
        popup   = CalendarPopup(self, initial_date=current,
                                on_select=self._var.set)
        # Position below the entry widget
        x = self.winfo_rootx()
        y = self.winfo_rooty() + self.winfo_height() + 2
        popup.update_idletasks()
        popup.geometry(f'+{x}+{y}')

    def get(self):
        return self._var.get()

    def set(self, value):
        self._var.set(value)
