"""
project_status_summary_view.py — Dynamic Project Status Summary
Click any monthly card to expand Week 1–4 detail below it.
Weekly data from WeeklyStatus sheet in project_data.xlsx.
"""

import tkinter as tk
from tkinter import ttk
import datetime
import pandas as pd
from pathlib import Path
from config.settings import Settings

C = {
    'bg':'#f4f6fb','topbar':'#0d1b3e','navy':'#0d1b3e',
    'surface':'#ffffff','border':'#d8dde8','ink':'#111827','t2':'#4b5563',
    'accent':'#2952e3','R':'#dc2626','A':'#d97706','G':'#16a34a',
    'R_bg':'#fef2f2','A_bg':'#fffbeb','G_bg':'#f0fdf4',
    'hdr_bg':'#1e3a5f','sect_bg':'#eef2f9',
    'done_bg':'#f0fdf4','done_fg':'#16a34a',
    'prog_bg':'#fffbeb','prog_fg':'#d97706',
    'risk_bg':'#fef2f2','risk_fg':'#dc2626',
    'plan_bg':'#f0f4ff','plan_fg':'#2952e3',
}

DATA_PATH = Settings.EXCEL_FILE   # same resolved path the service writes to

STATUS_CFG = {
    'Done':        ('✓', C['done_fg'], C['done_bg']),
    'In Progress': ('▶', C['prog_fg'], C['prog_bg']),
    'At Risk':     ('⚠', C['risk_fg'], C['risk_bg']),
    'Planned':     ('○', C['plan_fg'], C['plan_bg']),
    'Not Started': ('○', C['t2'],      C['surface']),
}

def _load_excel():
    """Read every sheet fresh — no file-handle caching, openpyxl engine guaranteed."""
    try:
        xl = pd.ExcelFile(DATA_PATH, engine='openpyxl')
        sheets = xl.sheet_names
        xl.close()
        return {s: pd.read_excel(DATA_PATH, sheet_name=s, engine='openpyxl')
                for s in sheets}
    except Exception as e:
        print(f'[Status] Excel read error: {e}')
        return {}

def _safe_num(v, default=0.0):
    """Return float, replacing NaN/None/empty with default. Avoids 'nan or 0 = nan' trap."""
    try:
        f = float(v)
        return default if (f != f) else f
    except:
        return default

def _fmt(v, default=''):
    if v is None: return default
    try:
        if pd.isna(v): return default
    except: pass
    s = str(v)
    return default if s in ('nan','None','NaT') else s

def _parse_date(v):
    if v is None: return None
    try:
        if hasattr(v,'date'): return v.date()
        return datetime.datetime.strptime(str(v)[:10],'%Y-%m-%d').date()
    except: return None

def _fmt_date(v):
    d = _parse_date(v)
    return d.strftime('%Y-%m-%d') if d else ''


# ══════════════════════════════════════════════════════════════════════════════
class ProjectStatusSummaryView(tk.Frame):

    def __init__(self, parent, svc=None):
        super().__init__(parent, bg=C['bg'])
        self.svc             = svc
        self._data           = {}
        self._pid            = None
        self._weekly_visible = False
        self._expanded_month = None      # currently open month key

        self._load_data()
        self._build_ui()

    # ── Data ──────────────────────────────────────────────────────────────────
    def _load_data(self):
        try: self._data = _load_excel()
        except Exception as e:
            self._data = {}; print(f'[Status] Excel error: {e}')

    def _projects(self):
        df = self._data.get('Projects', pd.DataFrame())
        return [] if df.empty else list(zip(df['ProjectID'], df['ProjectName']))

    def _get(self, sheet, pid):
        df = self._data.get(sheet, pd.DataFrame())
        if df.empty or pid is None: return pd.DataFrame()
        # Compare as strings so int/str type mismatches don't silently drop rows
        return df[df['ProjectID'].astype(str) == str(pid)].copy()

    def _proj_row(self, pid):
        df = self._data.get('Projects', pd.DataFrame())
        if df.empty or pid is None: return None
        r = df[df['ProjectID'].astype(str) == str(pid)]
        return r.iloc[0] if not r.empty else None

    def _status_row(self, pid):
        df = self._data.get('ProjectStatus', pd.DataFrame())
        if df.empty or pid is None: return None
        r = df[df['ProjectID'].astype(str) == str(pid)]
        return r.iloc[0] if not r.empty else None

    # ── Build UI ──────────────────────────────────────────────────────────────
    def _build_ui(self):
        self._build_topbar()
        self._build_scrollable_body()
        projects = self._projects()
        if projects:
            self._pid = str(projects[0][0])
            self._proj_var.set(projects[0][1])
            self._refresh()

    def _build_topbar(self):
        bar = tk.Frame(self, bg=C['topbar'], height=52)
        bar.pack(fill='x'); bar.pack_propagate(False)

        tk.Label(bar, text='📋  Project Status Summary',
                 font=('Segoe UI',13,'bold'),
                 bg=C['topbar'], fg='white').pack(side='left', padx=20, pady=14)

        ctrl = tk.Frame(bar, bg=C['topbar'])
        ctrl.pack(side='right', padx=12, pady=8)

        self._wm_btn = tk.Button(
            ctrl, text='📊  Monthly & Weekly Breakdown',
            font=('Segoe UI',9,'bold'),
            bg='#d97706', fg='white',
            activebackground='#b45309', activeforeground='white',
            relief='flat', bd=0, padx=14, pady=6,
            cursor='hand2', command=self._toggle_weekly)
        self._wm_btn.pack(side='left', padx=(0,10))

        tk.Button(ctrl, text='⟳  Reload',
                  font=('Segoe UI',8), bg='#1a2845', fg='white',
                  relief='flat', bd=0, padx=10, pady=6,
                  cursor='hand2', command=self._reload).pack(side='left', padx=(0,10))

        tk.Label(ctrl, text='Project:', font=('Segoe UI',9),
                 bg=C['topbar'], fg='#9ca3af').pack(side='left')

        self._proj_var = tk.StringVar()
        projects = self._projects()
        names    = [n for _,n in projects]
        self._pid_map = {str(n): str(p) for p, n in projects}

        cb = ttk.Combobox(ctrl, textvariable=self._proj_var,
                          values=names, state='readonly', width=20,
                          font=('Segoe UI',9))
        cb.pack(side='left', padx=(6,0))
        cb.bind('<<ComboboxSelected>>', self._on_project_change)
        self._cb = cb   # keep reference so _rebuild_combobox can update it

    def _build_scrollable_body(self):
        outer = tk.Frame(self, bg=C['bg'])
        outer.pack(fill='both', expand=True)
        self._canvas = tk.Canvas(outer, bg=C['bg'], highlightthickness=0)
        vsb = ttk.Scrollbar(outer, orient='vertical', command=self._canvas.yview)
        self._canvas.configure(yscrollcommand=vsb.set)
        vsb.pack(side='right', fill='y')
        self._canvas.pack(fill='both', expand=True)
        self._sf = tk.Frame(self._canvas, bg=C['bg'])
        self._win = self._canvas.create_window((0,0), window=self._sf, anchor='nw')
        self._sf.bind('<Configure>',
            lambda e: self._canvas.configure(scrollregion=self._canvas.bbox('all')))
        self._canvas.bind('<Configure>',
            lambda e: self._canvas.itemconfig(self._win, width=e.width))
        self._canvas.bind_all('<MouseWheel>',
            lambda e: self._canvas.yview_scroll(int(-1*e.delta/60),'units'))

    def _on_project_change(self, _=None):
        name = self._proj_var.get()
        self._pid = self._pid_map.get(name)
        self._expanded_month = None
        self._refresh()

    def _reload(self):
        self._load_data()
        self._rebuild_combobox()
        self._refresh()

    def _rebuild_combobox(self):
        """Refresh the project combobox in case new projects were added."""
        projects = self._projects()
        names    = [n for _, n in projects]
        self._pid_map = {str(n): str(p) for p, n in projects}
        self._cb.config(values=names)
        cur = self._proj_var.get()
        if cur not in names:
            # Current selection gone — pick first available
            if names:
                self._proj_var.set(names[0])
                self._pid = self._pid_map[names[0]]
            else:
                self._pid = None
        elif not self._pid and cur in self._pid_map:
            # Had no pid (opened when empty) — now we can resolve it
            self._pid = self._pid_map[cur]

    def _toggle_weekly(self):
        self._weekly_visible = not self._weekly_visible
        self._expanded_month = None
        if self._weekly_visible:
            self._wm_btn.config(bg='#1e3a5f', text='✖  Close Breakdown')
        else:
            self._wm_btn.config(bg='#d97706', text='📊  Monthly & Weekly Breakdown')
        self._refresh()

    # ── PPT slide preview window ──────────────────────────────────────────────
    def _open_ppt_view(self):
        """Open the slide-overlay UI for generating a PowerPoint report.
        Uses ONLY data from input/project_data.xlsx. The KMG portfolio /
        volume-of-work wizard page is intentionally not shown."""
        try:
            from ui.ppt_slide_view import PPTSlideView
        except Exception as e:
            from tkinter import messagebox
            messagebox.showerror(
                'PPT module missing',
                f'Could not load PPT slide view:\n{type(e).__name__}: {e}\n\n'
                f'Make sure python-pptx and Pillow are installed.')
            return
        PPTSlideView(self, initial_project_id=self._pid)

    # ── Refresh ───────────────────────────────────────────────────────────────
    def _refresh(self):
        for w in self._sf.winfo_children(): w.destroy()
        if not self._pid: return
        proj   = self._proj_row(self._pid)
        status = self._status_row(self._pid)
        tasks  = self._get('Tasks', self._pid)
        rag    = self._get('RAG',   self._pid)
        if proj is None: return

        for _fn, _args in [
            (self._build_project_header,       (proj, status)),
            (self._build_monthly_breakdown,    (proj,)) if self._weekly_visible else (None, None),
            (self._build_milestone_and_summary,(proj, status, tasks, rag)),
            (self._build_bottom_panels,        (tasks, rag)),
        ]:
            if _fn is None: continue
            try:
                _fn(*_args)
            except Exception as _e:
                import traceback
                print(f'[ProjectStatus] {_fn.__name__}: {_e}')
                traceback.print_exc()

    # ══════════════════════════════════════════════════════════════════════════
    #  MONTHLY BREAKDOWN — clickable cards → week expansion
    # ══════════════════════════════════════════════════════════════════════════
    @staticmethod
    def _bind_recursive(widget, event, callback):
        widget.bind(event, callback)
        for child in widget.winfo_children():
            ProjectStatusSummaryView._bind_recursive(child, event, callback)

    def _build_monthly_breakdown(self, proj):
        weekly_df = self._get('WeeklyStatus', self._pid)

        outer = tk.Frame(self._sf, bg=C['surface'],
                         highlightthickness=1, highlightbackground=C['border'])
        outer.pack(fill='x', padx=16, pady=(10,0))

        sh = tk.Frame(outer, bg=C['hdr_bg'])
        sh.pack(fill='x')
        tk.Label(sh, text='📅  Monthly & Weekly Breakdown',
                 font=('Segoe UI',9,'bold'),
                 bg=C['hdr_bg'], fg='white', padx=14, pady=8).pack(side='left')
        tk.Label(sh, text='  ·  Click a month to expand Week 1–4 spend & hours',
                 font=('Segoe UI',8), bg=C['hdr_bg'], fg='#93c5fd').pack(side='left')

        # ── Scrollable cards row ──────────────────────────────────────────────
        row_wrap = tk.Frame(outer, bg=C['surface'])
        row_wrap.pack(fill='x', padx=12, pady=(10,4))

        h_cvs = tk.Canvas(row_wrap, bg=C['surface'], highlightthickness=0, height=175)
        h_sb  = ttk.Scrollbar(row_wrap, orient='horizontal', command=h_cvs.xview)
        h_cvs.configure(xscrollcommand=h_sb.set)
        h_sb.pack(side='bottom', fill='x')
        h_cvs.pack(side='top', fill='x')

        cards_fr = tk.Frame(h_cvs, bg=C['surface'])
        h_cvs.create_window((0, 0), window=cards_fr, anchor='nw')

        def _update_scroll(e=None):
            h_cvs.configure(scrollregion=h_cvs.bbox('all'))
        cards_fr.bind('<Configure>', _update_scroll)

        # expansion frame below cards
        self._week_container = tk.Frame(outer, bg=C['surface'])
        self._week_container.pack(fill='x', padx=12, pady=(0,10))

        if weekly_df.empty:
            tk.Label(cards_fr, text='No WeeklyStatus data.',
                     font=('Segoe UI',9), bg=C['surface'],
                     fg=C['t2'], padx=20, pady=40).pack(side='left')
            return

        months_list = (weekly_df.drop_duplicates('Month')
                       .sort_values('Month')[['Month','MonthLabel']]
                       .values.tolist())

        for month_key, month_label in months_list:
            mdf       = weekly_df[weekly_df['Month'] == month_key]
            done_ct   = len(mdf[mdf['Status'] == 'Done'])
            prog_ct   = len(mdf[mdf['Status'].isin(['In Progress','At Risk'])])
            plan_ct   = len(mdf[mdf['Status'].isin(['Planned','Not Started'])])
            total_hrs = int(mdf['HoursLogged'].sum()) if 'HoursLogged' in mdf.columns else 0
            total_sp  = mdf['WeeklySpend'].sum() if 'WeeklySpend' in mdf.columns else 0

            is_exp  = (self._expanded_month == month_key)
            card_bg = '#dbeafe' if is_exp else C['sect_bg']
            bd_col  = C['accent'] if is_exp else C['border']

            card = tk.Frame(cards_fr, bg=card_bg, cursor='hand2',
                            highlightthickness=2 if is_exp else 1,
                            highlightbackground=bd_col,
                            padx=10, pady=8)
            card.pack(side='left', padx=(0,8), pady=4)

            tk.Label(card, text=month_label,
                     font=('Segoe UI',10,'bold'), width=14, anchor='w',
                     bg=card_bg, fg=C['accent'] if is_exp else C['navy']).pack(anchor='w')

            tk.Label(card, text=f'{len(mdf)} weeks  •  {total_hrs} hrs',
                     font=('Segoe UI',7), bg=card_bg, fg=C['t2']).pack(anchor='w', pady=(1,2))

            if total_sp > 0:
                tk.Label(card, text=f'💰 ${total_sp:,.0f} spent',
                         font=('Segoe UI',8,'bold'),
                         bg=card_bg, fg=C['R']).pack(anchor='w', pady=(0,5))
            else:
                tk.Label(card, text='💰 $0  (not started)',
                         font=('Segoe UI',7),
                         bg=card_bg, fg=C['t2']).pack(anchor='w', pady=(0,5))

            pills = tk.Frame(card, bg=card_bg)
            pills.pack(anchor='w', pady=(0,5))
            for cnt, lbl, fg2, pbg in [
                (done_ct, '✓ Done',   C['G'],    '#dcfce7'),
                (prog_ct, '▶ Active', C['A'],    '#fef9c3'),
                (plan_ct, '○ Ahead',  '#6b7280', '#f3f4f6'),
            ]:
                if cnt:
                    tk.Label(pills, text=f'{cnt} {lbl}',
                             font=('Segoe UI',6,'bold'),
                             bg=pbg, fg=fg2, padx=4, pady=1).pack(side='left', padx=(0,2))

            tk.Label(card,
                     text='▼  Close' if is_exp else '▶  View weeks',
                     font=('Segoe UI',7,'bold'),
                     bg=card_bg, fg=C['accent']).pack(anchor='w')

            mk = month_key
            self._bind_recursive(card, '<Button-1>',
                                  lambda e, m=mk: self._toggle_month(m))
            if is_exp:
                self._draw_week_cards(self._week_container, mdf, month_label)

    # ── Toggle month expand ───────────────────────────────────────────────────
    def _toggle_month(self, month_key):
        self._expanded_month = None if self._expanded_month == month_key else month_key
        self._refresh()
        self._sf.after(120, lambda: self._canvas.yview_moveto(0.12))

    # ── Weekly cards (2×2 grid) ───────────────────────────────────────────────
    def _draw_week_cards(self, parent, month_weeks, month_label):
        hdr = tk.Frame(parent, bg='#e8f0fe',
                       highlightthickness=1, highlightbackground=C['accent'])
        hdr.pack(fill='x', pady=(4,8))
        tk.Label(hdr, text=f'  📆  {month_label} — Week by Week Detail',
                 font=('Segoe UI',9,'bold'),
                 bg='#e8f0fe', fg=C['accent'], pady=8).pack(side='left')

        # ── Month totals summary bar ──────────────────────────────────────────
        tot_hrs = int(month_weeks['HoursLogged'].sum()) if 'HoursLogged' in month_weeks.columns else 0
        tot_sp  = month_weeks['WeeklySpend'].sum()      if 'WeeklySpend'  in month_weeks.columns else 0
        sumbar  = tk.Frame(parent, bg='#f0f4ff',
                           highlightthickness=1, highlightbackground=C['border'])
        sumbar.pack(fill='x', pady=(0,10))
        for lbl, val, col in [
            ('📊 Month Total Hours:',  f'{tot_hrs} hrs',    C['accent']),
            ('💰 Month Total Spend:',  f'${tot_sp:,.0f}',   C['R']),
            ('🗓 Weeks in Month:',      str(len(month_weeks)), C['navy']),
        ]:
            sf = tk.Frame(sumbar, bg='#f0f4ff')
            sf.pack(side='left', padx=20, pady=8)
            tk.Label(sf, text=lbl, font=('Segoe UI',8),
                     bg='#f0f4ff', fg=C['t2']).pack(side='left')
            tk.Label(sf, text=' ' + val, font=('Segoe UI',10,'bold'),
                     bg='#f0f4ff', fg=col).pack(side='left')

        # ── 2-column week layout using pack (avoids grid sizing issues) ───────
        weeks_sorted = month_weeks.sort_values('WeekNo').reset_index(drop=True)

        # Two column frames
        cols_fr = tk.Frame(parent, bg=C['surface'])
        cols_fr.pack(fill='x')
        left_col  = tk.Frame(cols_fr, bg=C['surface'])
        right_col = tk.Frame(cols_fr, bg=C['surface'])
        left_col.pack(side='left', fill='both', expand=True, padx=(0,4))
        right_col.pack(side='left', fill='both', expand=True, padx=(4,0))

        for idx, (_, wk) in enumerate(weeks_sorted.iterrows()):
            col_frame = left_col if idx % 2 == 0 else right_col

            st      = _fmt(wk.get('Status'), 'Planned')
            icon, fg_col, bg_col = STATUS_CFG.get(st, ('○', C['t2'], C['surface']))
            hrs     = wk.get('HoursLogged', 0) or 0
            sp      = wk.get('WeeklySpend',  0) or 0
            wk_lbl  = _fmt(wk.get('WeekLabel'), f'Week {idx+1}')
            wk_s    = _fmt(wk.get('WeekStart'))
            wk_e    = _fmt(wk.get('WeekEnd'))
            desc    = _fmt(wk.get('Description'), 'No activity recorded.')

            card = tk.Frame(col_frame, bg=bg_col,
                            highlightthickness=1, highlightbackground=fg_col,
                            padx=14, pady=10)
            card.pack(fill='x', pady=(0,8))

            # ── Week header ───────────────────────────────────────────────────
            top = tk.Frame(card, bg=bg_col)
            top.pack(fill='x')
            tk.Label(top, text=f' {icon} {st} ',
                     font=('Segoe UI',8,'bold'),
                     bg=fg_col, fg='white',
                     padx=6, pady=2).pack(side='right')
            tk.Label(top, text=wk_lbl,
                     font=('Segoe UI',11,'bold'),
                     bg=bg_col, fg=C['ink']).pack(side='left')

            # Date range
            if wk_s and wk_e:
                tk.Label(card, text=f'📅  {wk_s}  →  {wk_e}',
                         font=('Segoe UI',7),
                         bg=bg_col, fg=C['t2']).pack(anchor='w', pady=(2,4))

            # Divider — use a safe color (no alpha suffix)
            div_bg = '#16a34a' if fg_col == C['G'] else \
                     ('#d97706' if fg_col == C['A'] else \
                     ('#dc2626' if fg_col == C['R'] else '#9ca3af'))
            tk.Frame(card, bg=div_bg, height=1).pack(fill='x', pady=(0,8))

            # Description
            tk.Label(card, text=desc,
                     font=('Segoe UI',9),
                     bg=bg_col, fg=C['ink'],
                     wraplength=500, justify='left').pack(anchor='w')

            # ── Hours + Spend footer ──────────────────────────────────────────
            tk.Frame(card, bg='#e5e7eb', height=1).pack(fill='x', pady=(8,4))
            foot = tk.Frame(card, bg=bg_col)
            foot.pack(fill='x')

            if hrs > 0:
                tk.Label(foot, text=f'🕐  {int(hrs)} hrs logged',
                         font=('Segoe UI',8,'bold'),
                         bg='#e0f2fe', fg='#0369a1',
                         padx=8, pady=3).pack(side='left')
            else:
                tk.Label(foot, text='🕐  0 hrs (not started)',
                         font=('Segoe UI',8),
                         bg='#f3f4f6', fg=C['t2'],
                         padx=8, pady=3).pack(side='left')

            if sp > 0:
                tk.Label(foot, text=f'  💰  ${sp:,.0f} spent',
                         font=('Segoe UI',8,'bold'),
                         bg='#fee2e2', fg=C['R'],
                         padx=8, pady=3).pack(side='left', padx=(6,0))
            else:
                tk.Label(foot, text='  💰  $0 (planned)',
                         font=('Segoe UI',8),
                         bg='#f3f4f6', fg=C['t2'],
                         padx=8, pady=3).pack(side='left', padx=(6,0))

    # ══════════════════════════════════════════════════════════════════════════
    #  EXISTING PANELS
    # ══════════════════════════════════════════════════════════════════════════
    def _build_project_header(self, proj, status):
        hdr = tk.Frame(self._sf, bg=C['surface'],
                       highlightthickness=1, highlightbackground=C['border'])
        hdr.pack(fill='x', padx=16, pady=(12,0))
        inner = tk.Frame(hdr, bg=C['surface'])
        inner.pack(fill='x', padx=20, pady=14)

        left = tk.Frame(inner, bg=C['surface'])
        left.pack(side='left', fill='x', expand=True)
        nf = tk.Frame(left, bg=C['surface'])
        nf.pack(anchor='w')
        tk.Label(nf, text=_fmt(proj.get('ProjectName')),
                 font=('Segoe UI',22,'bold'),
                 bg=C['surface'], fg=C['ink']).pack(side='left')

        df = tk.Frame(left, bg=C['surface'])
        df.pack(anchor='w', pady=(4,0))
        tk.Label(df, text='Project Status as of ',
                 font=('Segoe UI',10),
                 bg=C['surface'], fg=C['t2']).pack(side='left')
        updated = _parse_date(status.get('LastUpdated') if status is not None else None) or datetime.date.today()
        tk.Label(df, text=updated.strftime('%B %d, %Y'),
                 font=('Segoe UI',10,'bold'),
                 bg=C['surface'], fg=C['A']).pack(side='left')
        ov = _fmt(status.get('AutoStatus'),'G') if status is not None else 'G'
        bcfg = {'Red':(C['R'],'#fff5f5'),'Amber':(C['A'],'#fffbeb'),
                'Green':(C['G'],'#f0fdf4')}.get(ov,(C['G'],'#f0fdf4'))
        tk.Label(df, text=f'  ◉  {ov}  ',
                 font=('Segoe UI',9,'bold'),
                 bg=bcfg[1], fg=bcfg[0],
                 padx=6, pady=3).pack(side='left', padx=12)

        right = tk.Frame(inner, bg=C['surface'])
        right.pack(side='right')

        # ── PPT Report button (opens the slide-overlay UI; uses pm_final excel only)
        ppt_wrap = tk.Frame(right, bg=C['surface'])
        ppt_wrap.pack(side='left', padx=(0, 18))
        self._ppt_btn = tk.Button(
            ppt_wrap, text='📑  PPT Report',
            font=('Segoe UI', 10, 'bold'),
            bg='#16a34a', fg='white',
            activebackground='#15803d', activeforeground='white',
            relief='flat', bd=0, padx=18, pady=10,
            cursor='hand2', command=self._open_ppt_view)
        self._ppt_btn.pack()

        budget = _safe_num(proj.get('Budget',0))
        spent  = _safe_num(proj.get('Spent',0))
        pct    = int(spent/budget*100) if budget else 0
        prog   = _safe_num(status.get('Progress',0)) if status is not None else 0.0
        pri    = _fmt(proj.get('Priority'))
        pc     = {'Critical':C['R'],'High':C['A'],'Medium':C['accent'],'Low':C['G']}.get(pri,C['t2'])
        for label, val, col in [('Priority',pri,pc),
                                 ('Progress',f'{prog:.0f}%',C['accent']),
                                 ('Budget Used',f'{pct}%',C['R'] if pct>90 else (C['A'] if pct>70 else C['G']))]:
            kf = tk.Frame(right, bg=C['surface'])
            kf.pack(side='left', padx=16)
            tk.Label(kf, text=val, font=('Segoe UI',18,'bold'),
                     bg=C['surface'], fg=col).pack()
            tk.Label(kf, text=label, font=('Segoe UI',8),
                     bg=C['surface'], fg=C['t2']).pack()

    def _build_milestone_and_summary(self, proj, status, tasks, rag):
        row = tk.Frame(self._sf, bg=C['bg'])
        row.pack(fill='x', padx=16, pady=(10,0))
        row.columnconfigure(0, weight=3); row.columnconfigure(1, weight=2)
        self._build_milestones(row, proj, tasks)
        self._build_summary_panel(row, proj, rag)

    def _build_milestones(self, parent, proj, tasks):
        card = tk.Frame(parent, bg=C['surface'],
                        highlightthickness=1, highlightbackground=C['border'])
        card.grid(row=0, column=0, sticky='nsew', padx=(0,6))
        sh = tk.Frame(card, bg=C['hdr_bg'])
        sh.pack(fill='x')
        tk.Label(sh, text='KEY MILESTONES', font=('Segoe UI',9,'bold'),
                 bg=C['hdr_bg'], fg='white', padx=14, pady=8).pack(side='left')
        today = datetime.date.today()
        if tasks.empty:
            tk.Label(card, text='No tasks found for this project.',
                     font=('Segoe UI',9), bg=C['surface'],
                     fg=C['t2'], padx=14, pady=12).pack(anchor='w')
            return
        tasks = tasks.copy()
        tasks['_s'] = tasks['StartDate'].apply(_parse_date)
        tasks['_e'] = tasks['EndDate'].apply(_parse_date)
        tasks = tasks.dropna(subset=['_s','_e']).sort_values('_s')
        # Guard: all tasks may lack valid dates after dropna
        if tasks.empty:
            tk.Label(card, text='No tasks with valid dates found.',
                     font=('Segoe UI',9), bg=C['surface'],
                     fg=C['t2'], padx=14, pady=12).pack(anchor='w')
            return
        proj_start = _parse_date(proj.get('StartDate')) or tasks['_s'].min()
        proj_end   = _parse_date(proj.get('EndDate'))   or tasks['_e'].max()
        # Final safety: ensure we have real dates before building the timeline
        if proj_start is None or pd.isna(proj_start) or proj_end is None or pd.isna(proj_end):
            tk.Label(card, text='Project start/end dates are missing.',
                     font=('Segoe UI',9), bg=C['surface'],
                     fg=C['t2'], padx=14, pady=12).pack(anchor='w')
            return
        months = []
        cur = proj_start.replace(day=1)
        while cur <= proj_end.replace(day=1):
            months.append(cur)
            m = cur.month+1 if cur.month<12 else 1
            y = cur.year+(1 if cur.month==12 else 0)
            cur = cur.replace(year=y,month=m)
        tl = tk.Canvas(card, bg=C['surface'], height=130, highlightthickness=0)
        tl.pack(fill='x', padx=12, pady=(10,6))
        def _draw(event=None):
            tl.delete('all'); w=tl.winfo_width() or 600; n=len(months)
            if not n: return
            cw=w/n; by=38
            for i,m in enumerate(months):
                x0,x1=i*cw,(i+1)*cw
                is_c=(m.year==today.year and m.month==today.month)
                tl.create_rectangle(x0,6,x1-1,28,fill=C['navy'] if is_c else '#374151',outline='')
                tl.create_text((x0+x1)/2,17,text=m.strftime('%b %Y'),font=('Segoe UI',7,'bold'),fill='white')
            slot={}
            for _,t in tasks.iterrows():
                for i,m in enumerate(months):
                    nxt=months[i+1] if i+1<len(months) else None
                    ok=(m<=t['_s']<nxt) if nxt else (t['_s']>=m)
                    if ok: slot.setdefault(i,[]).append(t); break
            r=12
            for mi,tlist in slot.items():
                xc=(mi+0.5)*cw
                for j,t in enumerate(tlist[:2]):
                    cx=xc+(j-0.5)*(cw*0.35) if len(tlist)>1 else xc; cy=by+14
                    st=_fmt(t.get('Status'))
                    done=st=='Completed'; act=st in('In Progress','At Risk')
                    fill=C['G'] if done else (C['A'] if act else '#d1d5db')
                    tl.create_oval(cx-r,cy-r,cx+r,cy+r,fill=fill,outline=fill,width=2)
                    lbl='✓' if done else ('▶' if act else str(mi+1))
                    tl.create_text(cx,cy,text=lbl,font=('Segoe UI',7,'bold'),
                                   fill='white' if(done or act) else '#374151')
                    nm=_fmt(t.get('TaskName')); words=nm.split(); lines,line=[],''
                    for ww in words:
                        if len(line+ww)>14: lines.append(line.strip()); line=ww+' '
                        else: line+=ww+' '
                    if line.strip(): lines.append(line.strip())
                    tl.create_text(cx,cy+r+6,text='\n'.join(lines[:2]),font=('Segoe UI',7,'bold'),
                                   fill='#111827',anchor='n',justify='center',width=cw-4)
        tl.bind('<Configure>',_draw); tl.after(80,_draw)
        leg=tk.Frame(card,bg=C['surface']); leg.pack(anchor='w',padx=14,pady=(0,10))
        for col,lbl in [(C['G'],'Completed'),(C['A'],'In Progress'),(C['R'],'At Risk'),('#d1d5db','Not Started')]:
            f=tk.Frame(leg,bg=C['surface']); f.pack(side='left',padx=(0,12))
            c=tk.Canvas(f,width=12,height=12,bg=C['surface'],highlightthickness=0); c.pack(side='left')
            c.create_oval(1,1,11,11,fill=col,outline='')
            tk.Label(f,text=lbl,font=('Segoe UI',7),bg=C['surface'],fg=C['t2']).pack(side='left')
        tk.Frame(card,bg=C['border'],height=1).pack(fill='x',padx=14)
        th=tk.Frame(card,bg='#f1f5f9'); th.pack(fill='x',padx=14,pady=(6,0))
        for col,cw2,anc in [('Task',220,'w'),('Phase',100,'w'),('Start',90,'center'),
                             ('End',90,'center'),('Status',100,'center'),('Progress',80,'center')]:
            tk.Label(th,text=col,font=('Segoe UI',8,'bold'),bg='#f1f5f9',fg=C['ink'],
                     width=cw2//7,anchor=anc,padx=6,pady=5).pack(side='left')
        for _,t in tasks.iterrows():
            st=_fmt(t.get('Status')); prg=t.get('Progress',0) or 0
            sc=C['G'] if st=='Completed' else(C['A'] if st=='In Progress' else(C['R'] if st=='At Risk' else C['t2']))
            bg='#f0fdf4' if st=='Completed' else('#fffbeb' if st=='In Progress' else('#fef2f2' if st=='At Risk' else C['surface']))
            r=tk.Frame(card,bg=bg,highlightthickness=1,highlightbackground='#e5e7eb'); r.pack(fill='x',padx=14,pady=1)
            for val,cw3,anc in [(_fmt(t.get('TaskName')),220,'w'),(_fmt(t.get('Phase')),100,'w'),
                                 (_fmt_date(t.get('StartDate')),90,'center'),(_fmt_date(t.get('EndDate')),90,'center'),
                                 (st,100,'center'),(f"{int(prg)}%",80,'center')]:
                tk.Label(r,text=val,font=('Segoe UI',8),bg=bg,fg=sc if val==st else C['ink'],
                         width=cw3//7,anchor=anc,padx=6,pady=4).pack(side='left')
            pb=tk.Frame(r,bg=bg,padx=4); pb.pack(side='left')
            pb_bg=tk.Frame(pb,bg='#e5e7eb',height=6,width=60); pb_bg.pack_propagate(False); pb_bg.pack(pady=7)
            tk.Frame(pb_bg,bg=sc,width=max(1,int(60*prg/100)),height=6).place(x=0,y=0)

    def _build_summary_panel(self, parent, proj, rag):
        card=tk.Frame(parent,bg=C['surface'],highlightthickness=1,highlightbackground=C['border'])
        card.grid(row=0,column=1,sticky='nsew')
        sh=tk.Frame(card,bg=C['hdr_bg']); sh.pack(fill='x')
        tk.Label(sh,text='SUMMARY',font=('Segoe UI',9,'bold'),
                 bg=C['hdr_bg'],fg='white',padx=14,pady=8).pack(side='left')
        body=tk.Frame(card,bg=C['surface'],padx=14,pady=10); body.pack(fill='both',expand=True)
        tk.Label(body,text='Scope',font=('Segoe UI',9,'bold'),bg=C['surface'],fg=C['ink']).pack(anchor='w')
        desc=_fmt(proj.get('Description'),'No description available.')
        tk.Label(body,text=desc,font=('Segoe UI',9),bg=C['surface'],fg=C['t2'],
                 wraplength=280,justify='left').pack(anchor='w',pady=(2,10))
        tk.Frame(body,bg=C['border'],height=1).pack(fill='x',pady=4)
        for label,key in [('Start Date','StartDate'),('End Date','EndDate')]:
            row=tk.Frame(body,bg=C['surface']); row.pack(fill='x',pady=2)
            tk.Label(row,text=label+':',font=('Segoe UI',8,'bold'),
                     bg=C['surface'],fg=C['ink'],width=10,anchor='w').pack(side='left')
            tk.Label(row,text=_fmt_date(proj.get(key,'')),
                     font=('Segoe UI',8),bg=C['surface'],fg=C['t2']).pack(side='left')
        tk.Frame(body,bg=C['border'],height=1).pack(fill='x',pady=(8,4))
        tk.Label(body,text='RAG At-Risk Aspects',font=('Segoe UI',9,'bold'),
                 bg=C['surface'],fg=C['ink']).pack(anchor='w',pady=(2,4))
        at_risk=rag[rag['Status'].isin(['R','A'])] if not rag.empty else pd.DataFrame()
        if at_risk.empty:
            tk.Label(body,text='✔  All aspects Green',font=('Segoe UI',9),
                     bg=C['surface'],fg=C['G']).pack(anchor='w')
        else:
            for _,rr in at_risk.iterrows():
                rb=C['R_bg'] if rr['Status']=='R' else C['A_bg']
                col=C['R'] if rr['Status']=='R' else C['A']
                fr=tk.Frame(body,bg=rb,padx=8,pady=4,highlightthickness=1,highlightbackground=C['border'])
                fr.pack(fill='x',pady=2)
                tk.Label(fr,text=f"{'🔴' if rr['Status']=='R' else '🟡'} {rr['Aspect']}",
                         font=('Segoe UI',8,'bold'),bg=rb,fg=col).pack(anchor='w')
                exp=_fmt(rr.get('Explanation'))
                if exp: tk.Label(fr,text=exp,font=('Segoe UI',7),bg=rb,fg=C['t2'],
                                 wraplength=260,justify='left').pack(anchor='w')
        tk.Frame(body,bg=C['border'],height=1).pack(fill='x',pady=(8,4))
        budget=_safe_num(proj.get('Budget',0)); spent=_safe_num(proj.get('Spent',0)); pct=spent/budget if budget else 0
        tk.Label(body,text='Budget Utilisation',font=('Segoe UI',9,'bold'),
                 bg=C['surface'],fg=C['ink']).pack(anchor='w',pady=(2,4))
        bb=tk.Frame(body,bg='#e5e7eb',height=10); bb.pack(fill='x',pady=(0,2)); bb.pack_propagate(False)
        col=C['R'] if pct>0.9 else(C['A'] if pct>0.7 else C['G'])
        tk.Frame(bb,bg=col,height=10).place(relwidth=max(0.0,min(pct,1.0)),relheight=1.0,x=0,y=0)
        row=tk.Frame(body,bg=C['surface']); row.pack(fill='x')
        tk.Label(row,text=f'${spent:,.0f} spent',font=('Segoe UI',8),
                 bg=C['surface'],fg=C['t2']).pack(side='left')
        tk.Label(row,text=f'${budget:,.0f} total',font=('Segoe UI',8),
                 bg=C['surface'],fg=C['t2']).pack(side='right')

    def _build_bottom_panels(self, tasks, rag):
        grid=tk.Frame(self._sf,bg=C['bg']); grid.pack(fill='x',padx=16,pady=10)
        grid.columnconfigure(0,weight=1); grid.columnconfigure(1,weight=1)
        comp=tasks[tasks['Status']=='Completed'] if not tasks.empty else pd.DataFrame()
        upc=tasks[tasks['Status'].isin(['In Progress','Not Started','At Risk'])] if not tasks.empty else pd.DataFrame()
        risks=rag[rag['Status'].isin(['R','A'])] if not rag.empty else pd.DataFrame()
        risks_r=rag[rag['Status']=='R'] if not rag.empty else pd.DataFrame()
        for row,col,title,accent,items in [
            (0,0,'✅  Recent Accomplishments',C['G'],self._acc_items(comp)),
            (0,1,'🔜  Upcoming Key Activities',C['accent'],self._upc_items(upc)),
            (1,0,'⚠️  Key Risks and Issues',C['R'],self._risk_items(risks)),
            (1,1,'🛡  Mitigation Discussions','#7c3aed',self._mit_items(risks_r)),
        ]: self._build_panel(grid,row,col,title,accent,items)

    def _build_panel(self,parent,row,col,title,accent,items):
        card=tk.Frame(parent,bg=C['surface'],highlightthickness=1,highlightbackground=C['border'])
        card.grid(row=row,column=col,sticky='nsew',padx=(0,6) if col==0 else 0,pady=(0,8))
        tk.Frame(card,bg=accent,height=4).pack(fill='x')
        hdr=tk.Frame(card,bg='#f8fafc'); hdr.pack(fill='x')
        tk.Label(hdr,text=title,font=('Segoe UI',9,'bold'),
                 bg='#f8fafc',fg=C['ink'],padx=14,pady=8).pack(side='left')
        body=tk.Frame(card,bg=C['surface'],padx=14,pady=8); body.pack(fill='both',expand=True)
        if not items:
            tk.Label(body,text='No items.',font=('Segoe UI',9),bg=C['surface'],fg=C['t2']).pack(anchor='w')
            return
        for bullet,text in items:
            r=tk.Frame(body,bg=C['surface']); r.pack(fill='x',pady=2)
            tk.Label(r,text=bullet,font=('Segoe UI',10),bg=C['surface'],fg=accent,width=2).pack(side='left',anchor='n',pady=2)
            tk.Label(r,text=text,font=('Segoe UI',9),bg=C['surface'],fg=C['ink'],
                     wraplength=340,justify='left',anchor='w').pack(side='left',fill='x',expand=True)

    def _acc_items(self,c):
        return [] if c.empty else [('•',f"{_fmt(t.get('TaskName'))} — {_fmt(t.get('Phase'))} completed {('by '+_fmt_date(t.get('EndDate'))) if _fmt_date(t.get('EndDate')) else ''}") for _,t in c.iterrows()]

    def _upc_items(self,u):
        if u.empty: return []
        items=[]
        for _,t in u.iterrows():
            st=_fmt(t.get('Status')); prg=int(t.get('Progress',0) or 0)
            detail=f'{prg}% complete' if prg>0 else f'Starts {_fmt_date(t.get("StartDate"))}'
            badge='▶' if st=='In Progress' else('⚠' if st=='At Risk' else '○')
            items.append((badge,f"{_fmt(t.get('TaskName'))} · {detail} → due {_fmt_date(t.get('EndDate'))}"))
        return items

    def _risk_items(self,r):
        if r.empty: return [('✔','All aspects Green.')]
        return [('🔴' if rr['Status']=='R' else '🟡', f"[{rr['Aspect']}] {_fmt(rr.get('Explanation')) or 'No detail.'}") for _,rr in r.iterrows()]

    def _mit_items(self,r):
        if r.empty: return [('✔','No critical items.')]
        return [('→',f"[{rr['Aspect']}] {_fmt(rr.get('Explanation')) or 'Escalate and assign owner.'}") for _,rr in r.iterrows()]
