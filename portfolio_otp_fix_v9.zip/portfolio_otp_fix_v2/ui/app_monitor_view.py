"""
app_monitor_view.py  — Admin-only Live App Usage Monitor
Visible ONLY to users with role == 'Admin'

Features:
  • Live active sessions panel (who is online right now, duration)
  • Login history table with filters (date/user)
  • Per-user stats: total logins, avg session, last seen
  • Hourly heatmap chart of logins
  • Method distribution (Password vs OTP) pie/bar
  • Auto-refresh every 30 s
"""

import tkinter as tk
from tkinter import ttk, font as tkfont
import datetime
import math
import os
from openpyxl import load_workbook, Workbook, utils

# ── colour palette (matches main_window) ────────────────────────────────────
C = {
    'topbar':   '#0f172a',
    'bg':       '#f0f2f7',
    'surface':  '#ffffff',
    'border':   '#dde1ed',
    'accent':   '#2952e3',
    'accent2':  '#7c3aed',
    'G':        '#16a34a',
    'A':        '#f59e0b',
    'R':        '#e53935',
    'ink':      '#0f172a',
    't2':       '#64748b',
    'card_hdr': '#1e293b',
    'online':   '#22c55e',
    'chart1':   '#2952e3',
    'chart2':   '#7c3aed',
    'chart3':   '#06b6d4',
    'chart4':   '#f59e0b',
    'chart5':   '#e53935',
}

XLSX = os.path.join(os.path.dirname(__file__), '..', 'input', 'project_data.xlsx')

# ── Module-level session registry (local process only — used for method chart) ─
_login_history: list = []   # list of dicts written at login time

# ── Shared ActiveSessions sheet ──────────────────────────────────────────────
# ALL running instances of the app read/write the same Excel sheet so that
# "Online Now" and User Statistics correctly reflect EVERY logged-in user,
# not just the user in the current process.
_AS_SHEET   = 'ActiveSessions'
_AS_HEADERS = ['Username', 'FullName', 'Role', 'Method', 'LoginDateTime', 'Heartbeat']
_STALE_MINS = 5          # rows older than this (no heartbeat) are treated as offline
_my_username: str = ''   # set at register_session, used by the heartbeat timer
_heartbeat_after_id = None


def _read_active_sessions_sheet() -> dict:
    """Read ActiveSessions sheet → dict  username → info dict.
    Rows whose Heartbeat is older than _STALE_MINS minutes are skipped
    (the process crashed / was force-killed without calling deregister_session)."""
    result = {}
    cutoff = datetime.datetime.now() - datetime.timedelta(minutes=_STALE_MINS)
    try:
        if not os.path.exists(XLSX):
            return result
        wb = load_workbook(XLSX, read_only=True, data_only=True)
        if _AS_SHEET not in wb.sheetnames:
            return result
        ws = wb[_AS_SHEET]
        headers = None
        for row in ws.iter_rows(values_only=True):
            if headers is None:
                headers = [str(h).strip() if h else '' for h in row]
                continue
            if not row or row[0] is None:
                continue
            d = dict(zip(headers, row))
            uname = str(d.get('Username', '')).strip()
            if not uname:
                continue
            hb_raw = d.get('Heartbeat', '')
            hb = _parse_dt(str(hb_raw)) if hb_raw else datetime.datetime.min
            if hb < cutoff:
                continue          # stale — process is gone
            login_raw = d.get('LoginDateTime', '')
            result[uname] = {
                'full_name': str(d.get('FullName', uname)).strip(),
                'role':      str(d.get('Role', '')).strip(),
                'method':    str(d.get('Method', '')).strip(),
                'login_dt':  _parse_dt(str(login_raw)) if login_raw else datetime.datetime.now(),
                'heartbeat': hb,
            }
        wb.close()
    except Exception as e:
        print(f'[monitor] _read_active_sessions_sheet: {e}')
    return result


def _write_active_sessions_sheet(sessions: dict):
    """Overwrite the entire ActiveSessions sheet with the given dict.
    Called after any add / remove / heartbeat update."""
    try:
        if os.path.exists(XLSX):
            wb = load_workbook(XLSX)
        else:
            wb = Workbook()

        if _AS_SHEET in wb.sheetnames:
            del wb[_AS_SHEET]
        ws = wb.create_sheet(_AS_SHEET)
        ws.append(_AS_HEADERS)
        for uname, info in sessions.items():
            ws.append([
                uname,
                info.get('full_name', uname),
                info.get('role', ''),
                info.get('method', ''),
                info['login_dt'].strftime('%Y-%m-%d %H:%M:%S'),
                info.get('heartbeat', datetime.datetime.now()).strftime('%Y-%m-%d %H:%M:%S'),
            ])
        wb.save(XLSX)
    except Exception as e:
        print(f'[monitor] _write_active_sessions_sheet: {e}')


def _heartbeat_tick(root_widget=None):
    """Update this process's heartbeat timestamp in the shared sheet every 60 s.
    Also prunes stale rows from other dead processes while we have the file open."""
    global _heartbeat_after_id
    if not _my_username:
        return
    try:
        sessions = _read_active_sessions_sheet()
        if _my_username in sessions:
            sessions[_my_username]['heartbeat'] = datetime.datetime.now()
            _write_active_sessions_sheet(sessions)
    except Exception as e:
        print(f'[monitor] _heartbeat_tick: {e}')
    # reschedule via the root widget if available
    if root_widget:
        try:
            _heartbeat_after_id = root_widget.after(60_000, lambda: _heartbeat_tick(root_widget))
        except Exception:
            pass


def register_session(user_info: dict, method: str = 'Password'):
    """Called from main.py at successful login.
    Writes this user into the shared ActiveSessions Excel sheet so all
    other running instances can see them immediately."""
    global _my_username, _heartbeat_after_id
    username  = user_info.get('username', 'unknown')
    full_name = (user_info.get('full_name') or username).strip()
    login_dt  = datetime.datetime.now()
    _my_username = username

    # --- write to shared sheet ---
    try:
        sessions = _read_active_sessions_sheet()
        sessions[username] = {
            'full_name': full_name,
            'role':      user_info.get('role', ''),
            'method':    method,
            'login_dt':  login_dt,
            'heartbeat': login_dt,
        }
        _write_active_sessions_sheet(sessions)
    except Exception as e:
        print(f'[monitor] register_session (sheet write): {e}')

    # --- also write to LoginHistory log ---
    persisted = _append_login_log(username, full_name,
                                   user_info.get('role', ''), login_dt, method)
    _login_history.append({
        'username':  username,
        'full_name': full_name,
        'role':      user_info.get('role', ''),
        'login_dt':  login_dt,
        'method':    method,
        'status':    'Login',
        'persisted': persisted,
    })


def start_heartbeat(root_widget):
    """Call this from main.py after the main Tk window is shown.
    Starts the 60-second heartbeat loop that keeps this session alive
    in the shared ActiveSessions sheet."""
    _heartbeat_tick(root_widget)


def deregister_session(username: str):
    """Called on logout — removes this user from the shared ActiveSessions sheet."""
    global _my_username
    try:
        sessions = _read_active_sessions_sheet()
        entry = sessions.pop(username, None)
        _write_active_sessions_sheet(sessions)
    except Exception as e:
        print(f'[monitor] deregister_session: {e}')
        entry = None

    _my_username = ''

    # record logout in local history
    if entry:
        _login_history.append({
            'username':  username,
            'full_name': entry.get('full_name', username),
            'role':      entry.get('role', ''),
            'login_dt':  entry.get('login_dt', datetime.datetime.now()),
            'logout_dt': datetime.datetime.now(),
            'method':    entry.get('method', ''),
            'status':    'Logout',
        })


# ── Persistent LoginHistory sheet (survives app restarts) ────────────────────
_LOGIN_SHEET = 'LoginHistory'
_LOGIN_HEADERS = ['Username', 'FullName', 'Role', 'LoginDateTime', 'Method']


def _append_login_log(username, full_name, role, login_dt, method) -> bool:
    """Append one row to the LoginHistory sheet so Count/Weekly/Monthly
    stats survive across app restarts. Fails silently (logs to console)
    so a locked/missing workbook never blocks the login flow.
    Returns True on a successful write, False otherwise."""
    try:
        if os.path.exists(XLSX):
            wb = load_workbook(XLSX)
        else:
            wb = Workbook()
        if _LOGIN_SHEET not in wb.sheetnames:
            ws = wb.create_sheet(_LOGIN_SHEET)
            ws.append(_LOGIN_HEADERS)
        else:
            ws = wb[_LOGIN_SHEET]
        ws.append([username, full_name, role,
                   login_dt.strftime('%Y-%m-%d %H:%M:%S'), method])
        wb.save(XLSX)
        return True
    except Exception as e:
        print(f'[monitor] _append_login_log: {e}')
        return False


def _load_login_log():
    """Read the LoginHistory sheet → list of dicts with parsed datetimes."""
    rows = []
    try:
        wb = load_workbook(XLSX, read_only=True, data_only=True)
        if _LOGIN_SHEET not in wb.sheetnames:
            return rows
        ws = wb[_LOGIN_SHEET]
        headers = None
        for row in ws.iter_rows(values_only=True):
            if headers is None:
                headers = [str(h).strip() if h else '' for h in row]
                continue
            if not row or row[0] is None:
                continue
            d = dict(zip(headers, row))
            dt = d.get('LoginDateTime', '')
            rows.append({
                'username':  str(d.get('Username', '')).strip().lower(),
                'full_name': str(d.get('FullName', '')).strip(),
                'role':      str(d.get('Role', '')).strip(),
                'login_dt':  _parse_dt(dt) if dt else None,
                'method':    str(d.get('Method', '')).strip(),
            })
    except Exception as e:
        print(f'[monitor] _load_login_log: {e}')
    return rows


def _all_login_events() -> list:
    """Single de-duplicated source of truth for every Login event:
    the persisted LoginHistory sheet, plus any logins from *this* session
    that have not been confirmed written to disk yet (so nothing is missed
    in the few moments before a save). A login that was already saved is
    never added a second time from memory — that double-add was the cause
    of inflated Count / Weekly / Monthly numbers."""
    events = list(_load_login_log())
    for h in _login_history:
        if h.get('status') == 'Login' and not h.get('persisted'):
            events.append({
                'username':  (h.get('username') or '').strip().lower(),
                'full_name': h.get('full_name', ''),
                'role':      h.get('role', ''),
                'login_dt':  h.get('login_dt'),
                'method':    h.get('method', ''),
            })
    return events


def _login_counts_for(username: str, events: list) -> dict:
    """Total / weekly (last 7 days) / monthly (last 30 days) login counts
    for a given username, computed from a single already-deduplicated
    event list (see _all_login_events)."""
    uname = (username or '').strip().lower()
    now = datetime.datetime.now()
    week_ago  = now - datetime.timedelta(days=7)
    month_ago = now - datetime.timedelta(days=30)

    dts = [e['login_dt'] for e in events
           if e.get('username') == uname and e.get('login_dt')]

    total   = len(dts)
    weekly  = sum(1 for d in dts if d >= week_ago)
    monthly = sum(1 for d in dts if d >= month_ago)
    return {'total': total, 'weekly': weekly, 'monthly': monthly}


def _load_excel_history():
    """Read LastLogin column from Users sheet as supplemental history."""
    rows = []
    try:
        wb = load_workbook(XLSX, read_only=True, data_only=True)
        if 'Users' not in wb.sheetnames:
            return rows
        ws = wb['Users']
        headers = None
        for row in ws.iter_rows(values_only=True):
            if headers is None:
                headers = [str(h).strip() if h else '' for h in row]
                continue
            if not row or row[0] is None:
                continue
            d = dict(zip(headers, row))
            uname = str(d.get('Username', '')).strip()
            ll    = d.get('LastLogin', '')
            if uname and ll:
                rows.append({
                    'username':  uname.lower(),
                    'full_name': str(d.get('FullName', uname)).strip(),
                    'role':      str(d.get('Role', '')).strip(),
                    'last_login': str(ll).strip(),
                    'email':     str(d.get('Email', '')).strip(),
                    'is_active': str(d.get('IsActive', 'True')).strip() in ('True','TRUE','1','true'),
                })
    except Exception as e:
        print(f'[monitor] _load_excel_history: {e}')
    return rows


def _duration_str(dt_start: datetime.datetime) -> str:
    secs = int((datetime.datetime.now() - dt_start).total_seconds())
    if secs < 60:
        return f'{secs}s'
    if secs < 3600:
        return f'{secs//60}m {secs%60}s'
    h = secs // 3600
    m = (secs % 3600) // 60
    return f'{h}h {m}m'


# ════════════════════════════════════════════════════════════════════════════
class AppMonitorView(tk.Frame):

    REFRESH_MS = 30_000  # 30 seconds
    ROW_H = 28            # fixed pixel row height for every table on this page

    def __init__(self, parent, user_info=None, **kw):
        super().__init__(parent, bg=C['bg'], **kw)
        self._user_info  = user_info or {}
        self._filter_var = tk.StringVar()
        self._after_id   = None
        self._build()
        self._refresh()

    def destroy(self):
        if self._after_id:
            try:
                self.after_cancel(self._after_id)
            except Exception:
                pass
        super().destroy()

    # ── layout ──────────────────────────────────────────────────────────────
    def _build(self):
        # ── page header ─────────────────────────────────────────────────────
        hdr = tk.Frame(self, bg=C['topbar'], height=52)
        hdr.pack(fill='x')
        hdr.pack_propagate(False)

        tk.Label(hdr, text='📡  App Monitor',
                 font=('Segoe UI', 14, 'bold'),
                 bg=C['topbar'], fg='white',
                 padx=20).pack(side='left', pady=12)

        tk.Label(hdr, text='Admin · Live Session & Usage Analytics',
                 font=('Segoe UI', 9),
                 bg=C['topbar'], fg='#94a3b8').pack(side='left')

        # refresh button + last-refresh label
        self._last_lbl = tk.Label(hdr, text='',
                                   font=('Segoe UI', 8),
                                   bg=C['topbar'], fg='#64748b')
        self._last_lbl.pack(side='right', padx=8)

        tk.Button(hdr, text='↻  Refresh',
                  font=('Segoe UI', 9, 'bold'),
                  bg='#1e3a8a', fg='white',
                  activebackground='#1e40af', activeforeground='white',
                  relief='flat', bd=0, padx=12, pady=6,
                  cursor='hand2',
                  command=self._refresh).pack(side='right', padx=(0, 6), pady=10)

        # ── scrollable body ─────────────────────────────────────────────────
        canvas = tk.Canvas(self, bg=C['bg'], highlightthickness=0)
        vsb    = ttk.Scrollbar(self, orient='vertical', command=canvas.yview)
        canvas.configure(yscrollcommand=vsb.set)
        vsb.pack(side='right', fill='y')
        canvas.pack(side='left', fill='both', expand=True)
        canvas.bind_all('<MouseWheel>',
            lambda e: canvas.yview_scroll(int(-1*(e.delta/60)), 'units'))

        self._body = tk.Frame(canvas, bg=C['bg'])
        wid = canvas.create_window((0, 0), window=self._body, anchor='nw')
        self._body.bind('<Configure>',
                        lambda e: canvas.configure(scrollregion=canvas.bbox('all')))
        canvas.bind('<Configure>',
                    lambda e: canvas.itemconfig(wid, width=e.width))
        self._canvas = canvas

    # ── refresh ─────────────────────────────────────────────────────────────
    def _refresh(self):
        # cancel pending
        if self._after_id:
            try:
                self.after_cancel(self._after_id)
            except Exception:
                pass

        # clear body
        for w in self._body.winfo_children():
            w.destroy()

        excel_users = _load_excel_history()
        self._render(excel_users)

        now = datetime.datetime.now().strftime('%H:%M:%S')
        self._last_lbl.config(text=f'Last refresh: {now}')

        # schedule next
        self._after_id = self.after(self.REFRESH_MS, self._refresh)

    def _render(self, excel_users):
        pad = {'padx': 16, 'pady': 8}

        # ── KPI row ─────────────────────────────────────────────────────────
        self._kpi_row(excel_users)

        # ── 2-column row: Active Sessions | Hourly Heatmap ──────────────────
        row2 = tk.Frame(self._body, bg=C['bg'])
        row2.pack(fill='x', **pad)
        row2.columnconfigure(0, weight=1)
        row2.columnconfigure(1, weight=2)

        self._active_sessions_card(row2, col=0)
        self._hourly_chart(row2, col=1)

        # ── 2-column row: Login History | User Stats ─────────────────────────
        row3 = tk.Frame(self._body, bg=C['bg'])
        row3.pack(fill='x', **pad)
        row3.columnconfigure(0, weight=2)
        row3.columnconfigure(1, weight=3)

        self._login_history_card(row3, excel_users, col=0)
        self._user_stats_card(row3, excel_users, col=1)

        # ── Method distribution chart ────────────────────────────────────────
        self._method_chart()

    # ── KPI row ─────────────────────────────────────────────────────────────
    def _kpi_row(self, excel_users):
        frame = tk.Frame(self._body, bg=C['bg'])
        frame.pack(fill='x', padx=16, pady=(16, 0))

        shared_sessions = _read_active_sessions_sheet()
        online_count = len(shared_sessions)
        total_users  = len(excel_users)
        active_users = sum(1 for u in excel_users if u.get('is_active'))

        today = datetime.date.today()
        today_logins = sum(
            1 for e in _all_login_events()
            if e.get('login_dt') and e['login_dt'].date() == today
        )

        kpis = [
            ('🟢 Online Now',   str(online_count),   C['G'],       'Active sessions'),
            ('👥 Total Users',  str(total_users),    C['accent'],  'Registered accounts'),
            ('✅ Active Users', str(active_users),   C['chart3'],  'IsActive = True'),
            ('🔑 Today Logins', str(today_logins),   C['accent2'], 'Session count today'),
        ]

        for i, (title, value, color, sub) in enumerate(kpis):
            card = tk.Frame(frame, bg=C['surface'],
                            relief='flat', bd=1,
                            highlightbackground=C['border'],
                            highlightthickness=1)
            card.grid(row=0, column=i, sticky='ew', padx=(0, 10 if i < 3 else 0))
            frame.columnconfigure(i, weight=1)

            tk.Frame(card, bg=color, height=4).pack(fill='x')
            tk.Label(card, text=value,
                     font=('Segoe UI', 28, 'bold'),
                     bg=C['surface'], fg=color).pack(padx=16, pady=(10, 0))
            tk.Label(card, text=title,
                     font=('Segoe UI', 10, 'bold'),
                     bg=C['surface'], fg=C['ink']).pack(padx=16)
            tk.Label(card, text=sub,
                     font=('Segoe UI', 8),
                     bg=C['surface'], fg=C['t2']).pack(padx=16, pady=(0, 10))

    # ── Helper: pixel width matching a header column's char-width ───────────
    def _cell_px(self, width_chars, font=('Segoe UI', 8, 'bold')):
        """Pixel width for a width_chars-wide column, always measured with
        ONE reference font (the header's). Using the same reference font for
        every cell in a column — instead of relying on tk.Label's own
        character-based `width=`, whose pixel size shifts with that label's
        own font weight/size — is what keeps header and body cells
        perfectly aligned even when a body cell is bold and its header
        isn't (or vice-versa)."""
        f = tkfont.Font(family=font[0], size=font[1],
                          weight=font[2] if len(font) > 2 else 'normal')
        return f.measure('0' * width_chars) + 12  # +12 = 6px gutter each side

    def _row(self, parent, bg, cells, pady=0):
        """Render one perfectly-aligned table row.
        cells: list of (text, width_chars, fg, font) tuples. Every cell is
        wrapped in a fixed (width x ROW_H) frame, so its rendered size never
        depends on its own font and its content is never clipped vertically
        — the bug that made the Active Sessions username disappear."""
        rf = tk.Frame(parent, bg=bg)
        rf.pack(fill='x', padx=8, pady=pady)
        for text, width_chars, fg, font in cells:
            cell = tk.Frame(rf, bg=bg,
                             width=self._cell_px(width_chars), height=self.ROW_H)
            cell.pack(side='left')
            cell.pack_propagate(False)
            tk.Label(cell, text=str(text), font=font, bg=bg, fg=fg,
                     anchor='w', padx=6).pack(fill='both', expand=True)
        return rf

    def _header_row(self, parent, cols, pady=(4, 0)):
        """cols: list of (text, width_chars). Renders the dark table header
        using the same _cell_px sizing as the body rows below it."""
        self._row(parent, '#1e293b',
                  [(txt, w, 'white', ('Segoe UI', 8, 'bold')) for txt, w in cols],
                  pady=pady)

    # ── Active Sessions card ─────────────────────────────────────────────────
    def _active_sessions_card(self, parent, col):
        card = self._card(parent, '🟢  Active Sessions', col=col, row=0)

        shared_sessions = _read_active_sessions_sheet()

        if not shared_sessions:
            tk.Label(card, text='No active sessions',
                     font=('Segoe UI', 10, 'italic'),
                     bg=C['surface'], fg=C['t2']).pack(pady=20)
            return

        # header row
        self._header_row(card, [('User', 16), ('Role', 10), ('Method', 10), ('Duration', 10)])

        for i, (uname, info) in enumerate(shared_sessions.items()):
            bg = C['surface'] if i % 2 == 0 else '#f8fafc'
            rf = tk.Frame(card, bg=bg)
            rf.pack(fill='x', padx=8)

            # User cell: fixed WIDTH *and* HEIGHT (this was the bug — the old
            # code only set width on a pack_propagate(False) frame, so with
            # no height it collapsed to ~1px tall and silently clipped the
            # dot + name to invisible).
            user_cell = tk.Frame(rf, bg=bg,
                                  width=self._cell_px(16), height=self.ROW_H)
            user_cell.pack(side='left')
            user_cell.pack_propagate(False)

            cv = tk.Canvas(user_cell, width=8, height=8, bg=bg,
                           highlightthickness=0)
            cv.pack(side='left', padx=(6, 4))
            cv.create_oval(0, 0, 8, 8, fill=C['online'], outline='')

            display_name = (info.get('full_name') or uname or '—').strip()
            tk.Label(user_cell, text=display_name[:14],
                     font=('Segoe UI', 8),
                     bg=bg, fg=C['ink'],
                     anchor='w').pack(side='left', fill='both', expand=True)

            role_col = {'Admin': C['accent2'], 'Manager': C['accent'],
                        'Viewer': C['t2']}.get(info['role'], C['t2'])
            method_col = C['G'] if info.get('method') == 'OTP' else C['accent']

            for txt, w, fg in [
                (info['role'],                  10, role_col),
                (info.get('method', 'Pwd'),     10, method_col),
                (_duration_str(info['login_dt']), 10, C['A']),
            ]:
                cell = tk.Frame(rf, bg=bg,
                                 width=self._cell_px(w), height=self.ROW_H)
                cell.pack(side='left')
                cell.pack_propagate(False)
                tk.Label(cell, text=str(txt), font=('Segoe UI', 8, 'bold'),
                         bg=bg, fg=fg, anchor='w', padx=6).pack(fill='both', expand=True)

            tk.Frame(card, bg=C['border'], height=1).pack(fill='x', padx=8)

    # ── Hourly login heatmap (canvas chart) ─────────────────────────────────
    def _hourly_chart(self, parent, col):
        card = self._card(parent, '📊  Login Activity — Hourly Heatmap (Today)', col=col, row=0)

        # count logins per hour (0-23)
        counts = [0] * 24
        today  = datetime.date.today()
        for e in _all_login_events():
            dt = e.get('login_dt')
            if dt and dt.date() == today:
                counts[dt.hour] += 1

        W, H = 640, 150
        cv = tk.Canvas(card, width=W, height=H,
                       bg=C['surface'], highlightthickness=0)
        cv.pack(padx=12, pady=(4, 8), fill='x')

        max_c = max(counts) if max(counts) > 0 else 1
        bar_w = (W - 60) // 24
        base_y = H - 30

        colors_grad = ['#dbeafe', '#93c5fd', '#60a5fa', '#3b82f6', '#1d4ed8', '#1e3a8a']

        for i, cnt in enumerate(counts):
            x1 = 40 + i * bar_w
            x2 = x1 + bar_w - 2
            bar_h = int((cnt / max_c) * (H - 50)) if cnt > 0 else 3
            y1 = base_y - bar_h
            y2 = base_y

            # pick gradient color
            ci = min(int((cnt / max_c) * (len(colors_grad) - 1)), len(colors_grad) - 1)
            fill = colors_grad[ci] if cnt > 0 else '#e2e8f0'

            cv.create_rectangle(x1, y1, x2, y2, fill=fill, outline='')

            if cnt > 0:
                cv.create_text((x1+x2)//2, y1 - 4,
                               text=str(cnt),
                               font=('Segoe UI', 7, 'bold'),
                               fill=C['accent'])

            # hour label every 3 hours
            if i % 3 == 0:
                cv.create_text((x1+x2)//2, base_y + 10,
                               text=f'{i:02d}',
                               font=('Segoe UI', 7),
                               fill=C['t2'])

        # current hour marker
        cur_h = datetime.datetime.now().hour
        cx = 40 + cur_h * bar_w + bar_w // 2
        cv.create_line(cx, 10, cx, base_y, fill='#ef4444', width=1, dash=(3, 3))
        cv.create_text(cx, 8, text='NOW', font=('Segoe UI', 6, 'bold'), fill='#ef4444')

        # y-axis label
        cv.create_text(20, H // 2, text='Logins', font=('Segoe UI', 7),
                       fill=C['t2'], angle=90)

        if max(counts) == 0:
            cv.create_text(W // 2, H // 2,
                           text='No logins recorded today yet',
                           font=('Segoe UI', 10, 'italic'),
                           fill=C['t2'])

    # ── Login History table ──────────────────────────────────────────────────
    def _login_history_card(self, parent, excel_users, col):
        card = self._card(parent, '📋  Login History', col=col, row=0)

        # filter bar
        ff = tk.Frame(card, bg=C['surface'])
        ff.pack(fill='x', padx=8, pady=(4, 6))
        tk.Label(ff, text='Filter:', font=('Segoe UI', 9),
                 bg=C['surface'], fg=C['t2']).pack(side='left')
        te = tk.Entry(ff, textvariable=self._filter_var,
                      font=('Segoe UI', 9),
                      relief='solid', bd=1, width=20)
        te.pack(side='left', padx=6)
        tk.Button(ff, text='Clear', font=('Segoe UI', 8),
                  bg='#f1f5f9', fg=C['t2'],
                  relief='flat', bd=0, padx=8, pady=3,
                  cursor='hand2',
                  command=lambda: self._filter_var.set('')).pack(side='left')

        # table header
        self._header_row(card, [('Time', 14), ('User', 14), ('Role', 8), ('Method', 8), ('Status', 8)], pady=0)

        # combine in-memory history + excel last-login
        combined = list(reversed(_login_history[-50:]))  # most recent first

        flt = self._filter_var.get().strip().lower()
        if flt:
            combined = [h for h in combined
                        if flt in h.get('username', '').lower()
                        or flt in h.get('full_name', '').lower()
                        or flt in h.get('role', '').lower()]

        if not combined:
            # fallback to excel users last-login
            for u in excel_users:
                if u.get('last_login') and u['last_login'] != 'None':
                    combined.append({
                        'login_dt':  _parse_dt(u['last_login']),
                        'username':  u['username'],
                        'full_name': u['full_name'],
                        'role':      u['role'],
                        'method':    '—',
                        'status':    'Last Login (Excel)',
                    })
            combined.sort(key=lambda x: x.get('login_dt') or datetime.datetime.min, reverse=True)
            combined = combined[:30]

        for i, entry in enumerate(combined[:30]):
            bg = C['surface'] if i % 2 == 0 else '#f8fafc'

            dt = entry.get('login_dt')
            dt_str = dt.strftime('%m/%d %H:%M:%S') if isinstance(dt, datetime.datetime) else str(dt)[:16]

            status = entry.get('status', 'Login')
            status_col = C['G'] if status == 'Login' else (C['R'] if status == 'Logout' else C['t2'])

            self._row(card, bg, [
                (dt_str,                            14, C['ink'], ('Segoe UI', 8)),
                (entry.get('full_name', '')[:14],   14, C['ink'], ('Segoe UI', 8)),
                (entry.get('role', ''),              8, C['accent2'], ('Segoe UI', 8)),
                (entry.get('method', '—'),           8, C['t2'], ('Segoe UI', 8)),
                (status,                              8, status_col, ('Segoe UI', 8)),
            ])

            tk.Frame(card, bg=C['border'], height=1).pack(fill='x')

    # ── Per-user stats ───────────────────────────────────────────────────────
    def _user_stats_card(self, parent, excel_users, col):
        card = self._card(parent, '👤  User Statistics', col=col, row=0)

        cols = [('User', 13), ('Role', 8), ('Last Login', 12),
                ('Active', 7), ('Count', 7), ('Weekly', 7), ('Monthly', 8)]
        self._header_row(card, cols, pady=(4, 0))

        online_names = {u.lower() for u in _read_active_sessions_sheet().keys()}
        events = _all_login_events()

        for i, u in enumerate(excel_users):
            bg = C['surface'] if i % 2 == 0 else '#f8fafc'

            is_online = u['username'].lower() in online_names
            name_col  = C['G'] if is_online else C['ink']
            prefix    = '🟢 ' if is_online else '   '

            role_col = {'Admin': C['accent2'], 'Manager': C['accent'],
                        'Viewer': C['t2']}.get(u['role'], C['t2'])

            ll = u.get('last_login', '—')
            ll = str(ll)[:12] if ll and ll != 'None' else 'Never'

            # 'Active' now reflects the live session (IN/OUT) rather than
            # the static IsActive flag from Excel — that's what this column
            # is for on a *live* monitor page; IsActive still drives the
            # 'Active Users' KPI card above.
            active_txt = 'IN' if is_online else 'OUT'
            active_col = C['G'] if is_online else C['t2']

            counts = _login_counts_for(u['username'], events)

            self._row(card, bg, [
                (prefix + u['full_name'][:10], 13, name_col,
                 ('Segoe UI', 8, 'bold' if is_online else 'normal')),
                (u['role'],              8, role_col,      ('Segoe UI', 8)),
                (ll,                    12, C['t2'],        ('Segoe UI', 8)),
                (active_txt,             7, active_col,     ('Segoe UI', 8, 'bold')),
                (str(counts['total']),   7, C['accent'],    ('Segoe UI', 8, 'bold')),
                (str(counts['weekly']),  7, C['chart3'],    ('Segoe UI', 8)),
                (str(counts['monthly']), 8, C['accent2'],   ('Segoe UI', 8)),
            ])

            tk.Frame(card, bg=C['border'], height=1).pack(fill='x', padx=8)

    # ── Login method distribution ────────────────────────────────────────────
    def _method_chart(self):
        card = self._card(self._body, '🔑  Login Method Distribution (This Session)',
                          col=None, row=None, full=True)

        pwd_count = sum(1 for h in _login_history
                        if h.get('method') == 'Password' and h.get('status') == 'Login')
        otp_count = sum(1 for h in _login_history
                        if h.get('method') == 'OTP' and h.get('status') == 'Login')
        total = pwd_count + otp_count or 1

        W, H = 500, 100
        cv = tk.Canvas(card, width=W, height=H,
                       bg=C['surface'], highlightthickness=0)
        cv.pack(padx=16, pady=(4, 12))

        # stacked bar
        bar_x, bar_y, bar_w, bar_h = 80, 30, 350, 40
        pwd_w = int((pwd_count / total) * bar_w)
        otp_w = bar_w - pwd_w

        if pwd_w > 0:
            cv.create_rectangle(bar_x, bar_y, bar_x + pwd_w, bar_y + bar_h,
                                 fill=C['accent'], outline='')
            cv.create_text(bar_x + pwd_w // 2, bar_y + bar_h // 2,
                           text=f'Password\n{pwd_count} ({pwd_count*100//total}%)',
                           font=('Segoe UI', 8, 'bold'), fill='white')

        if otp_w > 0:
            cv.create_rectangle(bar_x + pwd_w, bar_y, bar_x + bar_w, bar_y + bar_h,
                                 fill=C['G'], outline='')
            cv.create_text(bar_x + pwd_w + otp_w // 2, bar_y + bar_h // 2,
                           text=f'OTP\n{otp_count} ({otp_count*100//total}%)',
                           font=('Segoe UI', 8, 'bold'), fill='white')

        if pwd_count == 0 and otp_count == 0:
            cv.create_text(W // 2, H // 2,
                           text='No login events recorded in this session',
                           font=('Segoe UI', 10, 'italic'), fill=C['t2'])

        # legend
        for xi, (label, color) in enumerate(
                [('Password', C['accent']), ('OTP Email', C['G'])]):
            lx = bar_x + xi * 160
            cv.create_rectangle(lx, bar_y + bar_h + 10,
                                  lx + 14, bar_y + bar_h + 24,
                                  fill=color, outline='')
            cv.create_text(lx + 20, bar_y + bar_h + 17,
                           text=label, font=('Segoe UI', 8),
                           fill=C['ink'], anchor='w')

    # ── Helper: card container ───────────────────────────────────────────────
    def _card(self, parent, title, col=None, row=0, full=False):
        outer = tk.Frame(parent,
                         bg=C['surface'],
                         relief='flat',
                         highlightbackground=C['border'],
                         highlightthickness=1)
        if full:
            outer.pack(fill='x', padx=16, pady=(0, 12))
        else:
            outer.grid(row=row, column=col, sticky='nsew',
                       padx=(0, 12 if col == 0 else 0), pady=(0, 0))

        # card header
        hdr = tk.Frame(outer, bg=C['card_hdr'], height=36)
        hdr.pack(fill='x')
        hdr.pack_propagate(False)
        tk.Label(hdr, text=title,
                 font=('Segoe UI', 10, 'bold'),
                 bg=C['card_hdr'], fg='white',
                 padx=12).pack(side='left', pady=8)

        return outer


def _parse_dt(s):
    for fmt in ('%Y-%m-%d %H:%M', '%Y-%m-%d %H:%M:%S', '%Y-%m-%d'):
        try:
            return datetime.datetime.strptime(str(s).strip(), fmt)
        except ValueError:
            continue
    return datetime.datetime.min
