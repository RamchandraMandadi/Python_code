"""
main_window.py  — Top-nav Portfolio Manager window
Matches Image 1: smoke-grey topbar + tab navigation + content area
"""
import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
import datetime
import os
from PIL import Image, ImageTk

from services.portfolio_service import PortfolioService
from ui.dashboard_view   import DashboardView
from ui.portfolio_view   import PortfolioView
from ui.rag_summary_view import RagSummaryView
from ui.project_status_summary_view import ProjectStatusSummaryView
from ui.app_monitor_view import AppMonitorView

# ── Palette ─────────────────────────────────────────────────────────────────
C = {
    'topbar':     '#4a5568',   # smoke grey — KMG dark logo is visible on this
    'topbar_txt': '#f1f5f9',   # light text on smoke grey
    'tab_act_bg': '#2952e3',
    'bg':         '#f0f2f7',
    'accent':     '#2952e3',
    'surface':    '#ffffff',
    'border':     '#dde1ed',
    'ink':        '#000000',
    't2':         '#000000',
    'R':          '#e53935',
    'A':          '#f59e0b',
    'G':          '#16a34a',
}


class MainWindow:

    def __init__(self, root, user_info=None, on_logout=None):
        self.root       = root
        self.svc        = PortfolioService()
        self._active    = 'dashboard'
        self._user_info = user_info or {}
        self._on_logout = on_logout

        self.root.title('KMG Portfolio Mgmt')
        self.root.geometry('1440x860')
        self.root.minsize(1024, 680)
        self.root.configure(bg=C['bg'])
        self._set_window_icon()

        self._build_topbar()
        self._build_content()
        self._show('dashboard')

    def _set_window_icon(self):
        """Sets the taskbar / title-bar icon to the KMG logo (kept alive on self)."""
        icon_path = os.path.join(os.path.dirname(__file__), '..', 'assets', 'images', 'kmg-logo.png')
        try:
            pil_icon = Image.open(icon_path).convert('RGBA')
            self._window_icon_img = ImageTk.PhotoImage(pil_icon)
            self.root.iconphoto(True, self._window_icon_img)
        except Exception:
            pass

    # ══════════════════════════════════════════════════════════════════════════
    # TOP BAR
    # ══════════════════════════════════════════════════════════════════════════
    def _build_topbar(self):
        bar = tk.Frame(self.root, bg=C['topbar'], height=52)
        bar.pack(fill='x')
        bar.pack_propagate(False)

        brand = tk.Frame(bar, bg=C['topbar'])
        brand.pack(side='left', padx=(16, 0))

        logo_path = os.path.join(os.path.dirname(__file__), '..', 'assets', 'images', 'kmg-logo.png')
        try:
            pil_img = Image.open(logo_path).convert('RGBA')
            bg_img = Image.new('RGBA', pil_img.size, (74, 85, 104, 255))
            bg_img.paste(pil_img, mask=pil_img.split()[3])
            aspect = pil_img.width / pil_img.height
            new_h, new_w = 34, int(34 * aspect)
            bg_img = bg_img.resize((new_w, new_h), Image.LANCZOS)
            self._kmg_logo = ImageTk.PhotoImage(bg_img)
            tk.Label(brand, image=self._kmg_logo, bg=C['topbar'], bd=0).pack(side='left')
        except Exception:
            tk.Label(brand, text='KMG', bg=C['accent'], fg='white',
                     font=('Segoe UI', 11, 'bold'), padx=8, pady=4).pack(side='left')

        tk.Label(brand, text='Portfolio', font=('Segoe UI', 13, 'bold'),
                 bg=C['topbar'], fg=C['topbar_txt']).pack(side='left', padx=(10, 0))
        tk.Label(brand, text='Mgmt', font=('Segoe UI', 13),
                 bg=C['topbar'], fg='#a5c8ff').pack(side='left', padx=(3, 24))

        self._tab_btns = {}
        nav = tk.Frame(bar, bg=C['topbar'])
        nav.pack(side='left')

        tabs = [
            ('dashboard',      '📊 Dashboard'),
            ('portfolio',      '📁 Portfolio'),
            ('rag',            '📋 RAG Summary'),
            ('timeline',       '📅 Timeline'),
            ('status_summary', '📄 Project Status'),
        ]

        # Admin-only: App Monitor tab
        _role = self._user_info.get('role', '')
        if _role == 'Admin':
            tabs.append(('app_monitor', '📡 App Monitor'))
        for key, label in tabs:
            btn = tk.Label(nav, text=label,
                           font=('Segoe UI', 10),
                           bg=C['topbar'], fg=C['topbar_txt'],
                           padx=14, pady=16, cursor='hand2')
            btn.pack(side='left')
            btn.bind('<Button-1>', lambda e, k=key: self._show(k))
            btn.bind('<Enter>',
                     lambda e, b=btn, k=key: b.config(bg='#374151') if k != self._active else None)
            btn.bind('<Leave>',
                     lambda e, b=btn, k=key: b.config(
                         bg='#1a2845' if k == self._active else C['topbar']))
            self._tab_btns[key] = btn

        self._build_user_menu(bar)

        tk.Button(bar, text='  + New Project  ',
                  font=('Segoe UI', 10, 'bold'),
                  bg=C['accent'], fg='white',
                  activebackground='#3461f0', activeforeground='white',
                  relief='flat', bd=0, cursor='hand2',
                  command=self._new_project).pack(side='right', padx=(0, 6), pady=10)

    def _build_user_menu(self, bar):
        info = self._user_info
        full_name = info.get('full_name') or info.get('username', 'User')
        role      = info.get('role', '')
        initials  = ''.join(p[0].upper() for p in full_name.split()[:2]) or 'U'

        user_frame = tk.Frame(bar, bg=C['topbar'])
        user_frame.pack(side='right', padx=(0, 10))

        av = tk.Canvas(user_frame, width=30, height=30, bg=C['topbar'],
                       highlightthickness=0, bd=0)
        av.pack(side='left', pady=11)
        av.create_oval(0, 0, 30, 30, fill=C['accent'], outline='')
        av.create_text(15, 15, text=initials, fill='white',
                       font=('Segoe UI', 9, 'bold'))

        name_lbl = tk.Label(user_frame, text=full_name,
                            font=('Segoe UI', 9, 'bold'),
                            bg=C['topbar'], fg=C['topbar_txt'],
                            cursor='hand2')
        name_lbl.pack(side='left', padx=(6, 2))

        arrow = tk.Label(user_frame, text='▾',
                         font=('Segoe UI', 9),
                         bg=C['topbar'], fg='#94a3b8', cursor='hand2')
        arrow.pack(side='left', padx=(0, 8))

        def _show_popup(event=None):
            popup = tk.Toplevel(self.root)
            popup.overrideredirect(True)
            popup.configure(bg='white')
            popup.attributes('-topmost', True)
            x = user_frame.winfo_rootx()
            y = user_frame.winfo_rooty() + user_frame.winfo_height() + 2
            popup.geometry(f'210x125+{x}+{y}')

            outer = tk.Frame(popup, bg='#dde1ed', bd=1, relief='solid')
            outer.pack(fill='both', expand=True, padx=1, pady=1)

            tk.Label(outer, text=full_name,
                     font=('Segoe UI', 10, 'bold'),
                     bg='white', fg='#1e293b',
                     anchor='w').pack(fill='x', padx=14, pady=(10, 0))
            tk.Label(outer, text=role,
                     font=('Segoe UI', 9),
                     bg='white', fg='#64748b',
                     anchor='w').pack(fill='x', padx=14)
            tk.Label(outer, text=info.get('email', ''),
                     font=('Segoe UI', 8),
                     bg='white', fg='#94a3b8',
                     anchor='w').pack(fill='x', padx=14)

            tk.Frame(outer, bg='#e2e8f0', height=1).pack(fill='x', pady=6)

            def _logout():
                popup.destroy()
                if messagebox.askyesno('Sign Out', 'Sign out of Portfolio Mgmt?', parent=self.root):
                    if self._on_logout:
                        self._on_logout()

            logout_btn = tk.Button(outer, text='⏻  Sign Out',
                                   font=('Segoe UI', 9, 'bold'),
                                   bg='white', fg='#e53935',
                                   activebackground='#fef2f2',
                                   activeforeground='#e53935',
                                   relief='flat', bd=0,
                                   anchor='w', padx=14, pady=6,
                                   cursor='hand2',
                                   command=_logout)
            logout_btn.pack(fill='x')
            popup.bind('<FocusOut>', lambda e: popup.destroy())
            popup.focus_set()

        for w in (av, name_lbl, arrow):
            w.bind('<Button-1>', _show_popup)


    def _update_tabs(self):
        for key, btn in self._tab_btns.items():
            if key == self._active:
                btn.config(fg='white',
                           bg='#1a2845',
                           font=('Segoe UI', 10, 'bold'))
            else:
                btn.config(fg=C['topbar_txt'],
                           bg=C['topbar'],
                           font=('Segoe UI', 10))

    # ══════════════════════════════════════════════════════════════════════════
    # CONTENT AREA
    # ══════════════════════════════════════════════════════════════════════════
    def _build_content(self):
        self.content = tk.Frame(self.root, bg=C['bg'])
        self.content.pack(fill='both', expand=True)

    def _show(self, tab):
        self._active = tab
        self._update_tabs()

        # clear content
        for w in self.content.winfo_children():
            w.destroy()

        if tab == 'dashboard':
            DashboardView(self.content, self.svc).pack(fill='both', expand=True)
        elif tab == 'portfolio':
            PortfolioView(self.content, self.svc,
                          on_open_detail=self._open_detail).pack(fill='both', expand=True)
        elif tab == 'rag':
            RagSummaryView(self.content, self.svc).pack(fill='both', expand=True)
        elif tab == 'timeline':
            self._show_timeline()
        elif tab == 'status_summary':
            ProjectStatusSummaryView(self.content, self.svc).pack(fill='both', expand=True)
        elif tab == 'app_monitor':
            AppMonitorView(self.content, user_info=self._user_info).pack(fill='both', expand=True)

    def _show_timeline(self):
        from ui.timeline_view import TimelineView
        tv = TimelineView(self.content, self.svc, sheet_name='Tasks')
        tv.pack(fill='both', expand=True)

    def _recalculate(self):
        from tkinter import messagebox
        self.svc.refresh_all_statuses()
        messagebox.showinfo('Done', 'Project statuses recalculated.\n\nGreen = all tasks complete\nAmber = in progress\nRed = overdue')
        self._show(self._active)

    # ══════════════════════════════════════════════════════════════════════════
    # NEW PROJECT DIALOG
    # ══════════════════════════════════════════════════════════════════════════
    def _new_project(self):
        dialog = _NewProjectDialog(self.root, self.svc)
        self.root.wait_window(dialog)
        if dialog.saved:
            self._show(self._active)

    # ══════════════════════════════════════════════════════════════════════════
    # PROJECT DETAIL (click card → task list)
    # ══════════════════════════════════════════════════════════════════════════
    def _open_detail(self, pid):
        from ui.project_detail_view import ProjectDetailView
        for w in self.content.winfo_children():
            w.destroy()
        ProjectDetailView(self.content, self.svc, pid,
                          on_back=lambda: self._show('portfolio')).pack(fill='both', expand=True)


# ══════════════════════════════════════════════════════════════════════════════
# NEW PROJECT DIALOG
# ══════════════════════════════════════════════════════════════════════════════
class _NewProjectDialog(tk.Toplevel):

    RAG_ASPECTS = ['Scope','Schedule','Budget','Changes','Issues',
                   'Risks','Dependencies','Resourcing','Technical','Change Mgmt']

    def __init__(self, parent, svc):
        super().__init__(parent)
        self.svc      = svc
        self.saved    = False
        self.rag_data = {asp: {'status':'G','exp':''} for asp in self.RAG_ASPECTS}
        self.title('New Project')
        self.resizable(True, True)
        self.configure(bg='white')
        self.grab_set()
        self._build()
        self.update_idletasks()
        self.geometry('680x820')
        x = parent.winfo_rootx() + parent.winfo_width()//2  - 340
        y = max(parent.winfo_rooty() + 30, 20)
        self.geometry(f'+{x}+{y}')

    # ──────────────────────────────────────────────────────────────────────────
    def _build(self):
        C = {'topbar':'#000000','accent':'#2952e3','bg':'white',
             'ink':'#000000','t2':'#000000','border':'#dde1ed',
             'R':'#e53935','A':'#f59e0b','G':'#16a34a'}

        # ── header ────────────────────────────────────────────────────────────
        hdr = tk.Frame(self, bg=C['topbar'], height=52)
        hdr.pack(fill='x')
        hdr.pack_propagate(False)
        tk.Label(hdr, text='  + New Project',
                 font=('Segoe UI', 13, 'bold'),
                 bg=C['topbar'], fg='white', pady=14).pack(side='left')
        tk.Label(hdr, text='Fill in project details and set initial RAG status',
                 font=('Segoe UI', 9), bg=C['topbar'],
                 fg='#ffffff').pack(side='left', padx=8)

        # ── scrollable body ───────────────────────────────────────────────────
        canvas = tk.Canvas(self, bg='white', highlightthickness=0)
        vsb    = ttk.Scrollbar(self, orient='vertical', command=canvas.yview)
        canvas.configure(yscrollcommand=vsb.set)
        vsb.pack(side='right', fill='y')
        canvas.pack(side='top', fill='both', expand=True)
        canvas.bind_all('<MouseWheel>',
            lambda e: canvas.yview_scroll(int(-1*(e.delta/60)),'units'))

        body = tk.Frame(canvas, bg='white', padx=28, pady=18)
        wid  = canvas.create_window((0,0), window=body, anchor='nw')
        body.bind('<Configure>',
                  lambda e: canvas.configure(scrollregion=canvas.bbox('all')))
        canvas.bind('<Configure>',
                    lambda e: canvas.itemconfig(wid, width=e.width))

        # ── Project fields ────────────────────────────────────────────────────
        today      = datetime.date.today().strftime('%Y-%m-%d')
        self.vars  = {}
        left_fields = [
            ('ProjectID',   'Project ID *',   ''),
            ('ProjectName', 'Project Name *', ''),
            ('Manager',     'Manager *',      ''),
            ('Client',      'Client',         ''),
        ]
        right_fields = [
            ('Department', 'Department',  ''),
            ('Priority',   'Priority',    'High'),
            ('StartDate',  'Start Date',  today),
            ('EndDate',    'End Date',    ''),
        ]

        two = tk.Frame(body, bg='white')
        two.pack(fill='x', pady=(0,8))
        two.columnconfigure(0, weight=1)
        two.columnconfigure(1, weight=1)

        for col_idx, field_list in enumerate([left_fields, right_fields]):
            col = tk.Frame(two, bg='white')
            col.grid(row=0, column=col_idx, sticky='nsew', padx=(0 if col_idx==0 else 12, 0))
            for i, (key, label, default) in enumerate(field_list):
                tk.Label(col, text=label, font=('Segoe UI', 9, 'bold'),
                         bg='white', fg=C['ink'], anchor='w').grid(
                    row=i*2, column=0, sticky='w', pady=(8,1))
                v = tk.StringVar(value=default)
                self.vars[key] = v
                if key == 'Priority':
                    w = ttk.Combobox(col, textvariable=v, width=24,
                                     values=['Critical','High','Medium','Low'],
                                     state='readonly')
                    w.grid(row=i*2+1, column=0, sticky='ew', pady=(0,2))
                elif key in ('StartDate', 'EndDate'):
                    from ui.date_picker import DateEntry
                    w = DateEntry(col, textvariable=v, width=18)
                    w.grid(row=i*2+1, column=0, sticky='w', pady=(0,2))
                else:
                    w = tk.Entry(col, textvariable=v, width=26,
                                 font=('Segoe UI', 9), relief='solid', bd=1)
                    w.grid(row=i*2+1, column=0, sticky='ew', pady=(0,2))

        # budget / spent row
        brow = tk.Frame(body, bg='white')
        brow.pack(fill='x', pady=(0,8))
        brow.columnconfigure(0, weight=1)
        brow.columnconfigure(1, weight=1)
        for ci, (key, label) in enumerate([('Budget','Budget ($)'),('Spent','Spent ($)')]):
            tk.Label(brow, text=label, font=('Segoe UI', 9, 'bold'),
                     bg='white', fg=C['ink'], anchor='w').grid(
                row=0, column=ci, sticky='w', padx=(0 if ci==0 else 12, 0), pady=(0,1))
            v = tk.StringVar(value='')
            self.vars[key] = v
            tk.Entry(brow, textvariable=v, width=26,
                     font=('Segoe UI', 9), relief='solid', bd=1).grid(
                row=1, column=ci, sticky='ew', padx=(0 if ci==0 else 12, 0))

        # description
        tk.Label(body, text='Description', font=('Segoe UI', 9, 'bold'),
                 bg='white', fg=C['ink'], anchor='w').pack(fill='x', pady=(8,2))
        v = tk.StringVar()
        self.vars['Description'] = v
        tk.Entry(body, textvariable=v, font=('Segoe UI', 9),
                 relief='solid', bd=1).pack(fill='x', pady=(0,12))

        # ── RAG Status section ────────────────────────────────────────────────
        tk.Frame(body, bg='#dde1ed', height=1).pack(fill='x', pady=(4,12))

        rag_hdr = tk.Frame(body, bg='white')
        rag_hdr.pack(fill='x', pady=(0,4))
        tk.Frame(rag_hdr, bg=C['accent'], width=4).pack(side='left', fill='y')
        tk.Label(rag_hdr, text='  RAG Status — Set per Aspect',
                 font=('Segoe UI', 11, 'bold'),
                 bg='white', fg=C['ink']).pack(side='left')

        tk.Label(body,
                 text='Overall auto-calculates: Red if any Red → Amber if any Amber → Green if all Green',
                 font=('Segoe UI', 8), bg='white', fg=C['t2'],
                 anchor='w').pack(fill='x', pady=(0,10))

        # table header
        th = tk.Frame(body, bg='#000000')
        th.pack(fill='x')
        th.columnconfigure(1, minsize=130)
        th.columnconfigure(2, weight=1)
        for ci, (lbl, w) in enumerate([('ASPECT',160),('STATUS',130),('EXPLANATION (REQUIRED FOR R/A)',300)]):
            tk.Label(th, text=lbl, font=('Segoe UI', 8, 'bold'),
                     bg='#000000', fg='#ffffff',
                     padx=10, pady=7, anchor='w',
                     width=w//7).grid(row=0, column=ci, sticky='ew')

        # Overall row (read-only, auto-computed)
        self._overall_var  = tk.StringVar(value='G')
        self._overall_lbl  = None
        ov_row = tk.Frame(body, bg='#f7f8fc')
        ov_row.pack(fill='x')
        tk.Label(ov_row, text='Overall', font=('Segoe UI', 9, 'bold'),
                 bg='#f7f8fc', fg=C['ink'], padx=10, pady=8,
                 anchor='w', width=160//7).grid(row=0, column=0, sticky='ew')
        self._overall_badge = tk.Label(ov_row, text='G', width=3,
                                        bg=C['G'], fg='white',
                                        font=('Segoe UI', 9, 'bold'), pady=4)
        self._overall_badge.grid(row=0, column=1, padx=10, sticky='w')
        tk.Label(ov_row, text='Auto: Green — all aspects are Green',
                 font=('Segoe UI', 8), bg='#f7f8fc', fg=C['t2'],
                 anchor='w', padx=6).grid(row=0, column=2, sticky='ew')
        ov_row.columnconfigure(2, weight=1)
        tk.Frame(body, bg='#dde1ed', height=1).pack(fill='x')

        # per-aspect rows
        self._exp_vars = {}
        self._rag_btns = {}
        for i, asp in enumerate(self.RAG_ASPECTS):
            bg = 'white' if i % 2 == 0 else '#f7f8fc'
            r  = tk.Frame(body, bg=bg)
            r.pack(fill='x')
            r.columnconfigure(2, weight=1)

            tk.Label(r, text=asp, font=('Segoe UI', 9),
                     bg=bg, fg=C['ink'], padx=10, pady=7,
                     anchor='w', width=160//7).grid(row=0, column=0, sticky='ew')

            btn_frame = tk.Frame(r, bg=bg)
            btn_frame.grid(row=0, column=1, sticky='w', padx=8)

            self._rag_btns[asp] = {}
            for code, color in [('R',C['R']),('A',C['A']),('G',C['G'])]:
                def _pick(c=code, a=asp, col=color):
                    self.rag_data[a]['status'] = c
                    for k, b in self._rag_btns[a].items():
                        b.config(bg=self._rag_btns[a][k].orig_col if k==c else '#e5e7eb',
                                 fg='white' if k==c else '#000000',
                                 relief='sunken' if k==c else 'flat')
                    self._update_overall()
                active = (code == 'G')
                b = tk.Button(btn_frame, text=code, width=2,
                              bg=color if active else '#e5e7eb',
                              fg='white' if active else '#000000',
                              font=('Segoe UI', 8, 'bold'),
                              relief='sunken' if active else 'flat',
                              bd=0, padx=6, pady=3, cursor='hand2',
                              command=_pick)
                b.orig_col = color
                b.pack(side='left', padx=2)
                self._rag_btns[asp][code] = b

            exp_v = tk.StringVar()
            self._exp_vars[asp] = exp_v
            exp_v.trace_add('write', lambda *_, a=asp, v=exp_v:
                            self.rag_data[a].update({'exp': v.get()}))
            tk.Entry(r, textvariable=exp_v, font=('Segoe UI', 8),
                     relief='solid', bd=1,
                     fg='#000000').grid(row=0, column=2, sticky='ew',
                                        padx=(4,10), pady=4)
            tk.Frame(body, bg='#dde1ed', height=1).pack(fill='x')

        # ── footer buttons (outside scroll) ───────────────────────────────────
        footer = tk.Frame(self, bg='white', pady=12, padx=24,
                          relief='ridge', bd=0)
        footer.pack(fill='x', side='bottom')
        tk.Frame(footer, bg='#dde1ed', height=1).pack(fill='x', pady=(0,10))
        tk.Button(footer, text='Save Project',
                  font=('Segoe UI', 10, 'bold'),
                  bg=C['accent'], fg='white',
                  activebackground='#3461f0', activeforeground='white',
                  relief='flat', bd=0, padx=20, pady=9,
                  cursor='hand2', command=self._save).pack(side='right', padx=(8,0))
        tk.Button(footer, text='Cancel',
                  font=('Segoe UI', 10), bg='#f0f2f7', fg=C['ink'],
                  relief='flat', bd=0, padx=20, pady=9,
                  cursor='hand2', command=self.destroy).pack(side='right')

    def _update_overall(self):
        statuses = [d['status'] for d in self.rag_data.values()]
        overall  = 'R' if 'R' in statuses else ('A' if 'A' in statuses else 'G')
        colors   = {'R':'#e53935','A':'#f59e0b','G':'#16a34a'}
        labels   = {'R':'Red if any Red','A':'Amber if any Amber','G':'Green — all aspects Green'}
        self._overall_badge.config(text=overall, bg=colors[overall])

    def _save(self):
        data = {k: v.get().strip() for k, v in self.vars.items()}
        if not data.get('ProjectID') or not data.get('ProjectName') or not data.get('Manager'):
            messagebox.showwarning('Required',
                'Project ID, Project Name and Manager are required.', parent=self)
            return
        data['LastUpdated'] = datetime.date.today().strftime('%Y-%m-%d')

        # Save project
        self.svc.save_project(data)

        # Save RAG (override the default all-G from save_project)
        pid = data['ProjectID']
        for asp, d in self.rag_data.items():
            self.svc.save_rag_entry(pid, asp, d['status'], d.get('exp',''))

        self.saved = True
        self.destroy()
