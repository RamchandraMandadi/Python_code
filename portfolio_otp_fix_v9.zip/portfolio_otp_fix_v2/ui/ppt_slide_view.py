"""
ppt_slide_view.py
-----------------
A standalone Toplevel window that shows the KMG-style "UI slide" preview
(slide-overlay background with editable areas placed at exact slide-inch
coordinates) and lets the user generate a PowerPoint report.

DATA SOURCE  : ONLY pm_final/input/project_data.xlsx
               (Projects, Tasks, RAG, ProjectStatus, WeeklyStatus sheets)

UI BEHAVIOUR : The volume-of-work / "portfolio solution" page from the
               original KMG wizard is intentionally NOT shown. The user only
               sees the slide-overlay UI; the volume-of-work numbers are
               still computed in the background and written into the PPT.

The user picks a Project and a Month from dropdowns. The slide overlays
update instantly. Pressing "📊  Create as PPT" generates the .pptx file
(using assets/template.pptx + the data from pm_final's workbook).
"""
from __future__ import annotations

import datetime
import os
import sys
import tkinter as tk
from pathlib import Path
from tkinter import ttk, filedialog, messagebox
from typing import Optional

try:
    from PIL import Image, ImageTk
    HAVE_PIL = True
except ImportError:
    HAVE_PIL = False

from services.ppt_data_builder import PPTDataBuilder
from services.ppt_generator import generate_status_ppt


# --- Colour palette ---------------------------------------------------------
COLOR_NAVY        = "#1F3864"
COLOR_NAVY_LIGHT  = "#2A4A85"
COLOR_BG          = "#FFFFFF"
SLIDE_BG          = "#D9D9D9"

STATUS_COLOR_MAP = {
    "On track; will complete as planned": "#27AE60",
    "Planned delivery at risk":           "#F1C40F",
    "Will miss planned delivery":         "#C0392B",
    "Originally planned or completed":    "#BFBFBF",
}


# Resolve the assets folder once
def _assets_dir() -> Path:
    """Find pm_final/assets next to the project root."""
    here = Path(__file__).resolve()
    # ui/ppt_slide_view.py → parent.parent = project root
    return here.parent.parent / "assets"


# ============================================================================
class PPTSlideView(tk.Toplevel):
    """Slide-overlay UI + Create-as-PPT button. Modal-style toplevel."""

    # Native slide aspect ratio (10 × 5.625 in)
    SLIDE_RATIO = 5.625 / 10.0

    def __init__(self, parent, initial_project_id: Optional[str] = None):
        super().__init__(parent)
        self.title("Project Status — PPT Slide Preview")
        self.geometry("1240x820")
        self.minsize(1100, 700)
        self.configure(bg=COLOR_BG)

        # Try to inherit parent's icon / position
        try:
            self.transient(parent.winfo_toplevel())
        except Exception:
            pass

        self.assets_dir = _assets_dir()
        self.builder    = PPTDataBuilder()

        # state
        self._bg_img_src   = None
        self._photo        = None
        self._canvas_w     = 0
        self._canvas_h     = 0
        self._off_x        = 0
        self._off_y        = 0
        self._overlay_ids: dict[str, int] = {}
        self._widgets:     dict[str, tk.Widget] = {}
        self._img_refs:    list = []

        self.data = {
            "status_as_of": "",
            "milestones":   [{"text": "", "status": ""} for _ in range(4)],
            "summary": "", "resource_updates": "",
            "recent_accomplishments": "", "upcoming_activities": "",
            "key_risks": "", "mitigation_discussions": "",
            "weeks":     [{"total_amount":"","onshore":"","offshore":"","total_hours":""}
                          for _ in range(4)],
            "total_row": {"total_amount":"","onshore":"","offshore":"","total_hours":""},
            "value_delivered": "",
        }

        self._build_header()
        self._build_canvas_and_overlays()
        self._build_footer()

        # Initial population
        self._populate_project_list(preselect=initial_project_id)

    # ------------------------------------------------------------------ header
    def _build_header(self):
        hdr = tk.Frame(self, bg=COLOR_NAVY, height=56)
        hdr.pack(fill="x")
        hdr.pack_propagate(False)

        tk.Label(hdr, text="📊  Project Status — PPT Slide Preview",
                 font=("Segoe UI", 13, "bold"),
                 bg=COLOR_NAVY, fg="white").pack(side="left", padx=18, pady=14)

        # Right-side selectors
        ctrl = tk.Frame(hdr, bg=COLOR_NAVY)
        ctrl.pack(side="right", padx=14, pady=10)

        # Project is LOCKED to whatever was selected on the main page.
        # We display it as a read-only label, not a combobox, to avoid
        # the impression the user can switch projects from inside the
        # preview window.
        tk.Label(ctrl, text="Project:", font=("Segoe UI", 9),
                 bg=COLOR_NAVY, fg="#cbd5e1").pack(side="left")
        self._proj_var = tk.StringVar()
        self._proj_lbl = tk.Label(
            ctrl, textvariable=self._proj_var,
            font=("Segoe UI", 10, "bold"),
            bg="#0f1f44", fg="white",
            padx=10, pady=4, anchor="w", width=20)
        self._proj_lbl.pack(side="left", padx=(6, 14))

        tk.Label(ctrl, text="Month:", font=("Segoe UI", 9),
                 bg=COLOR_NAVY, fg="#cbd5e1").pack(side="left")
        self._month_var = tk.StringVar()
        self._month_cb  = ttk.Combobox(ctrl, textvariable=self._month_var,
                                       state="readonly", width=18,
                                       font=("Segoe UI", 9))
        self._month_cb.pack(side="left", padx=(6, 14))
        self._month_cb.bind("<<ComboboxSelected>>", self._on_month_change)

        tk.Button(ctrl, text="⟳",
                  font=("Segoe UI", 9, "bold"),
                  bg="#1a2845", fg="white",
                  activebackground="#2a3b6a", activeforeground="white",
                  relief="flat", bd=0, padx=8, pady=4,
                  cursor="hand2", command=self._reload).pack(side="left")

    # ------------------------------------------------------------------ canvas
    def _build_canvas_and_overlays(self):
        """Single-canvas preview, with < > arrow buttons to switch between:

            current_slide = 1  →  Slide 2 of the PPT (Project Status Summary)
                                  uses assets/slide2_ui_bg.jpg as background
            current_slide = 2  →  Slide 3 of the PPT (Volume of Work)
                                  uses assets/slide3_preview.jpg as background

        In both cases the user sees the actual KMG template image; the
        dynamic data values are placed as overlay widgets on top of it.
        """
        # ── State for the 2-slide navigator ────────────────────────────────
        self._current_slide = 1
        self._bg_imgs: dict[int, "Image.Image"] = {}
        for slide_idx, fname in [(1, "slide2_ui_bg.jpg"),
                                 (2, "slide3_preview.jpg")]:
            bg_path = self.assets_dir / fname
            if HAVE_PIL and bg_path.exists():
                try:
                    self._bg_imgs[slide_idx] = Image.open(bg_path)
                except Exception as e:
                    print(f"[PPTSlideView] Cannot load {fname}: {e}")
                    self._bg_imgs[slide_idx] = None
            else:
                self._bg_imgs[slide_idx] = None

        # ── Outer pane: [<-strip] [canvas + indicator] [strip->] ───────────
        pane = tk.Frame(self, bg=COLOR_BG)
        pane.pack(fill="both", expand=True, padx=14, pady=(10, 0))

        # Left side strip: a narrow column that blends with the window
        # background; the arrow button sits centred vertically inside it
        # (no more full-height yellow bar).
        prev_strip = tk.Frame(pane, bg=COLOR_BG, width=40)
        prev_strip.pack(side="left", fill="y", padx=(0, 4))
        prev_strip.pack_propagate(False)
        self._prev_btn = tk.Button(
            prev_strip, text="‹",
            font=("Segoe UI", 16, "bold"),
            bg="#1F3864", fg="white",
            activebackground="#2A4A85", activeforeground="white",
            relief="flat", bd=0, width=2, cursor="hand2",
            command=self._go_prev_slide)
        self._prev_btn.place(relx=0.5, rely=0.5, anchor="center")

        next_strip = tk.Frame(pane, bg=COLOR_BG, width=40)
        next_strip.pack(side="right", fill="y", padx=(4, 0))
        next_strip.pack_propagate(False)
        self._next_btn = tk.Button(
            next_strip, text="›",
            font=("Segoe UI", 16, "bold"),
            bg="#1F3864", fg="white",
            activebackground="#2A4A85", activeforeground="white",
            relief="flat", bd=0, width=2, cursor="hand2",
            command=self._go_next_slide)
        self._next_btn.place(relx=0.5, rely=0.5, anchor="center")

        # Centre: small indicator strip + the canvas
        middle = tk.Frame(pane, bg="#E0E0E0")
        middle.pack(side="left", fill="both", expand=True)

        indicator = tk.Frame(middle, bg=COLOR_BG)
        indicator.pack(fill="x")
        self._slide_label = tk.Label(
            indicator, text="Slide 1 of 2 — Project Status Summary",
            font=("Segoe UI", 9, "italic"),
            bg=COLOR_BG, fg="#444")
        self._slide_label.pack(side="left", padx=6, pady=(0, 4))

        self.canvas = tk.Canvas(middle, bg="white",
                                highlightthickness=2,
                                highlightbackground="#AAAAAA")
        self.canvas.pack(fill="both", expand=True)
        self.canvas.bind("<Configure>", self._on_canvas_resize)

        # ── Build BOTH slides' overlay widgets up-front. They are all children
        # of self.canvas and are shown/hidden by adding/removing canvas window
        # items on slide switch.
        self._build_slide1_widgets()  # Project Status Summary
        self._build_slide2_widgets()  # Volume of Work

        self._update_nav_buttons()

    # ──────────────────────────────────────────────────────────────────────
    # SLIDE 1 (Project Status Summary) — widgets
    # ──────────────────────────────────────────────────────────────────────
    def _build_slide1_widgets(self):
        # ── Project title overlay (covers the hardcoded "Quincy…" text in the bg)
        self._widgets["slide1_title"] = tk.Label(
            self.canvas, text="Project Status Summary",
            bg="#FFFFFF", fg="#1F5496",
            font=("Calibri", 20, "bold"), anchor="w", padx=4)

        # Section header overlays (cover the slide-bg headers cleanly)
        self._widgets["km_header"] = tk.Label(
            self.canvas, text="  KEY MILESTONES",
            bg="#1F3864", fg="white",
            font=("Calibri", 11, "bold"), anchor="w")

        self._widgets["sum_header"] = tk.Label(
            self.canvas, text="  SUMMARY",
            bg="#174B5E", fg="white",
            font=("Calibri", 11, "bold"), anchor="w")

        self._widgets["res_header"] = tk.Label(
            self.canvas, text="  Resource Updates",
            bg="#174B5E", fg="white",
            font=("Calibri", 10, "bold"), anchor="w")

        # 4 status pills inside KEY MILESTONES
        self._milestone_pills = []
        for i in range(4):
            lbl = tk.Label(self.canvas, text=f"W{i+1}",
                           bg="#4A6FA5", fg="white",
                           font=("Calibri", 9, "bold"), anchor="center")
            self._widgets[f"pill_{i}"] = lbl
            self._milestone_pills.append(lbl)

        # 4 milestone text rows
        self._milestone_lbls = []
        for i in range(4):
            lbl = tk.Label(self.canvas, text=f"Week {i+1}:",
                           bg=SLIDE_BG, fg="#111",
                           font=("Calibri", 10), anchor="w",
                           justify="left", padx=6)
            self._widgets[f"ms_{i}"] = lbl
            self._milestone_lbls.append(lbl)

        # Scrollable read-only text panels
        def _scrollbox(accent_color: str):
            outer = tk.Frame(self.canvas, bg=SLIDE_BG, bd=0,
                             highlightthickness=0)
            tk.Frame(outer, bg=accent_color, height=4).pack(side="top", fill="x")
            row = tk.Frame(outer, bg=SLIDE_BG)
            row.pack(fill="both", expand=True)
            vsb = ttk.Scrollbar(row, orient="vertical")
            vsb.pack(side="right", fill="y")
            txt = tk.Text(row, font=("Calibri", 9), wrap="word",
                          bg=SLIDE_BG, fg="#111", relief="flat",
                          state="disabled", padx=8, pady=4,
                          cursor="arrow", yscrollcommand=vsb.set)
            vsb.config(command=txt.yview)
            txt.pack(side="left", fill="both", expand=True)
            return outer, txt

        self._summary_frame,  self._summary_txt  = _scrollbox("#174B5E")
        self._resource_frame, self._resource_txt = _scrollbox("#4A6FA5")
        self._accomp_frame,   self._accomp_txt   = _scrollbox("#27AE60")
        self._upcoming_frame, self._upcoming_txt = _scrollbox("#2980B9")
        self._risks_frame,    self._risks_txt    = _scrollbox("#E67E22")
        self._mit_frame,      self._mit_txt      = _scrollbox("#8E44AD")

        self._widgets["summary"]  = self._summary_frame
        self._widgets["resource"] = self._resource_frame
        self._widgets["accomp"]   = self._accomp_frame
        self._widgets["upcoming"] = self._upcoming_frame
        self._widgets["risks"]    = self._risks_frame
        self._widgets["mit"]      = self._mit_frame

    # ──────────────────────────────────────────────────────────────────────
    # SLIDE 2 (Volume of Work) — widgets overlaid on slide3_preview.jpg
    # ──────────────────────────────────────────────────────────────────────
    # Table cell coordinates (in slide-inches) read from the template:
    #   table L=0.509  T=1.168  W=8.371  H=2.106
    #   col widths = [1.603, 1.684, 1.801, 1.782, 1.501]  (Dur, Amt, On, Off, Hrs)
    #   row heights = [0.351, 0.388, 0.323, 0.397, 0.323, 0.323]
    #     row 0 = header, rows 1-4 = Week 1..4, row 5 = Total
    # Data columns start at column index 1 (Total Amount onwards).
    _S2_TBL_L = 0.509
    _S2_TBL_T = 1.168
    _S2_COL_W = [1.603, 1.684, 1.801, 1.782, 1.501]
    _S2_ROW_H = [0.351, 0.388, 0.323, 0.397, 0.323, 0.323]
    # Value Delivered text-box location on the slide.
    # The template's "* Value Delivered" header sits at L=0.570 T=4.228 H=0.453
    # (so it ends at T=4.681). We start our overlay below that to avoid
    # covering the template's header text.
    _S2_VD_L  = 0.570
    _S2_VD_T  = 4.730
    _S2_VD_W  = 8.249
    _S2_VD_H  = 0.700

    def _s2_cell_xywh(self, row_idx: int, col_idx: int):
        """Return (l_in, t_in, w_in, h_in) for the given table cell."""
        l = self._S2_TBL_L + sum(self._S2_COL_W[:col_idx])
        t = self._S2_TBL_T + sum(self._S2_ROW_H[:row_idx])
        return l, t, self._S2_COL_W[col_idx], self._S2_ROW_H[row_idx]

    def _build_slide2_widgets(self):
        """Build the 5 data labels per week row + total row + value-delivered."""
        # Cell font colour matches the PPT cell colour for that column.
        # All but Ofshore (col 3) are dark, Ofshore is orange — preserve that
        # so the preview looks like the rendered slide.
        CELL_FG_DARK   = "#111111"
        CELL_FG_ORANGE = "#CC6600"
        CELL_BG_LIGHT  = "#F7F7F0"  # neutral light background that matches the
                                    # template's alternating row colour

        self._s2_cells: list[dict[str, tk.Label]] = []
        for r in range(4):  # 4 week rows  (rows 1..4 in the table)
            row_cells: dict[str, tk.Label] = {}
            for col_idx, key in enumerate(
                    ["total_amount", "onshore", "offshore", "total_hours"],
                    start=1):
                fg = CELL_FG_ORANGE if col_idx == 3 else CELL_FG_DARK
                lbl = tk.Label(self.canvas, text="",
                               bg=CELL_BG_LIGHT, fg=fg,
                               font=("Calibri", 11),
                               anchor="center", padx=4,
                               highlightthickness=0, bd=0)
                row_cells[key] = lbl
                self._widgets[f"s2_w{r+1}_{key}"] = lbl
            self._s2_cells.append(row_cells)

        # Total row cells (row 5 in table)
        self._s2_total: dict[str, tk.Label] = {}
        for col_idx, key in enumerate(
                ["total_amount", "onshore", "offshore", "total_hours"],
                start=1):
            fg = CELL_FG_ORANGE if col_idx == 3 else CELL_FG_DARK
            lbl = tk.Label(self.canvas, text="",
                           bg="#EAEAEA", fg=fg,
                           font=("Calibri", 11, "bold"),
                           anchor="center", padx=4,
                           highlightthickness=0, bd=0)
            self._s2_total[key] = lbl
            self._widgets[f"s2_total_{key}"] = lbl

        # Value Delivered text overlay
        vd_outer = tk.Frame(self.canvas, bg=COLOR_BG, bd=0, highlightthickness=0)
        vd_row = tk.Frame(vd_outer, bg=COLOR_BG)
        vd_row.pack(fill="both", expand=True)
        vd_vsb = ttk.Scrollbar(vd_row, orient="vertical")
        vd_vsb.pack(side="right", fill="y")
        self._s2_vd_txt = tk.Text(
            vd_row, font=("Calibri", 10), wrap="word",
            bg=COLOR_BG, fg="#111", relief="flat",
            state="disabled", padx=4, pady=2,
            cursor="arrow", yscrollcommand=vd_vsb.set,
            highlightthickness=0, bd=0)
        vd_vsb.config(command=self._s2_vd_txt.yview)
        self._s2_vd_txt.pack(side="left", fill="both", expand=True)
        self._widgets["s2_vd"] = vd_outer
        self._s2_vd_outer = vd_outer

    # ------------------------------------------------------------------ footer
    def _build_footer(self):
        foot = tk.Frame(self, bg=COLOR_BG, height=58)
        foot.pack(fill="x", side="bottom", padx=14, pady=(8, 10))
        foot.pack_propagate(False)

        self._info_lbl = tk.Label(foot,
                                  text="Pick a project and month.",
                                  font=("Calibri", 10, "italic"),
                                  fg="#666", bg=COLOR_BG)
        self._info_lbl.pack(side="left", pady=8)

        right = tk.Frame(foot, bg=COLOR_BG)
        right.pack(side="right", pady=6)

        tk.Button(right, text="Close",
                  font=("Calibri", 11),
                  bg="#888", fg="white", relief="flat",
                  activebackground="#666", activeforeground="white",
                  padx=18, pady=6, cursor="hand2",
                  command=self.destroy).pack(side="left", padx=(0, 8))

        self._create_btn = tk.Button(right, text="📊  Create as PPT",
                                     font=("Calibri", 12, "bold"),
                                     bg="#27AE60", fg="white", relief="flat",
                                     activebackground="#229954",
                                     activeforeground="white",
                                     padx=22, pady=8, cursor="hand2",
                                     state="disabled",
                                     command=self._create_ppt)
        self._create_btn.pack(side="left")

    # ============================================================== layout
    def _on_canvas_resize(self, event):
        cw, ch = event.width, event.height
        if cw < 10 or ch < 10:
            return
        target_h = int(cw * self.SLIDE_RATIO)
        if target_h > ch:
            target_h = ch
            cw = int(ch / self.SLIDE_RATIO)
        self._canvas_w = cw
        self._canvas_h = target_h

        # Re-draw background for the CURRENT slide
        self.canvas.delete("bg")
        bg_src = self._bg_imgs.get(self._current_slide)
        if HAVE_PIL and bg_src is not None:
            scaled = bg_src.resize((cw, target_h), Image.LANCZOS)
            self._photo = ImageTk.PhotoImage(scaled)
            self._img_refs.append(self._photo)
            off_x = (event.width - cw) // 2
            off_y = (event.height - target_h) // 2
            self.canvas.create_image(off_x, off_y, anchor="nw",
                                     image=self._photo, tags="bg")
            self._off_x, self._off_y = off_x, off_y
        else:
            self._off_x = 0
            self._off_y = 0

        self._place_all_overlays()

    def _place_all_overlays(self):
        """Place ONLY the overlays for the currently active slide.

        Any canvas window items belonging to the inactive slide are
        removed (so their widgets are hidden). Widgets themselves are
        not destroyed — only re-mounted on the canvas as needed.
        """
        ox, oy = self._off_x, self._off_y
        cw, ch = self._canvas_w, self._canvas_h

        def px(inch, axis="x"):
            if axis == "x":
                return ox + int(inch * cw / 10.0)
            return oy + int(inch * ch / 5.625)

        def place(tag, widget, l, t, w, h):
            x, y = px(l), px(t, "y")
            pw = int(w * cw / 10.0)
            ph = int(h * ch / 5.625)
            wrap_px = max(40, pw - 14)
            try:
                widget.config(wraplength=wrap_px)
            except Exception:
                pass
            if tag in self._overlay_ids:
                self.canvas.coords(self._overlay_ids[tag], x, y)
                self.canvas.itemconfig(self._overlay_ids[tag],
                                       width=pw, height=ph)
            else:
                cid = self.canvas.create_window(x, y, window=widget,
                                                anchor="nw",
                                                width=pw, height=ph)
                self._overlay_ids[tag] = cid

        # Determine which slide's overlays should be on the canvas right now
        active_tags = set()
        if self._current_slide == 1:
            active_tags = self._slide1_active_tags()
        else:
            active_tags = self._slide2_active_tags()

        # Remove canvas window items for any overlay NOT in the active set
        for tag in list(self._overlay_ids.keys()):
            if tag not in active_tags:
                cid = self._overlay_ids.pop(tag)
                try:
                    self.canvas.delete(cid)
                except Exception:
                    pass

        if self._current_slide == 1:
            self._place_slide1_overlays(place)
        else:
            self._place_slide2_overlays(place)

    def _slide1_active_tags(self) -> set:
        tags = {"slide1_title", "km_header", "sum_header", "res_header",
                "summary", "resource", "accomp", "upcoming", "risks", "mit"}
        for i in range(4):
            tags.add(f"pill_{i}")
            tags.add(f"ms_{i}")
        return tags

    def _slide2_active_tags(self) -> set:
        tags = {"s2_vd"}
        for r in range(4):
            for key in ("total_amount", "onshore", "offshore", "total_hours"):
                tags.add(f"s2_w{r+1}_{key}")
        for key in ("total_amount", "onshore", "offshore", "total_hours"):
            tags.add(f"s2_total_{key}")
        return tags

    def _place_slide1_overlays(self, place):
        # Project title overlay — covers "Quincy Project Status Summary" in bg
        place("slide1_title", self._widgets["slide1_title"], 0.30, 0.28, 8.80, 0.55)

        # Section headers
        place("km_header",  self._widgets["km_header"],  0.51, 1.14, 5.35, 0.26)
        place("sum_header", self._widgets["sum_header"], 5.94, 1.14, 3.56, 0.26)
        place("res_header", self._widgets["res_header"], 5.94, 2.48, 3.56, 0.22)

        # 4 milestone pills
        for i, lbl in enumerate(self._milestone_pills):
            pl = 0.51 + i * (1.30 + 0.04)
            place(f"pill_{i}", lbl, pl, 1.40, 1.30, 0.21)

        # 4 milestone text rows
        for i, lbl in enumerate(self._milestone_lbls):
            place(f"ms_{i}", lbl, 0.54, 1.67 + i * 0.31, 5.30, 0.29)

        # Scrollable content panels
        place("summary",  self._summary_frame,  5.96, 1.40, 3.48, 1.05)
        place("resource", self._resource_frame, 5.96, 2.70, 3.48, 0.40)
        place("accomp",   self._accomp_frame,   0.54, 3.16, 3.76, 1.06)
        place("upcoming", self._upcoming_frame, 4.38, 3.18, 5.10, 1.00)
        place("risks",    self._risks_frame,    0.54, 4.46, 3.76, 0.64)
        place("mit",      self._mit_frame,      4.38, 4.45, 5.10, 0.64)

    def _place_slide2_overlays(self, place):
        """Lay the 4×4 data labels + total row + Value Delivered overlay on
        top of the slide3_preview.jpg background."""
        # Slight inset to keep label edges off the cell borders
        INSET = 0.015  # ~1.5% of cell, in inches

        # Week rows 1..4 (table rows 1..4)
        for r in range(4):
            for col_idx, key in enumerate(
                    ["total_amount", "onshore", "offshore", "total_hours"],
                    start=1):
                l, t, w, h = self._s2_cell_xywh(r + 1, col_idx)
                place(f"s2_w{r+1}_{key}",
                      self._s2_cells[r][key],
                      l + INSET, t + INSET,
                      w - 2 * INSET, h - 2 * INSET)

        # Total row (table row 5)
        for col_idx, key in enumerate(
                ["total_amount", "onshore", "offshore", "total_hours"],
                start=1):
            l, t, w, h = self._s2_cell_xywh(5, col_idx)
            place(f"s2_total_{key}",
                  self._s2_total[key],
                  l + INSET, t + INSET,
                  w - 2 * INSET, h - 2 * INSET)

        # Value Delivered text overlay
        place("s2_vd", self._s2_vd_outer,
              self._S2_VD_L, self._S2_VD_T,
              self._S2_VD_W, self._S2_VD_H)

    # ============================================================== navigation
    def _go_prev_slide(self):
        if self._current_slide > 1:
            self._current_slide -= 1
            self._switch_slide()

    def _go_next_slide(self):
        if self._current_slide < 2:
            self._current_slide += 1
            self._switch_slide()

    def _switch_slide(self):
        # Update indicator label
        title = ("Slide 1 of 2 — Project Status Summary"
                 if self._current_slide == 1
                 else "Slide 2 of 2 — Summary (volume of work)")
        self._slide_label.config(text=title)
        # Force a redraw at the current canvas size
        cw = self.canvas.winfo_width()
        ch = self.canvas.winfo_height()
        if cw > 1 and ch > 1:
            class _FakeEvt:  # tiny shim so we can call _on_canvas_resize
                pass
            ev = _FakeEvt()
            ev.width  = cw
            ev.height = ch
            self._on_canvas_resize(ev)
        self._update_nav_buttons()

    def _update_nav_buttons(self):
        # Disable boundaries; keep enabled in the middle
        self._prev_btn.config(state=("disabled" if self._current_slide <= 1
                                    else "normal"))
        self._next_btn.config(state=("disabled" if self._current_slide >= 2
                                    else "normal"))

    # ============================================================== data
    def _populate_project_list(self, preselect: Optional[str] = None):
        """Lock the view to the project chosen on the main page.

        We DON'T expose a project picker inside the preview window — the
        project is fixed to `preselect` (the one selected on the main
        Project Status page). The user only picks a Month here.
        """
        projects = self.builder.list_projects()
        self._project_pairs = projects  # [(pid, name), ...]

        if not projects:
            self._proj_var.set("(no projects)")
            self._info_lbl.config(
                text="No projects found in project_data.xlsx.", fg="#C0392B")
            self._month_cb.config(state="disabled")
            self._create_btn.config(state="disabled")
            return

        # Resolve the preselected project ID -> name
        chosen_pid  = None
        chosen_name = None
        if preselect:
            for pid, name in projects:
                if str(pid) == str(preselect):
                    chosen_pid, chosen_name = pid, name
                    break
        # Fallback to the first project if preselect missing/invalid
        if chosen_pid is None:
            chosen_pid, chosen_name = projects[0]

        # Remember it for the rest of the lifecycle
        self._locked_pid = chosen_pid
        self._proj_var.set(chosen_name)

        self._info_lbl.config(
            text=f"Project locked to “{chosen_name}”. Pick a month.",
            fg="#666")
        self._load_months_for_locked_project()

    def _load_months_for_locked_project(self):
        pid = getattr(self, "_locked_pid", None)
        if not pid:
            return
        months = self.builder.list_months(pid)
        self._month_pairs = months  # [(month, label), ...]
        labels = [lbl for _, lbl in months]
        self._month_cb["values"] = labels
        if labels:
            self._month_var.set(labels[0])
            self._month_cb.config(state="readonly")
            self._on_month_change()
        else:
            self._month_var.set("")
            self._month_cb.config(state="disabled")
            self._info_lbl.config(
                text=f"No WeeklyStatus rows for project {pid}.",
                fg="#C0392B")
            self._create_btn.config(state="disabled")

    def _on_month_change(self, _evt=None):
        pid   = self._current_project_id()
        month = self._current_month_key()
        if not (pid and month):
            return
        try:
            self.data = self.builder.build(pid, month)
        except Exception as e:
            messagebox.showerror("Data error",
                                 f"Could not build PPT data:\n{type(e).__name__}: {e}",
                                 parent=self)
            return

        self._refresh_overlays()
        self._info_lbl.config(
            text=f"✔  Loaded: {self.data.get('status_as_of','')} — ready to generate.",
            fg="#27AE60")
        self._create_btn.config(state="normal")

    def _current_project_id(self) -> Optional[str]:
        # Always return the locked project ID — ignore any name typos etc.
        return getattr(self, "_locked_pid", None)

    def _current_month_key(self) -> Optional[str]:
        label = self._month_var.get()
        for m, lbl in getattr(self, "_month_pairs", []):
            if lbl == label:
                return m
        return None

    def _reload(self):
        self.builder.reload()
        current_pid = self._current_project_id()
        self._populate_project_list(preselect=current_pid)

    # ============================================================== overlays
    def _refresh_overlays(self):
        d = self.data
        month_str = d.get("status_as_of", "")

        # Update the title overlay with the real project name
        proj_name = d.get("project_name", "").strip() or self._proj_var.get()
        title_text = f"{proj_name} Project Status Summary" if proj_name else "Project Status Summary"
        self._widgets["slide1_title"].config(text=title_text)

        # Pill labels (try to derive 'Mar' from "March 2025")
        try:
            mo_abbr = datetime.datetime.strptime(month_str, "%B %Y").strftime("%b")
        except Exception:
            mo_abbr = ""
        pill_labels = ([f"{mo_abbr} W{i+1}" for i in range(4)]
                       if mo_abbr else [f"W{i+1}" for i in range(4)])

        # Update pill colors + text
        for i in range(4):
            status = d["milestones"][i]["status"]
            color  = STATUS_COLOR_MAP.get(status, "#4A6FA5")
            self._milestone_pills[i].config(bg=color, text=pill_labels[i])

        # Update milestone text rows
        for i in range(4):
            txt = d["milestones"][i]["text"]
            self._milestone_lbls[i].config(
                text=f"Week {i+1}:  {txt}" if txt else f"Week {i+1}:")

        # Update scrollable panels
        def _fill(widget, content):
            widget.config(state="normal")
            widget.delete("1.0", "end")
            if content:
                widget.insert("1.0", content)
            widget.config(state="disabled")

        _fill(self._summary_txt,  d.get("summary", ""))
        _fill(self._resource_txt, d.get("resource_updates", ""))
        _fill(self._accomp_txt,   d.get("recent_accomplishments", ""))
        _fill(self._upcoming_txt, d.get("upcoming_activities", ""))
        _fill(self._risks_txt,    d.get("key_risks", ""))
        _fill(self._mit_txt,      d.get("mitigation_discussions", ""))

        # Also push values into the Slide-2 (Volume of Work) overlay labels
        self._refresh_slide2_overlays()

    # ============================================================== slide 2 data
    def _refresh_slide2_overlays(self):
        """Push the current self.data into the canvas-overlaid Volume of Work
        cell labels and Value Delivered text."""
        if not hasattr(self, "_s2_cells"):
            return
        weeks = self.data.get("weeks", []) or []
        for i in range(4):
            wk = weeks[i] if i < len(weeks) else {}
            for key in ("total_amount", "onshore", "offshore", "total_hours"):
                self._s2_cells[i][key].config(
                    text=str(wk.get(key, "") or ""))

        total = self.data.get("total_row", {}) or {}
        for key in ("total_amount", "onshore", "offshore", "total_hours"):
            self._s2_total[key].config(text=str(total.get(key, "") or ""))

        # Value delivered text
        self._s2_vd_txt.config(state="normal")
        self._s2_vd_txt.delete("1.0", "end")
        vd = self.data.get("value_delivered", "") or ""
        if vd:
            self._s2_vd_txt.insert("1.0", vd)
        self._s2_vd_txt.config(state="disabled")
    # ============================================================== generate
    def _create_ppt(self):
        if not self.data:
            return

        proj_name = self._proj_var.get() or "Project"
        safe_proj = "".join(c if c.isalnum() else "_" for c in proj_name)
        default_name = (f"{safe_proj}_Status_"
                        f"{datetime.date.today().strftime('%Y%m%d')}.pptx")

        path = filedialog.asksaveasfilename(
            parent=self,
            title="Save Generated PPT",
            defaultextension=".pptx",
            initialfile=default_name,
            filetypes=[("PowerPoint files", "*.pptx"), ("All files", "*.*")],
        )
        if not path:
            return

        template_path = self.assets_dir / "template.pptx"
        if not template_path.exists():
            messagebox.showerror("Template Missing",
                                 f"Template PPT not found at:\n{template_path}",
                                 parent=self)
            return

        try:
            generate_status_ppt(str(template_path), path, self.data)
        except Exception as e:
            messagebox.showerror("Error Generating PPT",
                                 f"Something went wrong:\n\n"
                                 f"{type(e).__name__}: {e}",
                                 parent=self)
            return

        self._info_lbl.config(
            text=f"✔ PPT generated: {os.path.basename(path)}",
            fg="#27AE60")

        if messagebox.askyesno("Done",
                               f"PPT generated successfully!\n\n{path}\n\n"
                               f"Open the folder now?",
                               parent=self):
            self._open_folder(os.path.dirname(path))

    @staticmethod
    def _open_folder(path: str):
        import subprocess
        try:
            if sys.platform.startswith("win"):
                os.startfile(path)
            elif sys.platform == "darwin":
                subprocess.Popen(["open", path])
            else:
                subprocess.Popen(["xdg-open", path])
        except Exception:
            pass
