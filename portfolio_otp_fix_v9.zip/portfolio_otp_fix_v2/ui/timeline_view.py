import tkinter as tk
from tkinter import ttk, font as tkfont
from datetime import datetime, timedelta


# ─────────────────────────────────────────────────────────────────────────────
# PALETTE  (modern dark-slate professional theme)
# ─────────────────────────────────────────────────────────────────────────────
CLR = {
    "bg":           "#0F1117",   # near-black canvas
    "panel_bg":     "#161B27",   # left-panel background
    "header_bg":    "#1C2333",   # header strip
    "row_even":     "#131722",
    "row_odd":      "#0F1117",
    "row_hover":    "#1E263A",
    "row_selected": "#1A2E4A",
    "grid_line":    "#1E2535",
    "weekend_bg":   "#13181F",
    "text_primary": "#FFFFFF",
    "text_muted":   "#FFFFFF",
    "text_header":  "#FFFFFF",
    "today_line":   "#F97316",   # vivid orange
    "today_label":  "#F97316",
    "border":       "#252D3D",
    # bar colours
    "bar_green":    "#22C55E",
    "bar_amber":    "#F59E0B",
    "bar_red":      "#EF4444",
    "bar_blue":     "#3B82F6",
    "bar_gray":     "#475569",
    "bar_default":  "#6366F1",
    # bar glow (shadow colour, slightly transparent)
    "glow_green":   "#15803D",
    "glow_amber":   "#B45309",
    "glow_blue":    "#1D4ED8",
    # progress track
    "progress_bg":  "#1E2535",
    "progress_fg":  "#3B82F6",
    # milestone diamond
    "milestone":    "#A78BFA",
    # connector line
    "connector":    "#2D3748",
    # drag highlight
    "drag_border":  "#F59E0B",
    # scrollbar
    "sb_trough":    "#161B27",
    "sb_thumb":     "#2D3A55",
}

ROW_H      = 36          # px per task row
HEADER_H   = 60          # date header height
DAY_W      = 24          # px per day  (zoom level)
LEFT_W     = 260         # left panel width
BAR_PAD_Y  = 9           # vertical inset of bar inside row
BAR_R      = 4           # bar corner "radius" (simulated)
FONT_TASK  = ("Consolas", 9)
FONT_PROJ  = ("Consolas", 9, "bold")
FONT_HDR   = ("Consolas", 8)
FONT_DATE  = ("Consolas", 8, "bold")
FONT_TODAY = ("Consolas", 7, "bold")


def hex_to_rgb(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i+2], 16) for i in (0, 2, 4))


def blend(c1, c2, t):
    r1, g1, b1 = hex_to_rgb(c1)
    r2, g2, b2 = hex_to_rgb(c2)
    r = int(r1 + (r2 - r1) * t)
    g = int(g1 + (g2 - g1) * t)
    b = int(b1 + (b2 - b1) * t)
    return f"#{r:02x}{g:02x}{b:02x}"


# ─────────────────────────────────────────────────────────────────────────────
class TimelineView(tk.Frame):
    """
    Professional Gantt timeline with:
      • Dark-slate theme, colour-coded bars, progress track
      • Month / day two-row header, weekend shading, today line
      • Hierarchical task indentation (project → task → subtask)
      • Drag-and-drop bars → updates DataService + refreshes table
      • Zoom in / out (mouse-wheel on header)
      • Hover tooltip, selected-row highlight
    """

    def __init__(self, parent, data_service, sheet_name="Tasks"):
        super().__init__(parent, bg=CLR["bg"])

        self.data_service = data_service
        self.sheet_name   = sheet_name

        # state
        self.tasks          = []
        self.project_start  = None
        self.project_end    = None
        self.hovered_row    = None
        self.selected_row   = None
        self.collapsed_projects = set()  # project names that are collapsed
        self.collapsed_tasks    = set()   # task IDs that are collapsed
        self.drag_task       = None     # task dict being dragged
        self.drag_mode       = None     # "move" | "resize_end" | "resize_start"
        self.drag_offset_x   = 0       # px offset from bar left edge
        self.drag_orig_start = None
        self.drag_orig_end   = None
        self.HANDLE_W        = 10      # px width of resize handles
        self.tooltip_win    = None
        self.day_w          = DAY_W    # current zoom level

        self._build_layout()
        self.load_data()

    # ─────────────────────────── LAYOUT ──────────────────────────────────────
    def _build_layout(self):

        # ── top toolbar ──────────────────────────────────────────────────────
        toolbar = tk.Frame(self, bg=CLR["header_bg"], height=38)
        toolbar.pack(fill="x", side="top")
        toolbar.pack_propagate(False)

        self._make_btn(toolbar, "⟵", self._scroll_left).pack(side="left",  padx=(8, 2), pady=6)
        self._make_btn(toolbar, "⟶", self._scroll_right).pack(side="left", padx=2,      pady=6)
        tk.Frame(toolbar, bg=CLR["border"], width=1).pack(side="left", fill="y", padx=8, pady=8)
        self._make_btn(toolbar, "＋ Zoom", self._zoom_in).pack(side="left",  padx=2, pady=6)
        self._make_btn(toolbar, "－ Zoom", self._zoom_out).pack(side="left", padx=2, pady=6)
        tk.Frame(toolbar, bg=CLR["border"], width=1).pack(side="left", fill="y", padx=8, pady=8)
        self._make_btn(toolbar, "↺ Today", self._scroll_to_today).pack(side="left", padx=2, pady=6)

        # legend
        leg = tk.Frame(toolbar, bg=CLR["header_bg"])
        leg.pack(side="right", padx=12)
        for label, colour in [
            ("On Track", CLR["bar_green"]),
            ("At Risk",  CLR["bar_amber"]),
            ("Delayed",  CLR["bar_red"]),
            ("Active",   CLR["bar_blue"]),
        ]:
            dot = tk.Canvas(leg, width=10, height=10, bg=CLR["header_bg"],
                            highlightthickness=0)
            dot.create_oval(1, 1, 9, 9, fill=colour, outline="")
            dot.pack(side="left", padx=(6, 2))
            tk.Label(leg, text=label, fg=CLR["text_muted"], bg=CLR["header_bg"],
                     font=("Consolas", 8)).pack(side="left", padx=(0, 6))

        # ── canvas + scrollbars ───────────────────────────────────────────────
        container = tk.Frame(self, bg=CLR["bg"])
        container.pack(fill="both", expand=True)

        self.canvas = tk.Canvas(container, bg=CLR["bg"],
                                highlightthickness=0, cursor="arrow")
        self.canvas.pack(side="left", fill="both", expand=True)

        vsb = tk.Scrollbar(container, orient="vertical",
                           command=self.canvas.yview,
                           bg=CLR["sb_trough"], troughcolor=CLR["sb_trough"],
                           activebackground=CLR["sb_thumb"])
        vsb.pack(side="right", fill="y")
        self.canvas.configure(yscrollcommand=vsb.set)

        hsb_frame = tk.Frame(self, bg=CLR["bg"])
        hsb_frame.pack(fill="x", side="bottom")
        hsb = tk.Scrollbar(hsb_frame, orient="horizontal",
                           command=self.canvas.xview,
                           bg=CLR["sb_trough"], troughcolor=CLR["sb_trough"],
                           activebackground=CLR["sb_thumb"])
        hsb.pack(fill="x")
        self.canvas.configure(xscrollcommand=hsb.set)

        # bindings
        self.canvas.bind("<MouseWheel>",       self._on_vscroll)
        self.canvas.bind("<Shift-MouseWheel>", self._on_hscroll)
        self.canvas.bind("<Button-4>",         self._on_vscroll)
        self.canvas.bind("<Button-5>",         self._on_vscroll)
        self.canvas.bind("<Motion>",           self._on_motion)
        self.canvas.bind("<Leave>",            self._on_leave)
        self.canvas.bind("<Button-1>",         self._on_click)
        self.canvas.bind("<B1-Motion>",        self._on_drag_motion)
        self.canvas.bind("<ButtonRelease-1>",  self._on_drop)

    def _make_btn(self, parent, text, cmd):
        btn = tk.Label(
            parent, text=text,
            fg=CLR["text_primary"], bg=CLR["header_bg"],
            font=("Consolas", 9), cursor="hand2",
            padx=10, pady=2,
            relief="flat"
        )
        btn.bind("<Button-1>", lambda e: cmd())
        btn.bind("<Enter>",    lambda e: btn.configure(fg=CLR["bar_blue"]))
        btn.bind("<Leave>",    lambda e: btn.configure(fg=CLR["text_primary"]))
        return btn

    # ─────────────────────────── DATA ────────────────────────────────────────
    def load_data(self):
        try:
            self.tasks = self.data_service.get_hierarchy_ordered_tasks()
        except Exception as e:
            print("TimelineView: error loading tasks:", e)
            self.tasks = []

        valid = []
        for t in self.tasks:
            if t.get("is_project"):
                valid.append(t)
                continue
            try:
                t["_start"] = datetime.strptime(str(t["StartDate"])[:10], "%Y-%m-%d")
                t["_end"]   = datetime.strptime(str(t["EndDate"])[:10],   "%Y-%m-%d")
                valid.append(t)
            except Exception:
                t["_start"] = None
                t["_end"]   = None
                valid.append(t)

        # stamp original index for hover/select hit-testing
        for i, t in enumerate(valid):
            t["_orig_idx"] = i

        self.tasks = valid

        all_dates = [t["_start"] for t in self.tasks if t.get("_start")] + \
                    [t["_end"]   for t in self.tasks if t.get("_end")]

        if all_dates:
            self.project_start = min(all_dates) - timedelta(days=3)
            self.project_end   = max(all_dates) + timedelta(days=5)
        else:
            today = datetime.today()
            self.project_start = today - timedelta(days=14)
            self.project_end   = today + timedelta(days=14)

        self.draw()

    def refresh(self):
        self.load_data()

    # ─────────────────────────── DRAWING ─────────────────────────────────────
    def _day_to_x(self, d):
        return LEFT_W + (d - self.project_start).days * self.day_w

    def _x_to_day(self, x):
        days = (x - LEFT_W) / self.day_w
        return self.project_start + timedelta(days=round(days))

    def draw(self):
        self.canvas.delete("all")
        if not self.project_start:
            return
        self._draw_background()
        self._draw_header()
        self._draw_rows()
        self._draw_today_line()
        self._update_scroll()

    def _total_days(self):
        return (self.project_end - self.project_start).days + 1

    def _canvas_width(self):
        return LEFT_W + self._total_days() * self.day_w

    def _canvas_height(self):
        visible = self._get_visible_tasks()
        return HEADER_H + len(visible) * ROW_H + 40

    def _toggle_project(self, proj_name):
        if proj_name in self.collapsed_projects:
            self.collapsed_projects.discard(proj_name)
        else:
            self.collapsed_projects.add(proj_name)
        self.draw()

    def _toggle_task(self, task_id):
        if task_id in self.collapsed_tasks:
            self.collapsed_tasks.discard(task_id)
        else:
            self.collapsed_tasks.add(task_id)
        self.draw()

    # ── background ───────────────────────────────────────────────────────────
    def _draw_background(self):
        W = self._canvas_width()
        H = self._canvas_height()
        self.canvas.create_rectangle(0, 0, W, H, fill=CLR["bg"], outline="")

    # ── header ───────────────────────────────────────────────────────────────
    def _draw_header(self):
        W = self._canvas_width()

        # header fill
        self.canvas.create_rectangle(
            0, 0, W, HEADER_H,
            fill=CLR["header_bg"], outline=""
        )
        # bottom border
        self.canvas.create_line(
            0, HEADER_H, W, HEADER_H,
            fill=CLR["border"], width=1
        )
        # left panel header
        self.canvas.create_rectangle(
            0, 0, LEFT_W, HEADER_H,
            fill=CLR["panel_bg"], outline=""
        )
        self.canvas.create_line(
            LEFT_W, 0, LEFT_W, HEADER_H,
            fill=CLR["border"], width=1
        )
        self.canvas.create_text(
            20, HEADER_H // 2,
            text="TASK / PROJECT",
            anchor="w",
            fill=CLR["text_header"],
            font=FONT_DATE
        )

        # month labels (top row)
        cur = self.project_start.replace(day=1)
        while cur <= self.project_end:
            x1 = self._day_to_x(cur)
            # find end of month
            if cur.month == 12:
                next_m = cur.replace(year=cur.year + 1, month=1)
            else:
                next_m = cur.replace(month=cur.month + 1)
            x2 = self._day_to_x(min(next_m, self.project_end + timedelta(days=1)))
            mx = (x1 + x2) / 2

            self.canvas.create_text(
                mx, 15,
                text=cur.strftime("%B %Y").upper(),
                fill=CLR["text_header"],
                font=FONT_DATE,
                anchor="center"
            )
            cur = next_m if next_m <= self.project_end else next_m

        # day labels (bottom row)
        total = self._total_days()
        for i in range(total):
            d = self.project_start + timedelta(days=i)
            x = self._day_to_x(d)

            # weekend shading extends below header
            if d.weekday() >= 5:
                self.canvas.create_rectangle(
                    x, HEADER_H,
                    x + self.day_w, self._canvas_height(),
                    fill=CLR["weekend_bg"], outline=""
                )

            # vertical grid line
            self.canvas.create_line(
                x, 30, x, HEADER_H,
                fill=CLR["grid_line"], width=1
            )

            # show day number only if wide enough
            if self.day_w >= 14:
                colour = CLR["bar_amber"] if d.weekday() >= 5 else CLR["text_muted"]
                self.canvas.create_text(
                    x + self.day_w / 2, HEADER_H - 12,
                    text=str(d.day),
                    fill=colour,
                    font=FONT_HDR,
                    anchor="center"
                )

    # ── rows ─────────────────────────────────────────────────────────────────
    def _get_visible_tasks(self):
        """Return tasks list filtered by collapse state, with visual_idx assigned."""
        # build a set of all task IDs that have children
        all_parent_ids = set()
        for task in self.tasks:
            pid = task.get("ParentTaskID")
            if pid is not None:
                try:
                    all_parent_ids.add(int(float(pid)))
                except Exception:
                    pass

        visible = []
        proj_collapsed  = False
        # stack of collapsed ancestor task IDs
        collapsed_ancestors = []

        for task in self.tasks:
            if task.get("is_project"):
                proj_name      = task.get("TaskName", "")
                proj_collapsed = proj_name in self.collapsed_projects
                collapsed_ancestors = []
                task["_collapsed"] = False
                task["_has_children"] = False
                visible.append(task)
                continue

            if proj_collapsed:
                continue

            task_id  = None
            try:
                task_id = int(float(task.get("TaskID")))
            except Exception:
                pass

            parent_id = None
            try:
                raw = task.get("ParentTaskID")
                if raw is not None and str(raw).strip().lower() not in ("", "nan", "none"):
                    parent_id = int(float(raw))
            except Exception:
                pass

            # prune collapsed_ancestors to only those that are actual ancestors
            # of this task (by checking level)
            task_level = task.get("level", 1)
            collapsed_ancestors = [a for a in collapsed_ancestors
                                   if a["level"] < task_level]

            if collapsed_ancestors:
                continue

            task["_has_children"] = task_id in all_parent_ids
            task["_collapsed"]    = False

            if task_id in self.collapsed_tasks and task["_has_children"]:
                task["_collapsed"] = True
                collapsed_ancestors.append(task)

            visible.append(task)

        return visible

    def _draw_rows(self):
        visible = self._get_visible_tasks()
        for vis_idx, task in enumerate(visible):
            task["_vis_idx"] = vis_idx          # store for hit-testing
            y_top = HEADER_H + vis_idx * ROW_H

            # row background
            if task.get("_orig_idx") == self.selected_row:
                bg = CLR["row_selected"]
            elif task.get("_orig_idx") == self.hovered_row:
                bg = CLR["row_hover"]
            else:
                bg = CLR["row_even"] if vis_idx % 2 == 0 else CLR["row_odd"]

            self.canvas.create_rectangle(
                0, y_top, self._canvas_width(), y_top + ROW_H,
                fill=bg, outline=""
            )
            self.canvas.create_line(
                0, y_top + ROW_H - 1,
                self._canvas_width(), y_top + ROW_H - 1,
                fill=CLR["grid_line"], width=1
            )
            self.canvas.create_line(
                LEFT_W, y_top, LEFT_W, y_top + ROW_H,
                fill=CLR["border"], width=1
            )

            # vertical grid lines
            for i in range(self._total_days()):
                d = self.project_start + timedelta(days=i)
                x = self._day_to_x(d)
                self.canvas.create_line(
                    x, y_top, x, y_top + ROW_H,
                    fill=CLR["grid_line"], width=1
                )

            self._draw_task_label(task, vis_idx, y_top)

            if not task.get("is_project") and task.get("_start") and task.get("_end"):
                self._draw_bar(task, vis_idx, y_top)

    def _draw_task_label(self, task, idx, y_top):
        level  = task.get("level", 0)
        indent = 16 + level * 18

        is_proj      = task.get("is_project", False)
        proj_name    = task.get("TaskName", "")
        is_collapsed = (is_proj and proj_name in self.collapsed_projects) or \
                       (not is_proj and task.get("_collapsed", False))
        has_children = is_proj or task.get("_has_children", False)

        # arrow for expandable rows, dot for leaf tasks
        arrow        = "▶" if is_collapsed else ("▼" if has_children else "·")
        arrow_colour = CLR["text_header"] if is_proj else (
                       CLR["text_muted"]  if has_children else CLR["grid_line"])

        arrow_tag = f"toggle_{idx}"
        self.canvas.create_text(
            indent - 2, y_top + ROW_H / 2,
            text=arrow,
            fill=arrow_colour,
            font=("Consolas", 8, "bold") if has_children else ("Consolas", 7),
            anchor="center",
            tags=(arrow_tag,)
        )
        if is_proj:
            self.canvas.tag_bind(arrow_tag, "<Button-1>",
                lambda e, pn=proj_name: self._toggle_project(pn))
        elif has_children:
            task_id = None
            try:
                task_id = int(float(task.get("TaskID")))
            except Exception:
                pass
            if task_id is not None:
                self.canvas.tag_bind(arrow_tag, "<Button-1>",
                    lambda e, tid=task_id: self._toggle_task(tid))

        name  = str(task.get("TaskName", ""))
        color = CLR["text_primary"] if not is_proj else "#FFFFFF"
        fnt   = FONT_PROJ if is_proj else FONT_TASK

        # truncate
        max_chars = max(10, (LEFT_W - indent - 10) // 7)
        if len(name) > max_chars:
            name = name[:max_chars - 1] + "…"

        self.canvas.create_text(
            indent + 6, y_top + ROW_H / 2,
            text=name, anchor="w",
            fill=color, font=fnt
        )

        # progress badge (right side of label panel)
        prog = task.get("Progress")
        if prog is not None and not is_proj:
            try:
                pct = int(float(prog))
                badge_x = LEFT_W - 36
                badge_y = y_top + ROW_H / 2
                # small pill
                self.canvas.create_rectangle(
                    badge_x, badge_y - 7,
                    badge_x + 32, badge_y + 7,
                    fill=CLR["progress_bg"], outline=CLR["border"],
                    width=1
                )
                fill_w = int(32 * pct / 100)
                if fill_w > 0:
                    bar_col = CLR["bar_green"] if pct >= 80 else \
                              CLR["bar_amber"] if pct >= 40 else CLR["bar_red"]
                    self.canvas.create_rectangle(
                        badge_x, badge_y - 7,
                        badge_x + fill_w, badge_y + 7,
                        fill=bar_col, outline=""
                    )
                self.canvas.create_text(
                    badge_x + 16, badge_y,
                    text=f"{pct}%",
                    fill=CLR["text_primary"],
                    font=("Consolas", 7, "bold"),
                    anchor="center"
                )
            except Exception:
                pass

    def _draw_bar(self, task, idx, y_top):
        x1 = self._day_to_x(task["_start"])
        x2 = self._day_to_x(task["_end"]) + self.day_w

        y1 = y_top + BAR_PAD_Y
        y2 = y_top + ROW_H - BAR_PAD_Y

        colour = self._smart_colour(task)

        # shadow / glow
        self.canvas.create_rectangle(
            x1 + 1, y1 + 2, x2 + 1, y2 + 2,
            fill=blend(colour, "#000000", 0.6),
            outline=""
        )

        # bar body
        self.canvas.create_rectangle(
            x1, y1, x2, y2,
            fill=colour, outline=""
        )

        # progress overlay
        try:
            pct = float(task.get("Progress", 0)) / 100.0
            pw  = int((x2 - x1) * pct)
            if pw > 0:
                self.canvas.create_rectangle(
                    x1, y1, x1 + pw, y2,
                    fill=blend(colour, "#ffffff", 0.25),
                    outline=""
                )
        except Exception:
            pass

        # left edge accent
        self.canvas.create_rectangle(
            x1, y1, x1 + 3, y2,
            fill=blend(colour, "#ffffff", 0.4),
            outline=""
        )

        # task name on bar (if wide enough)
        bar_w = x2 - x1
        if bar_w > 40:
            short = str(task.get("TaskName", ""))
            max_c = max(3, (bar_w - 10) // 6)
            if len(short) > max_c:
                short = short[:max_c - 1] + "…"
            self.canvas.create_text(
                x1 + 7, (y1 + y2) / 2,
                text=short,
                anchor="w",
                fill="#ffffff",
                font=("Consolas", 8, "bold")
            )

        # drag handle (right edge)
        self.canvas.create_rectangle(
            x2 - 5, y1 + 2, x2, y2 - 2,
            fill=blend(colour, "#ffffff", 0.5),
            outline=""
        )

        # tag for hit testing
        tag = f"bar_{idx}"
        self.canvas.create_rectangle(
            x1, y1, x2, y2,
            fill="", outline="", tags=(tag, "bar")
        )

    def _smart_colour(self, task):
        """
        Colour priority:
          1. Completed (any wording) → green always
          2. Overdue (EndDate < today, not completed) → red
          3. Due within 3 days (not completed) → amber
          4. In Progress → blue
          5. Not Started → gray
          6. Fallback → default purple
        """
        today  = datetime.today().replace(hour=0, minute=0, second=0, microsecond=0)
        status = str(task.get("Status", "")).lower().strip()
        end    = task.get("_end")

        # 1. Completed
        if "complet" in status or "done" in status or "closed" in status:
            return CLR["bar_green"]

        # 2. Overdue — deadline passed and not completed
        if end and end < today:
            return CLR["bar_red"]

        # 3. Due within 3 days — at risk
        if end and (end - today).days <= 3:
            return CLR["bar_amber"]

        # 4. Active / In Progress
        if "progress" in status or "active" in status or "in progress" in status:
            return CLR["bar_blue"]

        # 5. Not started / pending
        if "not start" in status or "pending" in status or status == "":
            return CLR["bar_gray"]

        # 6. Explicit colour words as fallback
        if "green"  in status: return CLR["bar_green"]
        if "amber"  in status: return CLR["bar_amber"]
        if "red"    in status: return CLR["bar_red"]

        return CLR["bar_default"]

    def _status_colour(self, status):
        # Legacy — kept for safety, use _smart_colour(task) where possible
        s = status.lower() if status else ""
        if "complet" in s or "done" in s:         return CLR["bar_green"]
        if "green"    in s or "on track"  in s:   return CLR["bar_green"]
        if "amber"    in s or "at risk"   in s:   return CLR["bar_amber"]
        if "red"      in s or "delay"     in s:   return CLR["bar_red"]
        if "progress" in s or "active"    in s:   return CLR["bar_blue"]
        if "not start" in s or "pending"  in s:   return CLR["bar_gray"]
        return CLR["bar_default"]

    # ── today line ───────────────────────────────────────────────────────────
    def _draw_today_line(self):
        today = datetime.today().replace(hour=0, minute=0, second=0, microsecond=0)
        if not (self.project_start <= today <= self.project_end + timedelta(days=1)):
            return
        x = self._day_to_x(today)
        H = self._canvas_height()

        # glow
        for offset, alpha in [(2, 0.15), (1, 0.3)]:
            col = blend(CLR["today_line"], CLR["bg"], 1 - alpha)
            self.canvas.create_line(
                x - offset, HEADER_H, x - offset, H,
                fill=col, width=1
            )
            self.canvas.create_line(
                x + offset, HEADER_H, x + offset, H,
                fill=col, width=1
            )

        self.canvas.create_line(
            x, HEADER_H, x, H,
            fill=CLR["today_line"], width=2, dash=(4, 3)
        )

        # "TODAY" label on header
        self.canvas.create_rectangle(
            x - 18, HEADER_H - 16,
            x + 18, HEADER_H - 2,
            fill=CLR["today_line"], outline=""
        )
        self.canvas.create_text(
            x, HEADER_H - 9,
            text="TODAY",
            fill="#ffffff",
            font=FONT_TODAY,
            anchor="center"
        )

    # ─────────────────────────── SCROLL / ZOOM ───────────────────────────────
    def _update_scroll(self):
        W = self._canvas_width()
        H = self._canvas_height()
        self.canvas.configure(scrollregion=(0, 0, W, H))

    def _on_vscroll(self, event):
        delta = -1 if (getattr(event, "delta", 0) > 0 or getattr(event, "num", 0) == 4) else 1
        self.canvas.yview_scroll(delta, "units")

    def _on_hscroll(self, event):
        delta = -1 if event.delta > 0 else 1
        self.canvas.xview_scroll(delta, "units")

    def _scroll_left(self):
        self.canvas.xview_scroll(-3, "units")

    def _scroll_right(self):
        self.canvas.xview_scroll(3, "units")

    def _zoom_in(self):
        self.day_w = min(self.day_w + 4, 60)
        self.draw()

    def _zoom_out(self):
        self.day_w = max(self.day_w - 4, 8)
        self.draw()

    def _scroll_to_today(self):
        today = datetime.today()
        if not self.project_start:
            return
        days_in  = (today - self.project_start).days
        total    = self._total_days()
        fraction = max(0.0, min(1.0, (days_in - 5) / max(total, 1)))
        self.canvas.xview_moveto(fraction)

    # ─────────────────────────── INTERACTION ─────────────────────────────────
    def _row_at(self, y_canvas):
        """Returns the index into self.tasks (not visible list) at canvas y."""
        y = y_canvas - HEADER_H
        if y < 0:
            return None
        vis_idx = int(y // ROW_H)
        visible = self._get_visible_tasks()
        if 0 <= vis_idx < len(visible):
            return visible[vis_idx].get("_orig_idx", vis_idx)
        return None

    def _vis_row_at(self, y_canvas):
        """Returns index into visible task list."""
        y = y_canvas - HEADER_H
        if y < 0:
            return None
        vis_idx = int(y // ROW_H)
        visible = self._get_visible_tasks()
        if 0 <= vis_idx < len(visible):
            return vis_idx
        return None

    def _on_motion(self, event):
        cx, cy = self._canvas_coords(event)

        if self.drag_task is not None:
            self._do_drag(cx)
            return

        vis_idx = self._vis_row_at(cy)
        orig_idx = None

        if vis_idx is not None:
            visible  = self._get_visible_tasks()
            task     = visible[vis_idx]
            orig_idx = task.get("_orig_idx", vis_idx)

            # cursor hint based on bar zone
            if not task.get("is_project") and task.get("_start") and task.get("_end"):
                x1    = self._day_to_x(task["_start"])
                x2    = self._day_to_x(task["_end"]) + self.day_w
                y_top = HEADER_H + vis_idx * ROW_H
                if y_top + BAR_PAD_Y <= cy <= y_top + ROW_H - BAR_PAD_Y:
                    if cx <= x1 + self.HANDLE_W or cx >= x2 - self.HANDLE_W:
                        self.canvas.configure(cursor="sb_h_double_arrow")
                    else:
                        self.canvas.configure(cursor="fleur")
                else:
                    self.canvas.configure(cursor="arrow")
            else:
                self.canvas.configure(cursor="arrow")
        else:
            self.canvas.configure(cursor="arrow")

        if orig_idx != self.hovered_row:
            self.hovered_row = orig_idx
            self.draw()
            if vis_idx is not None:
                visible = self._get_visible_tasks()
                self._show_tooltip(event, visible[vis_idx])
            else:
                self._hide_tooltip()

    def _on_leave(self, event):
        self.hovered_row = None
        self._hide_tooltip()
        self.draw()

    def _on_click(self, event):
        cx, cy = self._canvas_coords(event)

        vis_idx = self._vis_row_at(cy)
        if vis_idx is None:
            self.draw()
            return

        visible = self._get_visible_tasks()
        task    = visible[vis_idx]
        orig_idx = task.get("_orig_idx", vis_idx)
        self.selected_row = orig_idx

        if not task.get("is_project") and task.get("_start") and task.get("_end"):
            x1    = self._day_to_x(task["_start"])
            x2    = self._day_to_x(task["_end"]) + self.day_w
            y_top = HEADER_H + vis_idx * ROW_H
            y1    = y_top + BAR_PAD_Y
            y2    = y_top + ROW_H - BAR_PAD_Y

            if x1 <= cx <= x2 and y1 <= cy <= y2:
                self.drag_task       = task
                self.drag_row        = vis_idx
                self.drag_orig_start = task["_start"]
                self.drag_orig_end   = task["_end"]

                if cx <= x1 + self.HANDLE_W:
                    self.drag_mode     = "resize_start"
                    self.drag_offset_x = 0
                    self.canvas.configure(cursor="sb_h_double_arrow")
                elif cx >= x2 - self.HANDLE_W:
                    self.drag_mode     = "resize_end"
                    self.drag_offset_x = 0
                    self.canvas.configure(cursor="sb_h_double_arrow")
                else:
                    self.drag_mode     = "move"
                    self.drag_offset_x = cx - x1
                    self.canvas.configure(cursor="fleur")
                return

        self.draw()

    def _do_drag(self, cx):
        if self.drag_task is None or self.drag_mode is None:
            return

        task = self.drag_task

        def x_to_date(x):
            days = self._x_to_day_float(x)
            return self.project_start + timedelta(days=max(0, round(days)))

        if self.drag_mode == "move":
            # shift both dates, keep duration fixed
            duration    = (task["_end"] - task["_start"]).days
            new_start   = x_to_date(cx - self.drag_offset_x)
            new_end     = new_start + timedelta(days=duration)
            task["_start"] = new_start
            task["_end"]   = new_end

        elif self.drag_mode == "resize_end":
            # only move end date; start stays fixed
            new_end = x_to_date(cx)
            if new_end > task["_start"]:          # must stay after start
                task["_end"] = new_end

        elif self.drag_mode == "resize_start":
            # only move start date; end stays fixed
            new_start = x_to_date(cx)
            if new_start < task["_end"]:          # must stay before end
                task["_start"] = new_start

        self.draw()

        # amber outline shows the new bounds while dragging
        self.canvas.create_rectangle(
            self._day_to_x(task["_start"]),
            HEADER_H + self.drag_row * ROW_H + BAR_PAD_Y - 2,
            self._day_to_x(task["_end"]) + self.day_w,
            HEADER_H + self.drag_row * ROW_H + ROW_H - BAR_PAD_Y + 2,
            outline=CLR["drag_border"], fill="", width=2
        )

    def _x_to_day_float(self, x):
        return (x - LEFT_W) / self.day_w

    def _on_drag_motion(self, event):
        cx, cy = self._canvas_coords(event)
        self._do_drag(cx)

    def _on_drop(self, event):
        if self.drag_task is None:
            return

        task      = self.drag_task
        new_start = task["_start"]
        new_end   = task["_end"]

        self._save_task_dates(task, new_start, new_end)

        self.drag_task  = None
        self.drag_mode  = None
        self.canvas.configure(cursor="arrow")
        self.draw()

    def _save_task_dates(self, task, new_start, new_end):
        """
        Saves dragged dates back to Excel using repo.update_row_by_id —
        the same method the rest of the app uses for task edits.
        Then fires on_data_changed so the table refreshes.
        """
        try:
            task_id = task.get("TaskID")

            updated_data = {
                "StartDate": new_start.strftime("%Y-%m-%d"),
                "EndDate":   new_end.strftime("%Y-%m-%d"),
            }

            # Use the exact same path as DynamicTable → update_row_by_id
            self.data_service.repo.update_row_by_id(
                self.sheet_name,
                "TaskID",
                str(task_id),
                updated_data
            )

            # Keep in-memory task dict in sync so timeline redraws correctly
            task["StartDate"] = updated_data["StartDate"]
            task["EndDate"]   = updated_data["EndDate"]
            task["_start"]    = new_start
            task["_end"]      = new_end

            print(f"✅ Drag saved → TaskID {task_id} | "
                  f"{new_start.strftime('%d %b')} → {new_end.strftime('%d %b')}")

            # Notify main_window to refresh the task table
            if hasattr(self, "on_data_changed") and callable(self.on_data_changed):
                self.on_data_changed()

        except Exception as e:
            print(f"❌ Timeline drag save failed: {e}")

    # ─────────────────────────── TOOLTIP ─────────────────────────────────────
    def _show_tooltip(self, event, task):
        self._hide_tooltip()
        if task.get("is_project"):
            return

        lines = []
        name = task.get("TaskName", "")
        if name:
            lines.append(f"  {name}  ")

        start = task.get("_start")
        end   = task.get("_end")
        if start and end:
            dur = (end - start).days + 1
            lines.append(f"  {start.strftime('%d %b')} → {end.strftime('%d %b')}  ({dur}d)  ")

        status = task.get("Status")
        if status:
            lines.append(f"  Status : {status}  ")

        prog = task.get("Progress")
        if prog is not None:
            lines.append(f"  Progress: {prog}%  ")

        assigned = task.get("AssignedTo")
        if assigned and str(assigned) not in ("None", "nan", ""):
            lines.append(f"  Owner  : {assigned}  ")

        Comments = task.get("Comments")
        lines.append(f"  Comments: {Comments}  ")

        if not lines:
            return

        tw = tk.Toplevel(self)
        tw.wm_overrideredirect(True)
        tw.attributes("-topmost", True)
        tw.configure(bg=CLR["border"])

        inner = tk.Frame(tw, bg=CLR["panel_bg"], padx=1, pady=1)
        inner.pack(fill="both", expand=True, padx=1, pady=1)

        for i, ln in enumerate(lines):
            fg = CLR["text_primary"] if i > 0 else "#FFFFFF"
            fnt = ("Consolas", 9, "bold") if i == 0 else ("Consolas", 8)
            tk.Label(inner, text=ln, bg=CLR["panel_bg"], fg=fg, font=fnt,
                     anchor="w").pack(fill="x")

        tw.update_idletasks()
        x = event.x_root + 16
        y = event.y_root - 10
        tw.geometry(f"+{x}+{y}")
        self.tooltip_win = tw

    def _hide_tooltip(self):
        if self.tooltip_win:
            try:
                self.tooltip_win.destroy()
            except Exception:
                pass
            self.tooltip_win = None

    # ─────────────────────────── HELPERS ─────────────────────────────────────
    def _canvas_coords(self, event):
        """Convert widget coords → canvas (scrolled) coords."""
        cx = self.canvas.canvasx(event.x)
        cy = self.canvas.canvasy(event.y)
        return cx, cy