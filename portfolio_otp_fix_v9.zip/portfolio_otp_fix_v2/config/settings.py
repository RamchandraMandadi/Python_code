from pathlib import Path

class Settings:
    BASE_DIR   = Path(__file__).resolve().parent.parent
    INPUT_FOLDER = BASE_DIR / "input"
    EXCEL_FILE   = INPUT_FOLDER / "project_data.xlsx"
