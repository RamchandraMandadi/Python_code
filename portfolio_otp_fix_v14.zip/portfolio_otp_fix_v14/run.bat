@echo off
pip install pandas openpyxl Pillow python-pptx lxml requests --quiet
python main.py
