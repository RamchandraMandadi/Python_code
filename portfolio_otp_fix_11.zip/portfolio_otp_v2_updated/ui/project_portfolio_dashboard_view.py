"""
project_portfolio_dashboard_view.py — Project Portfolio Dashboard
Shown from the RAG Summary tab's "View" dropdown.

Lets the user pick a Manager (to narrow the list) and then a Project,
then renders a full dashboard for that single project:
  • KPI cards (tasks, progress, budget, resources, RAG)
  • Project Progress donut chart (task status breakdown)
  • Monthly Effort bar chart (Hours Logged, from WeeklyStatus)
  • RAG status grid (10 aspects)
  • Resources table (people assigned, derived from Tasks.AssignedTo)
  • Budget utilization gauge
"""

import tkinter as tk
from tkinter import ttk
import datetime
import pandas as pd

C = {
    'bg':     '#f0f2f7', 'surface': '#ffffff', 'border': '#dde1ed',
    'ink':    '#000000', 't2':      '#000000',
    'accent': '#2952e3', 'topbar':  '#000000',
    'R':      '#e53935', 'A':       '#f59e0b', 'G':      '#16a34a',
    'grey':   '#94a3b8', 'purple':  '#7c3aed',
}


def _parse_date(v):
    if not v or str(v).strip().lower() in ('', 'nan', 'nat', 'none'):
        return None
    for fmt in ('%Y-%m-%d', '%d/%m/%Y', '%m/%d/%Y', '%d-%m-%Y'):
        try:
            return datetime.datetime.strptime(str(v)[:10], fmt).date()
        except Exception:
            pass
    return None


def _safe_float(v):
    try:
        f = float(v)
        return 0.0 if f != f else f
    except Exception:
        return 0.0


class ProjectPortfolioDashboardView(tk.Frame):

    def __init__(self, parent, svc):
        super().__init__(parent, bg=C['bg'])
        self.svc            = svc
        self._pid           = None
        self._name_to_pid   = {}
        self._build_topbar()
        self._build_body_container()
        self._init_selection()

    # ══════════════════════════════════════════════════════════════════════
    # TOP CONTROL BAR — Manager + Project selectors
    # ══════════════════════════════════════════════════════════════════════
    def _build_topbar(self):
        bar = tk.Frame(self, bg=C['topbar'], height=50)
        bar.pack(fill='x')
        bar.pack_propagate(False)

        tk.Label(bar, text='📊  Project Portfolio Dashboard',
                 font=('Segoe UI', 12, 'bold'),
                 bg=C['topbar'], fg='white').pack(side='left', padx=16, pady=12)

        ctrl = tk.Frame(bar, bg=C['topbar'])
        ctrl.pack(side='right', padx=14, pady=9)

        tk.Label(ctrl, text='Project:', font=('Segoe UI', 9),
                 bg=C['topbar'], fg='#cbd5e1').pack(side='left', padx=(0, 4))
        self._proj_var = tk.StringVar()
        self._proj_cb = ttk.Combobox(ctrl, textvariable=self._proj_var,
                                     state='readonly', width=32,
                                     font=('Segoe UI', 9))
        self._proj_cb.pack(side='left', padx=(0, 16))
        self._proj_cb.bind('<<ComboboxSelected>>', self._on_project_change)

        tk.Label(ctrl, text='Manager:', font=('Segoe UI', 9),
                 bg=C['topbar'], fg='#cbd5e1').pack(side='left', padx=(0, 4))
        self._mgr_var = tk.StringVar()
        self._mgr_cb = ttk.Combobox(ctrl, textvariable=self._mgr_var,
                                    state='readonly', width=18,
                                    font=('Segoe UI', 9))
        self._mgr_cb.pack(side='left')
        self._mgr_cb.bind('<<ComboboxSelected>>', self._on_manager_change)

    # ══════════════════════════════════════════════════════════════════════
    # SCROLLABLE BODY CONTAINER
    # ══════════════════════════════════════════════════════════════════════
    def _build_body_container(self):
        outer = tk.Frame(self, bg=C['bg'])
        outer.pack(fill='both', expand=True)

        canvas = tk.Canvas(outer, bg=C['bg'], highlightthickness=0)
        vsb    = ttk.Scrollbar(outer, orient='vertical', command=canvas.yview)
        canvas.configure(yscrollcommand=vsb.set)
        vsb.pack(side='right', fill='y')
        canvas.pack(side='left', fill='both', expand=True)

        inner  = tk.Frame(canvas, bg=C['bg'])
        win_id = canvas.create_window((0, 0), window=inner, anchor='nw')
        inner.bind('<Configure>',
                   lambda e: canvas.configure(scrollregion=canvas.bbox('all')))
        canvas.bind('<Configure>',
                    lambda e: canvas.itemconfig(win_id, width=e.width))
        canvas.bind_all('<MouseWheel>',
            lambda e: canvas.yview_scroll(int(-1 * (e.delta / 60)), 'units'))

        self._body = tk.Frame(inner, bg=C['bg'], padx=20, pady=16)
        self._body.pack(fill='both', expand=True)

    # ══════════════════════════════════════════════════════════════════════
    # SELECTION — Manager filters Project list
    # ══════════════════════════════════════════════════════════════════════
    def _init_selection(self):
        projects = self.svc.get_projects()
        managers = sorted({str(p.get('Manager', '')).strip()
                           for p in projects if str(p.get('Manager', '')).strip()})
        self._mgr_cb['values'] = ['All Managers'] + managers
        self._mgr_var.set('All Managers')
        self._rebuild_project_list()

    def _rebuild_project_list(self):
        projects = self.svc.get_projects()
        mgr = self._mgr_var.get()
        if mgr and mgr != 'All Managers':
            projects = [p for p in projects
                       if str(p.get('Manager', '')).strip() == mgr]

        self._name_to_pid = {}
        labels = []
        for p in projects:
            pid   = str(p.get('ProjectID', ''))
            label = f"{p.get('ProjectName', '(unnamed)')}   ·   {pid}"
            self._name_to_pid[label] = pid
            labels.append(label)

        self._proj_cb['values'] = labels
        if labels:
            # keep current project selected if it's still in the filtered list
            cur_label = self._proj_var.get()
            if cur_label in labels:
                self._pid = self._name_to_pid[cur_label]
            else:
                self._proj_var.set(labels[0])
                self._pid = self._name_to_pid[labels[0]]
        else:
            self._proj_var.set('')
            self._pid = None

        self._refresh_body()

    def _on_manager_change(self, _=None):
        self._rebuild_project_list()

    def _on_project_change(self, _=None):
        label = self._proj_var.get()
        self._pid = self._name_to_pid.get(label)
        self._refresh_body()

    # ══════════════════════════════════════════════════════════════════════
    # DATA HELPERS
    # ══════════════════════════════════════════════════════════════════════
    def _load_weekly(self, pid):
        try:
            df = pd.read_excel(self.svc.path, sheet_name='WeeklyStatus', engine='openpyxl')
        except Exception:
            return []
        if df.empty or 'ProjectID' not in df.columns:
            return []
        df = df[df['ProjectID'].astype(str) == str(pid)]
        return df.to_dict('records')

    # ══════════════════════════════════════════════════════════════════════
    # BODY — rebuilt whenever the project selection changes
    # ══════════════════════════════════════════════════════════════════════
    def _refresh_body(self):
        for w in self._body.winfo_children():
            w.destroy()

        if not self._pid:
            tk.Label(self._body, text='No projects available.',
                     font=('Segoe UI', 10), bg=C['bg'],
                     fg=C['t2']).pack(pady=40)
            return

        project = self.svc.get_project(self._pid)
        tasks   = self.svc.get_tasks(self._pid)
        p_rag   = self.svc.get_project_rag(self._pid)
        weekly  = self._load_weekly(self._pid)

        self._header(self._body, project)
        self._kpi_row(self._body, project, tasks)
        self._charts_row(self._body, tasks, weekly)
        self._rag_and_resources_row(self._body, p_rag, tasks)
        self._budget_panel(self._body, project)

    # ── Header ────────────────────────────────────────────────────────────
    def _header(self, parent, p):
        bar = tk.Frame(parent, bg=C['topbar'])
        bar.pack(fill='x', pady=(0, 14))

        overall = self.svc.get_overall_rag(self._pid)
        badge_color = {'R': C['R'], 'A': C['A'], 'G': C['G']}[overall]
        tk.Label(bar, text=overall, bg=badge_color, fg='white',
                 font=('Segoe UI', 10, 'bold'), width=3,
                 pady=6).pack(side='left', padx=(12, 8), pady=10)

        tk.Label(bar, text=p.get('ProjectName', ''),
                 font=('Segoe UI', 13, 'bold'),
                 bg=C['topbar'], fg='white').pack(side='left', pady=10)

        meta = (f"   Manager: {p.get('Manager','')}    "
                f"Client: {p.get('Client','')}    "
                f"Priority: {p.get('Priority','')}    "
                f"{p.get('StartDate','')} → {p.get('EndDate','')}")
        tk.Label(bar, text=meta, font=('Segoe UI', 8),
                 bg=C['topbar'], fg='#94a3b8').pack(side='left', padx=8)

        desc = str(p.get('Description', '') or '').strip()
        if desc and desc.lower() != 'nan':
            tk.Label(parent, text=desc, font=('Segoe UI', 9),
                     bg=C['bg'], fg=C['t2'], anchor='w', justify='left',
                     wraplength=1150).pack(fill='x', pady=(6, 14))

    # ── KPI row ───────────────────────────────────────────────────────────
    def _kpi_row(self, parent, p, tasks):
        frame = tk.Frame(parent, bg=C['bg'])
        frame.pack(fill='x', pady=(0, 16))

        budget = _safe_float(p.get('Budget', 0))
        spent  = _safe_float(p.get('Spent', 0))
        util   = (spent / budget * 100) if budget else 0

        progress_vals = [_safe_float(t.get('Progress', 0)) for t in tasks]
        avg_prog = round(sum(progress_vals) / len(progress_vals), 1) if progress_vals else 0.0

        overall = self.svc.get_overall_rag(self._pid)
        resources_n = len({str(t.get('AssignedTo', '')).strip()
                           for t in tasks if str(t.get('AssignedTo', '')).strip()})

        cards = [
            ('Tasks',        str(len(tasks)),                       'total tasks',          C['accent']),
            ('Avg Progress', f'{avg_prog:.0f}%',                    'across all tasks',     C['accent']),
            ('Budget',       f"${budget:,.0f}",                     f"${spent:,.0f} spent",  C['purple']),
            ('Budget Used',  f'{util:.0f}%',                        'of allocated budget',  C['R'] if util >= 100 else (C['A'] if util >= 80 else C['G'])),
            ('Resources',    str(resources_n),                      'people assigned',      C['accent']),
            ('Overall RAG',  {'R': 'Red', 'A': 'Amber', 'G': 'Green'}[overall], 'project health', {'R': C['R'], 'A': C['A'], 'G': C['G']}[overall]),
        ]
        for col, (label, value, sub, color) in enumerate(cards):
            frame.columnconfigure(col, weight=1)
            self._kpi_card(frame, label, value, sub, color, col)

    def _kpi_card(self, parent, label, value, sub, color, col):
        card = tk.Frame(parent, bg=C['surface'],
                        highlightbackground=C['border'], highlightthickness=1)
        card.grid(row=0, column=col, sticky='ew', padx=5, pady=2, ipady=10)

        tk.Frame(card, bg=color, height=3).pack(fill='x')
        tk.Label(card, text=label, font=('Segoe UI', 9),
                 bg=C['surface'], fg=C['t2']).pack(pady=(8, 2))
        tk.Label(card, text=value, font=('Segoe UI', 18, 'bold'),
                 bg=C['surface'], fg=color).pack()
        tk.Label(card, text=sub, font=('Segoe UI', 8),
                 bg=C['surface'], fg=C['t2']).pack(pady=(2, 8))

    # ── Charts row: donut + monthly bar ──────────────────────────────────
    def _charts_row(self, parent, tasks, weekly):
        row = tk.Frame(parent, bg=C['bg'])
        row.pack(fill='x', pady=(0, 16))
        row.columnconfigure(0, weight=1)
        row.columnconfigure(1, weight=1)

        self._donut_card(row, tasks)
        self._monthly_bar_card(row, weekly)

    # ── Project Progress donut ───────────────────────────────────────────
    def _donut_card(self, parent, tasks):
        card = tk.Frame(parent, bg=C['surface'],
                        highlightbackground=C['border'], highlightthickness=1)
        card.grid(row=0, column=0, sticky='nsew', padx=(0, 8))

        tk.Label(card, text='Project Progress', font=('Segoe UI', 11, 'bold'),
                 bg=C['surface'], fg=C['ink'], anchor='w').pack(fill='x', padx=16, pady=(14, 4))
        tk.Frame(card, bg=C['border'], height=1).pack(fill='x')

        today  = datetime.date.today()
        counts = {'Completed': 0, 'In Progress': 0, 'Not Started': 0, 'Overdue': 0}
        for t in tasks:
            prog    = _safe_float(t.get('Progress', 0))
            status  = str(t.get('Status', '')).strip()
            end_dt  = _parse_date(t.get('EndDate'))
            if status == 'Completed' or prog >= 100:
                counts['Completed'] += 1
            elif end_dt and end_dt < today:
                counts['Overdue'] += 1
            elif prog > 0:
                counts['In Progress'] += 1
            else:
                counts['Not Started'] += 1
        total = sum(counts.values())

        body = tk.Frame(card, bg=C['surface'])
        body.pack(fill='both', expand=True, padx=10, pady=10)

        if total == 0:
            tk.Label(body, text='No tasks yet for this project.',
                     font=('Segoe UI', 9), bg=C['surface'],
                     fg=C['t2']).pack(pady=30)
            return

        cv = tk.Canvas(body, width=200, height=190, bg=C['surface'], highlightthickness=0)
        cv.pack(side='left', padx=(6, 16))

        donut_colors = [
            ('Completed',   C['G']),
            ('In Progress', C['A']),
            ('Not Started', C['grey']),
            ('Overdue',     C['R']),
        ]
        cx, cy, r = 95, 95, 78
        start = 90
        for label, color in donut_colors:
            n = counts[label]
            if n <= 0:
                continue
            extent = -360 * (n / total)
            cv.create_arc(cx - r, cy - r, cx + r, cy + r,
                          start=start, extent=extent,
                          fill=color, outline=C['surface'], width=3)
            start += extent

        hole = 42
        cv.create_oval(cx - hole, cy - hole, cx + hole, cy + hole,
                       fill=C['surface'], outline='')
        pct_done = round(100 * counts['Completed'] / total)
        cv.create_text(cx, cy - 8, text=f'{pct_done}%',
                       font=('Segoe UI', 17, 'bold'), fill=C['ink'])
        cv.create_text(cx, cy + 14, text='Completed',
                       font=('Segoe UI', 8), fill=C['t2'])

        leg = tk.Frame(body, bg=C['surface'])
        leg.pack(side='left', fill='y', pady=10)
        for label, color in donut_colors:
            n   = counts[label]
            pct = round(100 * n / total) if total else 0
            r_  = tk.Frame(leg, bg=C['surface'])
            r_.pack(fill='x', pady=4, anchor='w')
            tk.Frame(r_, bg=color, width=12, height=12).pack(side='left', padx=(0, 8))
            tk.Label(r_, text=f'{label}  —  {n} ({pct}%)',
                     font=('Segoe UI', 9), bg=C['surface'], fg=C['ink']).pack(side='left')

    # ── Monthly Effort bar chart (Hours Logged) ──────────────────────────
    def _monthly_bar_card(self, parent, weekly):
        card = tk.Frame(parent, bg=C['surface'],
                        highlightbackground=C['border'], highlightthickness=1)
        card.grid(row=0, column=1, sticky='nsew')

        tk.Label(card, text='Monthly Effort (Hours Logged)',
                 font=('Segoe UI', 11, 'bold'),
                 bg=C['surface'], fg=C['ink'], anchor='w').pack(fill='x', padx=16, pady=(14, 4))
        tk.Frame(card, bg=C['border'], height=1).pack(fill='x')

        body = tk.Frame(card, bg=C['surface'])
        body.pack(fill='both', expand=True, padx=14, pady=14)

        if not weekly:
            tk.Label(body, text='No weekly status entries logged for this project yet.',
                     font=('Segoe UI', 9), bg=C['surface'], fg=C['t2'],
                     wraplength=320, justify='left').pack(pady=30)
            return

        agg   = {}
        order = []
        for w in weekly:
            key   = str(w.get('Month', '')).strip() or str(w.get('MonthLabel', ''))
            label = str(w.get('MonthLabel', '')).strip() or key
            hrs   = _safe_float(w.get('HoursLogged', 0))
            if key not in agg:
                agg[key] = {'label': label, 'hours': 0.0}
                order.append(key)
            agg[key]['hours'] += hrs

        order.sort()
        months = order[-6:]                 # last up to 6 months
        max_h  = max((agg[k]['hours'] for k in months), default=0) or 1

        cv = tk.Canvas(body, height=180, bg=C['surface'], highlightthickness=0)
        cv.pack(fill='x', expand=True)

        def draw(event=None):
            cv.delete('all')
            W      = cv.winfo_width() or 360
            n      = len(months)
            slot   = W / max(n, 1)
            bar_w  = min(46, slot * 0.5)
            base_y = 150
            for i, k in enumerate(months):
                v = agg[k]['hours']
                h = (v / max_h) * 110 if max_h else 0
                x = i * slot + slot / 2
                cv.create_rectangle(x - bar_w / 2, base_y - h, x + bar_w / 2, base_y,
                                    fill=C['accent'], outline='')
                cv.create_text(x, base_y - h - 10, text=f'{v:.0f}h',
                               font=('Segoe UI', 8, 'bold'), fill=C['ink'])
                cv.create_text(x, base_y + 14, text=agg[k]['label'],
                               font=('Segoe UI', 8), fill=C['t2'])
            cv.create_line(0, base_y, W, base_y, fill=C['border'])

        cv.bind('<Configure>', draw)
        card.after(80, draw)

    # ── RAG grid + Resources table ───────────────────────────────────────
    def _rag_and_resources_row(self, parent, p_rag, tasks):
        row = tk.Frame(parent, bg=C['bg'])
        row.pack(fill='x', pady=(0, 16))
        row.columnconfigure(0, weight=1)
        row.columnconfigure(1, weight=2)

        self._rag_card(row, p_rag)
        self._resources_card(row, tasks)

    def _rag_card(self, parent, p_rag):
        card = tk.Frame(parent, bg=C['surface'],
                        highlightbackground=C['border'], highlightthickness=1)
        card.grid(row=0, column=0, sticky='nsew', padx=(0, 8))

        tk.Label(card, text='RAG Status', font=('Segoe UI', 11, 'bold'),
                 bg=C['surface'], fg=C['ink'], anchor='w').pack(fill='x', padx=16, pady=(14, 4))
        tk.Frame(card, bg=C['border'], height=1).pack(fill='x')

        from services.portfolio_service import RAG_ASPECTS
        grid = tk.Frame(card, bg=C['surface'])
        grid.pack(padx=14, pady=12, fill='x')
        for ci in range(2):
            grid.columnconfigure(ci, weight=1)

        for i, asp in enumerate(RAG_ASPECTS):
            s    = p_rag.get(asp, {}).get('status', 'G')
            cell = tk.Frame(grid, bg=C['surface'])
            cell.grid(row=i // 2, column=i % 2, padx=6, pady=6, sticky='ew')

            badge_row = tk.Frame(cell, bg=C['surface'])
            badge_row.pack(anchor='w')
            tk.Label(badge_row, text=s, width=2,
                     bg={'R': C['R'], 'A': C['A'], 'G': C['G']}[s], fg='white',
                     font=('Segoe UI', 9, 'bold'), pady=3).pack(side='left', padx=(0, 6))
            tk.Label(badge_row, text=asp, font=('Segoe UI', 8),
                     bg=C['surface'], fg=C['t2']).pack(side='left')

    def _resources_card(self, parent, tasks):
        card = tk.Frame(parent, bg=C['surface'],
                        highlightbackground=C['border'], highlightthickness=1)
        card.grid(row=0, column=1, sticky='nsew')

        tk.Label(card, text='Resources', font=('Segoe UI', 11, 'bold'),
                 bg=C['surface'], fg=C['ink'], anchor='w').pack(fill='x', padx=16, pady=(14, 4))
        tk.Frame(card, bg=C['border'], height=1).pack(fill='x')

        today = datetime.date.today()
        agg   = {}
        for t in tasks:
            name = str(t.get('AssignedTo', '')).strip() or 'Unassigned'
            d    = agg.setdefault(name, {'total': 0, 'completed': 0, 'overdue': 0, 'progress_sum': 0.0})
            d['total'] += 1
            prog   = _safe_float(t.get('Progress', 0))
            status = str(t.get('Status', '')).strip()
            end_dt = _parse_date(t.get('EndDate'))
            d['progress_sum'] += prog
            if status == 'Completed' or prog >= 100:
                d['completed'] += 1
            elif end_dt and end_dt < today:
                d['overdue'] += 1

        body = tk.Frame(card, bg=C['surface'])
        body.pack(fill='both', expand=True, padx=10, pady=8)

        if not agg:
            tk.Label(body, text='No resources assigned to this project yet.',
                     font=('Segoe UI', 9), bg=C['surface'], fg=C['t2']).pack(pady=20)
            return

        hdr = tk.Frame(body, bg='#1f2d4a')
        hdr.pack(fill='x')
        for lbl, w in [('Resource', 160), ('Tasks', 60), ('Completed', 80),
                      ('Overdue', 70), ('Avg Progress', 100)]:
            tk.Label(hdr, text=lbl.upper(), font=('Segoe UI', 8, 'bold'),
                     bg='#1f2d4a', fg='#cbd5e1', width=w // 7, anchor='w',
                     padx=8, pady=6).pack(side='left')

        for i, (name, d) in enumerate(sorted(agg.items(), key=lambda kv: -kv[1]['total'])):
            avg_p = d['progress_sum'] / d['total'] if d['total'] else 0
            bg    = C['surface'] if i % 2 == 0 else '#f7f8fc'
            r_    = tk.Frame(body, bg=bg)
            r_.pack(fill='x')

            tk.Label(r_, text=name, font=('Segoe UI', 9, 'bold'),
                     bg=bg, fg=C['ink'], width=160 // 7, anchor='w',
                     padx=8, pady=7).pack(side='left')
            tk.Label(r_, text=str(d['total']), font=('Segoe UI', 9),
                     bg=bg, fg=C['ink'], width=60 // 7, anchor='w', padx=8).pack(side='left')
            tk.Label(r_, text=str(d['completed']), font=('Segoe UI', 9),
                     bg=bg, fg=C['G'], width=80 // 7, anchor='w', padx=8).pack(side='left')
            ov_color = C['R'] if d['overdue'] > 0 else C['t2']
            tk.Label(r_, text=str(d['overdue']),
                     font=('Segoe UI', 9, 'bold' if d['overdue'] > 0 else 'normal'),
                     bg=bg, fg=ov_color, width=70 // 7, anchor='w', padx=8).pack(side='left')
            tk.Label(r_, text=f'{avg_p:.0f}%', font=('Segoe UI', 9, 'bold'),
                     bg=bg, fg=C['accent'], width=100 // 7, anchor='w', padx=8).pack(side='left')

            tk.Frame(body, bg=C['border'], height=1).pack(fill='x')

    # ── Budget gauge ──────────────────────────────────────────────────────
    def _budget_panel(self, parent, p):
        card = tk.Frame(parent, bg=C['surface'],
                        highlightbackground=C['border'], highlightthickness=1)
        card.pack(fill='x')

        tk.Label(card, text='Budget Utilization', font=('Segoe UI', 11, 'bold'),
                 bg=C['surface'], fg=C['ink'], anchor='w').pack(fill='x', padx=16, pady=(14, 4))
        tk.Frame(card, bg=C['border'], height=1).pack(fill='x')

        budget = _safe_float(p.get('Budget', 0))
        spent  = _safe_float(p.get('Spent', 0))
        pct    = (spent / budget * 100) if budget else 0
        color  = C['R'] if pct >= 100 else (C['A'] if pct >= 80 else C['G'])

        body = tk.Frame(card, bg=C['surface'])
        body.pack(fill='x', padx=16, pady=14)

        cv = tk.Canvas(body, height=24, bg=C['surface'], highlightthickness=0)
        cv.pack(fill='x')

        def draw(event=None):
            cv.delete('all')
            W = cv.winfo_width() or 600
            cv.create_rectangle(0, 0, W, 24, fill='#e5e7eb', outline='')
            fill_w = min(W, W * pct / 100)
            cv.create_rectangle(0, 0, fill_w, 24, fill=color, outline='')

        cv.bind('<Configure>', draw)
        card.after(80, draw)

        info = tk.Frame(body, bg=C['surface'])
        info.pack(fill='x', pady=(8, 0))
        for label, value in [
            ('Budget',    f'${budget:,.0f}'),
            ('Spent',     f'${spent:,.0f}'),
            ('Remaining', f'${budget - spent:,.0f}'),
            ('Utilized',  f'{pct:.0f}%'),
        ]:
            box = tk.Frame(info, bg=C['surface'])
            box.pack(side='left', padx=(0, 28))
            tk.Label(box, text=label, font=('Segoe UI', 8),
                     bg=C['surface'], fg=C['t2']).pack(anchor='w')
            tk.Label(box, text=value, font=('Segoe UI', 11, 'bold'),
                     bg=C['surface'],
                     fg=color if label == 'Utilized' else C['ink']).pack(anchor='w')

    # ══════════════════════════════════════════════════════════════════════
    def refresh(self):
        """Re-read managers/projects (e.g. after a new project is added) and redraw."""
        self._init_selection()
