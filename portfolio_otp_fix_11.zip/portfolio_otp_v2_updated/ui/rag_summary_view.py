"""
rag_summary_view.py  — Project Task Summary
Shows tasks grouped by project, colour-coded by completion % + dates.

Row colours:
  Green  — Progress = 100 (completed on time)
  Red    — End date passed AND Progress < 100  (overdue)
  Amber  — Progress > 0 but < 100, end date not yet passed  (in progress)
  Amber  — Progress = 0, not started yet within timeframe
"""

import tkinter as tk
from tkinter import ttk
import datetime, math

C = {
    'bg':     '#f0f2f7', 'surface': '#ffffff', 'border': '#dde1ed',
    'ink':    '#000000', 'ink2':    '#000000', 't2':     '#000000',
    'accent': '#2952e3', 'topbar':  '#000000',
    'R':      '#e53935', 'A':       '#f59e0b', 'G':      '#16a34a',
    'R_bg':   '#fdecea', 'A_bg':    '#fffbeb', 'G_bg':   '#f0fdf4',
    'R_fg':   '#991b1b', 'A_fg':    '#92400e', 'G_fg':   '#166534',
}


def _parse_date(v):
    if not v or str(v).strip().lower() in ('', 'nan', 'nat', 'none'):
        return None
    for fmt in ('%Y-%m-%d', '%d/%m/%Y', '%m/%d/%Y', '%d-%m-%Y'):
        try:
            return datetime.datetime.strptime(str(v)[:10], fmt).date()
        except:
            pass
    return None


def _safe_float(v):
    try:
        f = float(v)
        return 0.0 if f != f else f
    except:
        return 0.0


def row_colour(progress, end_date_str, status=""):
    """
    Green  : Status == Completed  OR  Progress >= 100
    Red    : End date passed AND task is NOT completed  (Overdue)
    Amber  : In progress or not started, within deadline
    """
    today  = datetime.date.today()
    end_dt = _parse_date(end_date_str)
    pct    = _safe_float(progress)
    stat   = str(status).strip()          # ← THIS IS THE FIX

    # Completed wins regardless of progress %
    if stat == 'Completed' or pct >= 100:
        return C['G_bg'], C['G_fg'], 'Completed'

    # Past end date and NOT completed → Overdue
    if end_dt and end_dt < today:
        return C['R_bg'], C['R_fg'], 'Overdue'

    label = 'In Progress' if pct > 0 else 'Not Started'
    return C['A_bg'], C['A_fg'], label 

class RagSummaryView(tk.Frame):

    MODES = ['Project Portfolio Dashboard', 'Project Task Summary']

    def __init__(self, parent, svc):
        super().__init__(parent, bg=C['bg'])
        self.svc       = svc
        self._mode_var = tk.StringVar(value='Project Task Summary')
        self._content  = None
        self._build_shell()

    # ── shell: top "View" selector + swappable content area ────────────────
    def _build_shell(self):
        bar = tk.Frame(self, bg=C['topbar'], height=46)
        bar.pack(fill='x')
        bar.pack_propagate(False)

        tk.Label(bar, text='📋  RAG Summary', font=('Segoe UI', 12, 'bold'),
                 bg=C['topbar'], fg='white').pack(side='left', padx=16, pady=10)

        ctrl = tk.Frame(bar, bg=C['topbar'])
        ctrl.pack(side='right', padx=14, pady=8)
        tk.Label(ctrl, text='View:', font=('Segoe UI', 9),
                 bg=C['topbar'], fg='#cbd5e1').pack(side='left', padx=(0, 6))
        cb = ttk.Combobox(ctrl, textvariable=self._mode_var, state='readonly',
                          width=28, font=('Segoe UI', 9), values=self.MODES)
        cb.pack(side='left')
        cb.bind('<<ComboboxSelected>>', lambda e: self._render())

        self._content = tk.Frame(self, bg=C['bg'])
        self._content.pack(fill='both', expand=True)

        self._render()

    def _render(self):
        for w in self._content.winfo_children():
            w.destroy()

        if self._mode_var.get() == 'Project Portfolio Dashboard':
            from ui.project_portfolio_dashboard_view import ProjectPortfolioDashboardView
            ProjectPortfolioDashboardView(self._content, self.svc).pack(fill='both', expand=True)
        else:
            self._build_task_summary(self._content)

    def _build_task_summary(self, parent):
        # scrollable canvas
        canvas = tk.Canvas(parent, bg=C['bg'], highlightthickness=0)
        vsb    = ttk.Scrollbar(parent, orient='vertical', command=canvas.yview)
        canvas.configure(yscrollcommand=vsb.set)
        vsb.pack(side='right', fill='y')
        canvas.pack(side='left', fill='both', expand=True)

        inner  = tk.Frame(canvas, bg=C['bg'])
        win_id = canvas.create_window((0, 0), window=inner, anchor='nw')
        inner.bind('<Configure>',
                   lambda e: canvas.configure(scrollregion=canvas.bbox('all')))
        canvas.bind('<Configure>',
                    lambda e: canvas.itemconfig(win_id, width=e.width))
        canvas.bind_all('<MouseWheel>',
            lambda e: canvas.yview_scroll(int(-1 * (e.delta / 60)), 'units'))

        pad = tk.Frame(inner, bg=C['bg'], padx=22, pady=20)
        pad.pack(fill='both', expand=True)

        # page header + legend
        hdr = tk.Frame(pad, bg=C['bg'])
        hdr.pack(fill='x', pady=(0, 6))
        tk.Label(hdr, text='Project Task Summary',
                 font=('Segoe UI', 14, 'bold'),
                 bg=C['bg'], fg=C['ink']).pack(side='left')

        leg = tk.Frame(pad, bg=C['bg'])
        leg.pack(fill='x', pady=(0, 18))
        tk.Label(leg, text='Colour guide:', font=('Segoe UI', 8, 'bold'),
                 bg=C['bg'], fg=C['t2']).pack(side='left', padx=(0, 8))
        for lbl, bg, fg in [
            ('Completed (100%)',         C['G_bg'], C['G_fg']),
            ('Overdue (past end date)',   C['R_bg'], C['R_fg']),
            ('In Progress / Not Started', C['A_bg'], C['A_fg']),
        ]:
            tk.Label(leg, text=f'  {lbl}  ',
                     font=('Segoe UI', 8, 'bold'),
                     bg=bg, fg=fg,
                     padx=8, pady=3).pack(side='left', padx=4)

        projects = self.svc.get_projects()

        for p in projects:
            pid   = str(p['ProjectID'])
            tasks = self.svc.get_tasks(pid)
            self._project_block(pad, p, tasks)

    def _project_block(self, parent, p, tasks):
        pid = str(p['ProjectID'])

        # ── Project-level status — based on PROJECT dates, not task dates ──────
        today    = datetime.date.today()
        p_end    = _parse_date(p.get('EndDate'))
        p_start  = _parse_date(p.get('StartDate'))

        def _task_done(t):
            """Task is done if Status=Completed OR Progress>=100."""
            if str(t.get('Status', '')).strip() == 'Completed':
                return True
            try:
                return float(t.get('Progress', 0) or 0) >= 100
            except:
                return False

        all_done = bool(tasks) and all(_task_done(t) for t in tasks)

        # ── Project Status (based on project end date only) ───────────────────
        # Green : ALL tasks completed before or on end date
        # Red   : Project end date has PASSED and NOT all tasks complete
        # Amber : Project end date has NOT yet passed and NOT all tasks complete
        if all_done:
            p_status, p_status_bg, p_status_fg = 'Green', C['G_bg'], C['G_fg']
        elif p_end and p_end < today:
            p_status, p_status_bg, p_status_fg = 'Red',   C['R_bg'], C['R_fg']
        elif p_end and p_end >= today:
            p_status, p_status_bg, p_status_fg = 'Amber', C['A_bg'], C['A_fg']
        else:
            p_status, p_status_bg, p_status_fg = 'Green', C['G_bg'], C['G_fg']

        card = tk.Frame(parent, bg=C['surface'],
                        highlightbackground=C['border'], highlightthickness=1)
        card.pack(fill='x', pady=(0, 14))

        # ── project header row ────────────────────────────────────────────────
        proj_hdr = tk.Frame(card, bg=C['topbar'])
        proj_hdr.pack(fill='x')

        # badge
        tk.Label(proj_hdr, text=p_status[0],
                 bg={'Green': C['G'], 'Red': C['R'], 'Amber': C['A']}[p_status],
                 fg='white', font=('Segoe UI', 10, 'bold'),
                 width=3, pady=6).pack(side='left', padx=(12, 8))

        tk.Label(proj_hdr,
                 text=p.get('ProjectName', ''),
                 font=('Segoe UI', 11, 'bold'),
                 bg=C['topbar'], fg='white').pack(side='left')

        meta = (f"  {p.get('StartDate','')}  →  {p.get('EndDate','')}  "
                f"  Manager: {p.get('Manager','')}  "
                f"  Priority: {p.get('Priority','')}")
        tk.Label(proj_hdr, text=meta,
                 font=('Segoe UI', 8),
                 bg=C['topbar'], fg='#94a3b8').pack(side='left', padx=8)

        tk.Label(proj_hdr, text=f'Status: {p_status}',
                 font=('Segoe UI', 8, 'bold'),
                 bg=p_status_bg, fg=p_status_fg,
                 padx=10, pady=5).pack(side='right', padx=12)

        # ── column headings ───────────────────────────────────────────────────
        col_defs = [
            ('Task Name',   220, 'w'),
            ('Phase',        90, 'w'),
            ('Assigned To', 120, 'w'),
            ('Start Date',   95, 'center'),
            ('End Date',     95, 'center'),
            ('Status',      110, 'center'),
            ('Progress',     80, 'center'),
        ]
        hdr_row = tk.Frame(card, bg='#1f2d4a')
        hdr_row.pack(fill='x')
        for lbl, w, anchor in col_defs:
            tk.Label(hdr_row, text=lbl,
                     font=('Segoe UI', 8, 'bold'),
                     bg='#1f2d4a', fg='#cbd5e1',
                     width=w // 7, anchor=anchor,
                     padx=8, pady=6).pack(side='left')

        # ── task rows ─────────────────────────────────────────────────────────
        if not tasks:
            tk.Label(card, text='  No tasks found for this project.',
                     font=('Segoe UI', 9), bg=C['surface'], fg=C['t2'],
                     pady=10, anchor='w').pack(fill='x', padx=12)
            return

        for i, t in enumerate(tasks):
            pct          = _safe_float(t.get('Progress', 0))
            end_d        = str(t.get('EndDate', ''))
            task_status  = str(t.get('Status', ''))
            bg, fg, status_label = row_colour(pct, end_d, task_status)

            row = tk.Frame(card, bg=bg)
            row.pack(fill='x')

            def _val(key, t=t):
                v = t.get(key, '')
                if v is None or (isinstance(v, float) and math.isnan(v)):
                    return ''
                return str(v)

            # Task Name
            tk.Label(row, text=_val('TaskName'),
                     font=('Segoe UI', 9, 'bold' if pct >= 100 else 'normal'),
                     bg=bg, fg=fg, width=220 // 7,
                     padx=8, pady=8, anchor='w').pack(side='left')
            # Phase
            tk.Label(row, text=_val('Phase'),
                     font=('Segoe UI', 9), bg=bg, fg=fg,
                     width=90 // 7, padx=8, anchor='w').pack(side='left')
            # Assigned To
            tk.Label(row, text=_val('AssignedTo'),
                     font=('Segoe UI', 9), bg=bg, fg=fg,
                     width=120 // 7, padx=8, anchor='w').pack(side='left')
            # Start Date
            tk.Label(row, text=_val('StartDate'),
                     font=('Segoe UI', 9), bg=bg, fg=fg,
                     width=95 // 7, padx=8, anchor='center').pack(side='left')
            # End Date
            tk.Label(row, text=_val('EndDate'),
                     font=('Segoe UI', 9), bg=bg, fg=fg,
                     width=95 // 7, padx=8, anchor='center').pack(side='left')
            # Status label
            tk.Label(row, text=status_label,
                     font=('Segoe UI', 8, 'bold'),
                     bg=bg, fg=fg,
                     width=110 // 7, padx=8, anchor='center').pack(side='left')
            # Progress %
            pct_txt = f'{pct:.0f}%'
            tk.Label(row, text=pct_txt,
                     font=('Segoe UI', 9, 'bold'),
                     bg=bg, fg=fg,
                     width=80 // 7, padx=8, anchor='center').pack(side='left')

            # thin divider
            tk.Frame(card, bg=C['border'], height=1).pack(fill='x')

    def refresh(self):
        self._render()
